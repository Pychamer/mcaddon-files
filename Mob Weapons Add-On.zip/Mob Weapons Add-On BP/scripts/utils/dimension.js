import * as mc from "@minecraft/server";
/**
 * @remarks Shorthand for mc.world.getDimension('overworld');
 */
export const overworld = mc.world.getDimension('overworld');
/**
 * @remarks Shorthand for mc.world.getDimension('nether');
 */
export const nether = mc.world.getDimension('nether');
/**
 * @remarks Shorthand for mc.world.getDimension('the_end');
 */
export const end = mc.world.getDimension('the_end');
