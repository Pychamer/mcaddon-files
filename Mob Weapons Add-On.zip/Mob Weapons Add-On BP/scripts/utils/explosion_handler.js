import { afterEvents } from "./events";
/**
 * @remarks Creates an explosion from a command.
 * @example
 * sample.mcfunction
 * ```mcfunction
 * scriptevent ldz:explosion {"radius": 1}
 * ```
 */
function initializeExplosionHandler() {
    afterEvents.scriptEventRecieve.subscribe("explosion", event => {
        if (event.sourceEntity) {
            event.sourceEntity.dimension.createExplosion(event.sourceEntity.location, event.data.radius, event.data.options);
        }
    });
}
initializeExplosionHandler();
