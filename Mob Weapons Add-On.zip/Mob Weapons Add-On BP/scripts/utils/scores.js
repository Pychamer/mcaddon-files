import * as mc from "@minecraft/server";
import { GlobalNamespace } from "./namespace";
import { SafetyCheckedEntity } from "./entity";
/**
 * @remarks Sets a target's score. This will automatically initialize the objective and add the entity to the scoreboard if needed.
 * @param target The target who's score to set.
 * @param objectiveID The objective name to set.
 * @param value The value the scoreboard should be set to.
 * @returns The value of the target's objective score.
 * @example
 * ```typescript
 * setScore('.var', 'myScore', 10); // Sets .var's myScore value to 10
 * ```
 */
export function setScore(target, objectiveID, value) {
    if (target instanceof SafetyCheckedEntity)
        target = target.UnsafeEntity;
    let objective = mc.world.scoreboard.getObjective(GlobalNamespace.Namespace + objectiveID);
    if (!objective) {
        objective = mc.world.scoreboard.addObjective(GlobalNamespace.Namespace + objectiveID, objectiveID);
    }
    objective.setScore(target, value);
}
/**
 * @remarks Modifies a target's score by the value provided. This will automatically initialize the objective and add the entity to the scoreboard if needed.
 * @param target The target who's score to set.
 * @param objectiveID The objective name to set.
 * @param value The amount to modify the score by.
 * @returns The value of the target's objective score.
 * @example
 * ```typescript
 * modifyScore('.var', 'myScore', 10); // adds 10 to .var's myScore
 * ```
 */
export function modifyScore(target, objectiveID, value) {
    if (target instanceof SafetyCheckedEntity)
        target = target.UnsafeEntity;
    let currentScore = getScore(target, objectiveID);
    setScore(target, objectiveID, currentScore + value);
}
/**
 * @remarks Checks an entity's score. This will automatically initialize the objective and add the entity to the scoreboard if needed.
 * @param target The target who's score to read.
 * @param objectiveID The objective name to test.
 * @returns The value of the target's objective score.
 * @example
 * ```typescript
 * const score = getScore('.var', 'myScore'); // Returns .var's myScore value, initializing it to 0 if the scoreboard is not setup.
 * ```
 */
export function getScore(target, objectiveID) {
    if (target instanceof SafetyCheckedEntity)
        target = target.UnsafeEntity;
    let objective = mc.world.scoreboard.getObjective(GlobalNamespace.Namespace + objectiveID);
    if (!objective) {
        objective = mc.world.scoreboard.addObjective(GlobalNamespace.Namespace + objectiveID, objectiveID);
        objective.setScore(target, 0);
        return 0;
    }
    if (!objective.hasParticipant(target)) {
        objective.setScore(target, 0);
        return 0;
    }
    const score = objective.getScore(target);
    if (score !== undefined) {
        return score;
    }
    objective.setScore(target, 0);
    return 0;
}
/**
 * @remarks Checks an score and returns true if the score is >= 1, false otherwise.
 * @param target The target who's score to read.
 * @param objectiveID The objective name to test.
 * @returns True if the score is >= 1, false otherwise.
 * @example
 * ```typescript
 * const shouldRun = getScoreAsBool('.var', 'myScore'); // Returns true if .var's myScore value is not 0, false otherwise
 * ```
 */
export function getScoreAsBool(target, objectiveID) {
    return Boolean(getScore(target, objectiveID));
}
/**
 * @deprecated An alias for {@link getScore} for backwards compatibility
 */
export function getTargetScore(target, objective, range_min = 0, range_max = 0) {
    return getScore(target, objective);
}
/**
 * @deprecated An alias for {@link getScore} for backwards compatibility
 */
export function getEntityScore(entity, objective, range_min = 0, range_max = 0) {
    return getScore(entity, objective);
}
/**
 * @deprecated An alias for {@link getScoreAsBool} for backwards compatibility
 */
export function getTargetScoreAsBool(target, objective) {
    return getScoreAsBool(target, objective);
}
/**
 * @deprecated An alias for {@link getScoreAsBool} for backwards compatibility
 */
export function getEntityScoreAsBool(target, objective) {
    return getScoreAsBool(target, objective);
}
