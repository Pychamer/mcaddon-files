import * as mc from "@minecraft/server";
import { waitForEvent } from "./events";
import { runCommand } from "./commands";
/**
 * @deprecated This has been deprecated. Now use `scriptevent <namespace>:command_delay {"delay": <number>, "command": <command>}`
 * @remarks Calls a function after a specified amount of time. Can be called from mcfunctions and animations.
 * @example
 * sample.mcfunction
 * ```mcfunction
 * scriptevent ldz:mcfunction {"delay": 5, "function": "test"}
 * ```
 */
export function initializeMcfunctionDelay() {
    mc.system.afterEvents.scriptEventReceive.subscribe(event => {
        if (event.id === 'ldz:mcfunction' && event.sourceEntity) {
            let functionData = { delay: 0, fromEntity: true };
            if (event.message) {
                functionData = Object.assign(Object.assign({}, functionData), JSON.parse(event.message));
            }
            waitForEvent(functionData.delay, () => {
                if (functionData.fromEntity) {
                    runCommand(`function ${functionData.function}`, event.sourceEntity);
                }
                else {
                    runCommand(`function ${functionData.function}`);
                }
            });
        }
    });
}
