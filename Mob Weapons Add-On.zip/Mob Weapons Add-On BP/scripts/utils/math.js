/**
 * @remarks Clamps a number inclusively.
 * @param value The value to be clamped.
 * @param min The minimum value (inclusive).
 * @param max The maximum value (inclusive).
 * @returns The clamped value.
 * @example
 * ```typescript
 * const value = clamp(100, 0, 99); // Returns 99
 * ```
 */
export function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}
/**
 * @remarks Gets a random number between min and max (inclusive).
 * @param min The minimum value (inclusive).
 * @param max The maximum value (inclusive).
 * @returns A random number between min and max.
 * @example
 * ```typescript
 * const value = getRandomInteger(0, 9); // Returns a random value beteen 0 and 9
 * ```
 */
export function getRandomInteger(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
/**
 * @remarks Wraps a number around the minimum an maximum, i.e. a value higher than max wraps to the minimum, a value lower than min wraps around to the maximum.
 * @param min The minimum value to wrap to (inclusive).
 * @param max The maximum value to wrap to (inclusive).
 * @param value The value to wrap around minimum and maximum.
 * @returns The value wrapped around min to max.
 * @example
 * ```typescript
 * wrapAroundMinMax(0, 10, 15) // Outputs 5 as it wraps above 10 with 5 remaining.
 * wrapAroundMinMax(0, 10, -2) // Outputs 9 as it wraps below 0 with -1 remaining.
 * wrapAroundMinMax(0, 24000, mc.world.getTimeOfDay() + 6000) // Outputs the time of day as if 0 was midnight like in a real clock, rather than sunrise as in Minecraft.
 * ```
 */
export function wrapAroundMinMax(min, max, value) {
    const mod = (max + 1) - min;
    return ((value % mod) + mod) % mod;
}
/**
 * @remarks Normalizes a value between a range to a 0-1 point.
 * @param min The minimum value of the range.
 * @param max The maximum value of the range.
 * @param value The value to normalize.
 * @returns A number between 0-1.
 * @example
 * ```typescript
 * normalize(0, 255, 90) // Outputs 0.35294117647058826
 */
export function normalize(min, max, value) {
    if (max - min === 0)
        return 0;
    return Math.min(1, (value - min) / (max - min));
}
/**
 * @remarks Performs a linear interpolation between the min and max, returning the value at the alpha.
 * @param min The minimum value.
 * @param max The maximum value.
 * @param alpha The alpha between min and max, should be normalized to 0-1.
 * @returns The interpolated value between min and max at the alpha.
 * @example
 * ```typescript
 * lerp(0, 100, 0.5) // Outputs 50
 */
export function lerp(min, max, alpha) {
    return min + alpha * (max - min);
}
