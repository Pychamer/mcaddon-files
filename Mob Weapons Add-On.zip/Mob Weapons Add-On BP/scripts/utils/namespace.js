import { afterEvents } from "./events";
/**
 * @global
 * @remarks Getter and Setter for the global namespace, used in scoreboard objective and tag names.
 */
export class GlobalNamespace {
    /**
     * @remarks Gets the Namespace, appending a ":" unless Namespace is empty.
     */
    static get Namespace() {
        return this.namespace + (this.namespace === '' ? '' : ':');
    }
    /**
     * @remarks Gets the Namespace, does not append a ":" ever.
     */
    static get NamespaceUnformatted() {
        return this.namespace;
    }
    /**
     * @remarks Sets the Namespace
     */
    static set Namespace(v) {
        this.namespace = v;
        //@ts-ignore
        afterEvents.onNamespaceChanged.raise(v);
    }
    /**
     * @remarks Gets or sets the Ignore flag, set to true if the project isn't using a namespace to allow the {@link waitForNamespace} promise to resolve immediately.
     */
    static get Ignore() {
        return this.ignore;
    }
    static set Ignore(v) {
        this.ignore = v;
        //@ts-ignore
        afterEvents.onNamespaceChanged.raise(this.namespace);
    }
}
GlobalNamespace.namespace = '';
GlobalNamespace.ignore = false;
/**
 * @remarks Shorthand for `GlobalNamespace.Namespace + <source_string>`.
 * @param source The string to prepend with the Global Namespace.
 * @param formatted Should the `:` be added, defaults to true.
 * @returns The source string with the namespace prepended.
 * @example
 * ```typescript
 * mclog(addName("test")); // prints "ldz:test"
 * ```
 */
export function addName(source, formatted = true) {
    if (source.startsWith(GlobalNamespace.NamespaceUnformatted))
        return source;
    return (formatted ? GlobalNamespace.Namespace : GlobalNamespace.NamespaceUnformatted) + source;
}
