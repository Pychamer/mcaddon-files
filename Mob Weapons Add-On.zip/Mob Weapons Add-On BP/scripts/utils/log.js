import * as mc from "@minecraft/server";
import { GlobalNamespace } from "./namespace";
function getTimeStamp() {
    const date = new Date(Date.now());
    const hour = date.getUTCHours();
    const minutes = date.getUTCMinutes();
    const seconds = date.getUTCSeconds();
    const milliseconds = date.getUTCMilliseconds();
    return `[${hour}:${minutes}:${seconds}:${milliseconds}, ${mc.system.currentTick}]`;
}
/**
 * @deprecated This has been deprecated in favor of {@link mc.Player.onScreenDisplay}'s {@link mc.ScreenDisplay.setActionBar}
 * @remarks Sends a message to the target's actionbar.
 * @param target The target to send the actionbar to.
 * @param msg The message to send to the target.
 * @param translate Should the message be translated.
 */
export function actionbar(target, msg, translate = false) {
    let rawtext = translate ? `"translate": "${msg}"` : `"text": "${msg}"`;
    target.runCommand(`titleraw @s actionbar { "rawtext": [ { ${rawtext} }] }`);
}
/**
 * @deprecated This has been deprecated in favor of {@link mc.Player.onScreenDisplay}'s {@link mc.ScreenDisplay.setTitle}
 * @remarks Sends a message to the target's title screen.
 * @param target The target to send the title screen to.
 * @param msg The message to send to the target.
 * @param translate Should the message be translated.
 */
export function title(target, msg, translate = false) {
    let rawtext = translate ? `"translate": "${msg}"` : `"text": "${msg}"`;
    target.runCommand(`titleraw @s title { "rawtext": [ { ${rawtext} }] }`);
}
/**
 * @remarks Prints a log to players with the dev tag.
 * @param msg The message to print as a string.
 * @param categories Optional additional tags a player must have to see the message.
 * @example
 * ```typescript
 * mclog('my Message');
 * ```
 */
export function mclog(msg, ...categories) {
    mc.world.getPlayers({ tags: [GlobalNamespace.Namespace + 'dev', ...categories
                .map(category => GlobalNamespace.Namespace + category)] })
        .forEach((player) => player.sendMessage({ rawtext: [{ text: `§b${String(msg)}` }] }));
    console.log("\x1b[36m", getTimeStamp(), `(${[GlobalNamespace.NamespaceUnformatted, ...categories].join(", ")})`, String(msg), "\x1B[0m");
}
/**
 * @remarks Prints a warning to players with the dev tag.
 * @param msg The message to print as a string.
 * @param categories Optional additional tags a player must have to see the message.
 * @example
 * ```typescript
 * mclog('my Warning');
 * ```
 */
export function mcwarn(msg, ...categories) {
    mc.world.getPlayers({ tags: [GlobalNamespace.Namespace + 'dev', ...categories
                .map(category => GlobalNamespace.Namespace + category)] })
        .forEach((player) => player.sendMessage({ rawtext: [{ text: `§e${String(msg)}` }] }));
    console.log("\x1B[33m", getTimeStamp(), `(${[GlobalNamespace.NamespaceUnformatted, ...categories].join(", ")})`, String(msg), "\x1B[0m");
}
/**
 * @remarks Prints an error to players with the dev tag.
 * @param msg The message to print as a string.
 * @param categories Optional additional tags a player must have to see the message.
 * @example
 * ```typescript
 * mclog('my Error');
 * ```
 */
export function mcerror(msg, ...categories) {
    mc.world.getPlayers({ tags: [GlobalNamespace.Namespace + 'dev', ...categories
                .map(category => GlobalNamespace.Namespace + category)] })
        .forEach((player) => player.sendMessage({ rawtext: [{ text: `§c${String(msg)}` }] }));
    console.log("\x1B[31m", getTimeStamp(), `(${[GlobalNamespace.NamespaceUnformatted, ...categories].join(", ")})`, String(msg), "\x1B[0m");
}
