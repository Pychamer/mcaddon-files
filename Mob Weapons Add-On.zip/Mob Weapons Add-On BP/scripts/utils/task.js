import { abortEvents } from "./events";
import { mclog, mcwarn, mcerror } from "./log";
export var TaskOutcome;
(function (TaskOutcome) {
    TaskOutcome["Succeeded"] = "succeeded";
    TaskOutcome["Failed"] = "failed";
    TaskOutcome["Aborted"] = "aborted";
})(TaskOutcome || (TaskOutcome = {}));
;
/**
 * @remarks The base class for tasks, this should be extended from when creating new tasks.
 * @template A The type of actor that will perform the task.
 * @template T The type of options that the task will accept.
 * @template R The type of result that the task will return.
 */
export class Task {
    /**
     * @remarks Returns the current task for the actor, or undefined if there is no task.
     * @param actor The actor to check the task for.
     * @returns The current task for the actor, or undefined if there is no task.
     */
    static getCurrentTask(actor) {
        var _a;
        return (_a = Task.taskMap.get(actor.id)) === null || _a === void 0 ? void 0 : _a.currentTask;
    }
    static setCurrentTask(actor, task) {
        if (Task.taskMap.has(actor.id)) {
            Task.taskMap.get(actor.id).currentTask = task;
        }
        else {
            Task.taskMap.set(actor.id, { currentTask: task });
        }
    }
    static setQueuedTask(actor, task) {
        if (Task.taskMap.has(actor.id)) {
            Task.taskMap.get(actor.id).queuedTask = task;
        }
        else {
            Task.taskMap.set(actor.id, { queuedTask: task });
        }
    }
    static getQueuedTask(actor) {
        var _a;
        return (_a = Task.taskMap.get(actor.id)) === null || _a === void 0 ? void 0 : _a.queuedTask;
    }
    /**
     * @remarks Sets a default task for the actor. This task will be started if the current task finishes and there is no queued task.
     * @param actor The actor to set the default task for.
     * @param task The task that should be set as the default.
     * @example
     * ```ts
     * new Task(actor, options).start();
     * ```
     */
    static setDefaultTask(actor, task) {
        mclog(`Setting default task for ${actor.id} to ${task === null || task === void 0 ? void 0 : task.id}`, "task");
        if (Task.taskMap.has(actor.id)) {
            Task.taskMap.get(actor.id).defaultTask = task;
        }
        else {
            Task.taskMap.set(actor.id, { defaultTask: task });
        }
    }
    /**
     * @remarks The status of this task. This can be:
     * - `pending` (the class has been created but start has not been caled),
     * - `running` (start has been called but has not resolved yet),
     * - `aborting` (the task is in the process of aborting),
     * - `result object` (The object containing the outcome of the task and any optional data it returned).
     */
    get Status() {
        return this.status;
    }
    /**
     * @remarks True if the task is in the process of aborting.
     */
    get Aborting() {
        return this.Status === "aborting";
    }
    /**
     * @remarks The actor that is performing this task.
     */
    get Actor() {
        return this.actor;
    }
    /**
     * @remarks The id that should be used for aborts, a combination of the actor id and the task id.
     * @example
     * ```ts
     * await waitForTick(100, this.EventId);
     * ```
     */
    get EventId() {
        return this.actor.id + this.id;
    }
    get ChainPosition() {
        return this.parentTask ? `Child of (${this.parentTask.id}: ${this.parentTask.index})` : "Root";
    }
    /**
     * @remarks Creates a new instance of a task. Note that creating a task does not automatically execute it, the {@link start} method must be called.
     * @param actor The actor who should perform this task.
     * @param options Any additional options the task needs.
     * @param parentTask The parent task if this task is being called by another task.
     */
    constructor(actor, options, parentTask) {
        this.id = this.constructor.name;
        this.status = "pending";
        this.actor = actor;
        this.index = Task.TaskIndex++;
        this.options = options;
        this.parentTask = parentTask;
    }
    /**
     * @remarks Starts the task. This method **should not be overridden**, the {@link perform} method should be overridden instead.
     * @returns The result of the task.
     */
    async start() {
        var _a;
        if (!this.Actor.isValid())
            return { outcome: TaskOutcome.Failed };
        // Attempting to start a task while another is queued
        const queuedTask = Task.getQueuedTask(this.actor);
        if (queuedTask) {
            if ((queuedTask === null || queuedTask === void 0 ? void 0 : queuedTask.id) === this.id) {
                mcwarn(`Task ${queuedTask.ChainPosition} (${queuedTask.id}: ${queuedTask.index}) is already queued`, "task");
                return { outcome: TaskOutcome.Aborted };
            }
            else {
                mcwarn(`Task ${queuedTask.ChainPosition} (${queuedTask.id}: ${queuedTask.index}) is queued, replacing with ${this.id}`, "task");
                Task.setQueuedTask(this.actor, this);
            }
        }
        if (Task.taskMap.has(this.actor.id) && !this.parentTask) {
            // If the actor is already running a task and this task is not a child of that task, we need to abort the current task.
            const existingTask = (_a = Task.taskMap.get(this.actor.id)) === null || _a === void 0 ? void 0 : _a.currentTask;
            if (existingTask) {
                if (existingTask.id !== this.id) {
                    mclog(`Aborting ${existingTask.ChainPosition} (${existingTask.id}: ${existingTask.index}) in order to start (${this.id}: ${this.index})`, "task");
                    Task.setQueuedTask(this.actor, this);
                    await existingTask.abort();
                    // Queued task was replaced by another task during the abort
                    if (Task.getQueuedTask(this.actor) !== this) {
                        return { outcome: TaskOutcome.Aborted };
                    }
                }
                else {
                    mcwarn(`Task ${this.ChainPosition} (${existingTask.id}: ${existingTask.index}) is already running`, "task");
                    return existingTask.status;
                }
            }
        }
        else if (this.parentTask && this.parentTask.childTask) {
            // If this task is a child of another task and that task already has a child task, we need to abort the sibling task.
            const siblingTask = this.parentTask.childTask;
            mclog(`Aborting ${siblingTask.ChainPosition} (${siblingTask.id}: ${siblingTask.index}) in order to start (${this.id}: ${this.index})`, "task");
            await this.parentTask.removeChildTask();
        }
        mclog(`${this.Actor.id} Starting ${this.ChainPosition} Task (${this.id}: ${this.index})`, "task");
        this.status = "running";
        if (!this.parentTask) {
            Task.setQueuedTask(this.actor, undefined);
            Task.setCurrentTask(this.actor, this);
        }
        else {
            this.parentTask.setChildTask(this);
        }
        this.promise = new Promise(resolve => {
            this.perform().then(res => {
                // Perform the task and return the result
                mclog(`${this.ChainPosition} Task (${this.id}: ${this.index}) ${res.outcome}`, "task");
                this.status = res;
                resolve(this.status);
            }).catch(err => {
                // Some error occurred while performing the task, possibly due to an abort
                if (!this.Aborting) {
                    // Only show error if task was not aborted externally, i.e. another task is replacing this one
                    mcerror(`${this.ChainPosition} Task (${this.id}: ${this.index}) aborted [${err}]`, "task");
                    this.status = "aborting";
                }
                // Handle cleanup and resolve any cleanup errors
                this.cleanup().then(() => {
                    mclog(`${this.ChainPosition} Task (${this.id}: ${this.index}) cleanup complete`, "task");
                }).catch(err => {
                    mcerror(`${this.ChainPosition} Task (${this.id}: ${this.index}) cleanup failed [${err}]`, "task");
                }).then(() => {
                    this.status = { outcome: TaskOutcome.Aborted };
                    resolve(this.status);
                });
            });
        });
        // Once the task is completed or aborted, we start the default task if there is one and we have no queued task.
        this.promise.then(() => {
            if (!this.parentTask) {
                Task.setCurrentTask(this.actor, undefined);
                const data = Task.taskMap.get(this.actor.id);
                if (!data.queuedTask && data.defaultTask && this.Actor.isValid()) {
                    mclog(`Starting default task for ${this.actor.id}`, "task");
                    data.defaultTask.start();
                }
            }
            else {
                this.parentTask.childTask = undefined;
            }
        });
        return this.promise;
    }
    /**
     * @remarks Aborts the task, this will abort any subtasks as well and perform the {@link cleanup} method of all of the subtasks, then itself.
     * This method **should not be overridden**, you should override the {@link cleanup} method instead.
     */
    async abort() {
        if (this.Status !== "running") {
            mcwarn(`${this.ChainPosition} Task (${this.id}: ${this.index}) is not running, no need to abort`, "task");
            return;
        }
        this.status = "aborting";
        abortEvents(this.EventId);
        if (this.childTask) {
            mclog(`${this.ChainPosition} Task (${this.id}: ${this.index}) aborting child (${this.childTask.id}: ${this.childTask.index})`, "task");
            await this.childTask.abort();
        }
        if (this.promise) {
            mclog(`${this.ChainPosition} Task (${this.id}: ${this.index}) awaiting cleanup`, "task");
            await this.promise;
        }
    }
    /**
     * @remarks Performs cleanup on this task, this will be called automatically when aborting. This should be overridden when creating a new Task class.
     * @returns A promise that resolves when the cleanup is complete.
     */
    async cleanup() { }
    /**
     * @remarks The core logic of the task, called from the {@link start} method. This should be overriden when creating a new Task class.
     * @returns A promise that resolves to the result of the task.
     */
    async perform() {
        return { outcome: TaskOutcome.Succeeded };
    }
    /**
     * @remarks Can be used within the {@link perform} method to throw an error if the task is aborted or should abort. Should be called after any async calls to ensure the task is still valid.
     * @throws Error if the task is aborted or the actor is not valid.
     * @example
     * ```ts
     * protected async perform() {
     *   await waitForTick(100, this.EventId);
     *   this.abortThrow();
     *   return { outcome: TaskOutcome.Succeeded };
     * }
     * ```
     */
    abortThrow() {
        if (!this.Actor.isValid()) {
            throw new Error(`Actor ${this.Actor.id} is not valid`);
        }
        if (this.Aborting) {
            throw new Error("Task was aborted");
        }
    }
    /**
     * @remarks Reassigns the actor to a new one. This is useful if the actor is changed during the task (i.e. they use the `minecraft:transform` event to become a new entity).
     * @param actor The actor that becomes associated with this task.
     */
    reassignActor(actor) {
        if (Task.taskMap.has(this.actor.id) && !this.parentTask) {
            Task.taskMap.set(actor.id, Task.taskMap.get(this.actor.id));
            Task.taskMap.delete(this.actor.id);
        }
        mclog(`${actor.id} Inherited ${this.ChainPosition} Task (${this.id}: ${this.index})`, "task");
        this.actor = actor;
    }
    async setChildTask(task) {
        this.removeChildTask();
        this.childTask = task;
        return this.childTask;
    }
    async removeChildTask() {
        if (this.childTask) {
            await this.childTask.abort();
            this.childTask = undefined;
        }
    }
}
Task.taskMap = new Map();
Task.TaskIndex = 0;
