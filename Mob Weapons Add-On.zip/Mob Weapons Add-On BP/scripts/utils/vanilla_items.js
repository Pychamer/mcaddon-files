export const VANILLA_ITEMS = {
    "minecraft:acacia_boat": {
        "langKey": "item.boat.acacia.name"
    },
    "minecraft:acacia_button": {
        "langKey": "tile.acacia_button.name"
    },
    "minecraft:acacia_chest_boat": {
        "langKey": "item.chest_boat.acacia.name"
    },
    "minecraft:acacia_door": {
        "langKey": "item.acacia_door.name"
    },
    "minecraft:acacia_fence": {
        "langKey": "tile.acaciaFence.name"
    },
    "minecraft:acacia_fence_gate": {
        "langKey": "tile.acacia_fence_gate.name"
    },
    "minecraft:acacia_hanging_sign": {
        "langKey": "item.acacia_hanging_sign.name"
    },
    "minecraft:acacia_leaves": {
        "langKey": "tile.leaves.acacia.name"
    },
    "minecraft:acacia_log": {
        "langKey": "tile.log.acacia.name"
    },
    "minecraft:acacia_planks": {
        "langKey": "tile.planks.acacia.name"
    },
    "minecraft:acacia_pressure_plate": {
        "langKey": "tile.acacia_pressure_plate.name"
    },
    "minecraft:acacia_sapling": {
        "langKey": "tile.sapling.acacia.name"
    },
    "minecraft:acacia_sign": {
        "langKey": "item.acacia_sign.name"
    },
    "minecraft:acacia_slab": {
        "langKey": "tile.wooden_slab.acacia.name"
    },
    "minecraft:acacia_stairs": {
        "langKey": "tile.acacia_stairs.name"
    },
    "minecraft:acacia_trapdoor": {
        "langKey": "tile.acacia_trapdoor.name"
    },
    "minecraft:acacia_wood": {
        "langKey": "tile.wood.acacia.name"
    },
    "minecraft:activator_rail": {
        "langKey": "tile.activator_rail.name"
    },
    "minecraft:allay_spawn_egg": {
        "langKey": "item.spawn_egg.entity.allay.name"
    },
    "minecraft:allium": {
        "langKey": "tile.red_flower.allium.name"
    },
    "minecraft:allow": {
        "langKey": "tile.allow.name"
    },
    "minecraft:amethyst_block": {
        "langKey": "tile.amethyst_block.name"
    },
    "minecraft:amethyst_cluster": {
        "langKey": "tile.amethyst_cluster.name"
    },
    "minecraft:amethyst_shard": {
        "langKey": "item.amethyst_shard.name"
    },
    "minecraft:ancient_debris": {
        "langKey": "tile.ancient_debris.name"
    },
    "minecraft:andesite": {
        "langKey": "tile.stone.andesite.name"
    },
    "minecraft:andesite_slab": {
        "langKey": "tile.stone_slab3.andesite.name"
    },
    "minecraft:andesite_stairs": {
        "langKey": "tile.andesite_stairs.name"
    },
    "minecraft:andesite_wall": {
        "langKey": "tile.cobblestone_wall.andesite.name"
    },
    "minecraft:angler_pottery_shard": {
        "langKey": "item.angler_pottery_shard.name"
    },
    "minecraft:angler_pottery_sherd": {
        "langKey": "item.angler_pottery_sherd.name"
    },
    "minecraft:anvil": {
        "langKey": "tile.anvil.name"
    },
    "minecraft:apple": {
        "langKey": "item.apple.name"
    },
    "minecraft:archer_pottery_shard": {
        "langKey": "item.archer_pottery_shard.name"
    },
    "minecraft:archer_pottery_sherd": {
        "langKey": "item.archer_pottery_sherd.name"
    },
    "minecraft:armadillo_scute": {
        "langKey": "item.armadillo_scute.name"
    },
    "minecraft:armadillo_spawn_egg": {
        "langKey": "item.spawn_egg.entity.armadillo.name"
    },
    "minecraft:armor_stand": {
        "langKey": "item.armor_stand.name"
    },
    "minecraft:arms_up_pottery_shard": {
        "langKey": "item.arms_up_pottery_shard.name"
    },
    "minecraft:arms_up_pottery_sherd": {
        "langKey": "item.arms_up_pottery_sherd.name"
    },
    "minecraft:arrow": {
        "langKey": "item.arrow.name"
    },
    "minecraft:axolotl_bucket": {
        "langKey": "item.bucketAxolotl.name"
    },
    "minecraft:axolotl_spawn_egg": {
        "langKey": "item.spawn_egg.entity.axolotl.name"
    },
    "minecraft:azalea": {
        "langKey": "tile.azalea.name"
    },
    "minecraft:azalea_leaves": {
        "langKey": "tile.azalea_leaves.name"
    },
    "minecraft:azalea_leaves_flowered": {
        "langKey": "tile.azalea_leaves_flowered.name"
    },
    "minecraft:azure_bluet": {
        "langKey": "tile.red_flower.houstonia.name"
    },
    "minecraft:baked_potato": {
        "langKey": "item.baked_potato.name"
    },
    "minecraft:bamboo": {
        "langKey": "tile.bamboo.name"
    },
    "minecraft:bamboo_block": {
        "langKey": "tile.bamboo_block.name"
    },
    "minecraft:bamboo_button": {
        "langKey": "tile.bamboo_button.name"
    },
    "minecraft:bamboo_chest_raft": {
        "langKey": "item.chest_boat.bamboo.name"
    },
    "minecraft:bamboo_door": {
        "langKey": "item.bamboo_door.name"
    },
    "minecraft:bamboo_fence": {
        "langKey": "tile.bamboo_fence.name"
    },
    "minecraft:bamboo_fence_gate": {
        "langKey": "tile.bamboo_fence_gate.name"
    },
    "minecraft:bamboo_hanging_sign": {
        "langKey": "item.bamboo_hanging_sign.name"
    },
    "minecraft:bamboo_mosaic": {
        "langKey": "tile.bamboo_mosaic.name"
    },
    "minecraft:bamboo_mosaic_slab": {
        "langKey": "tile.bamboo_mosaic_slab.name"
    },
    "minecraft:bamboo_mosaic_stairs": {
        "langKey": "tile.bamboo_mosaic_stairs.name"
    },
    "minecraft:bamboo_planks": {
        "langKey": "tile.bamboo_planks.name"
    },
    "minecraft:bamboo_pressure_plate": {
        "langKey": "tile.bamboo_pressure_plate.name"
    },
    "minecraft:bamboo_raft": {
        "langKey": "item.boat.bamboo.name"
    },
    "minecraft:bamboo_sign": {
        "langKey": "item.bamboo_sign.name"
    },
    "minecraft:bamboo_slab": {
        "langKey": "tile.bamboo_slab.name"
    },
    "minecraft:bamboo_stairs": {
        "langKey": "tile.bamboo_stairs.name"
    },
    "minecraft:bamboo_trapdoor": {
        "langKey": "tile.bamboo_trapdoor.name"
    },
    "minecraft:banner": {
        "langKey": "item.banner.white.name"
    },
    "minecraft:barrel": {
        "langKey": "tile.barrel.name"
    },
    "minecraft:barrier": {
        "langKey": "tile.barrier.name"
    },
    "minecraft:basalt": {
        "langKey": "tile.basalt.name"
    },
    "minecraft:bat_spawn_egg": {
        "langKey": "item.spawn_egg.entity.bat.name"
    },
    "minecraft:beacon": {
        "langKey": "tile.beacon.name"
    },
    "minecraft:bed": {
        "langKey": "tile.bed.name"
    },
    "minecraft:bedrock": {
        "langKey": "tile.bedrock.name"
    },
    "minecraft:bee_nest": {
        "langKey": "tile.bee_nest.name"
    },
    "minecraft:bee_spawn_egg": {
        "langKey": "item.spawn_egg.entity.bee.name"
    },
    "minecraft:beef": {
        "langKey": "item.beef.name"
    },
    "minecraft:beehive": {
        "langKey": "tile.beehive.name"
    },
    "minecraft:beetroot": {
        "langKey": "item.beetroot.name"
    },
    "minecraft:beetroot_seeds": {
        "langKey": "item.beetroot_seeds.name"
    },
    "minecraft:beetroot_soup": {
        "langKey": "item.beetroot_soup.name"
    },
    "minecraft:bell": {
        "langKey": "item.bell.name"
    },
    "minecraft:big_dripleaf": {
        "langKey": "tile.big_dripleaf.name"
    },
    "minecraft:birch_boat": {
        "langKey": "item.boat.birch.name"
    },
    "minecraft:birch_button": {
        "langKey": "tile.birch_button.name"
    },
    "minecraft:birch_chest_boat": {
        "langKey": "item.chest_boat.birch.name"
    },
    "minecraft:birch_door": {
        "langKey": "item.birch_door.name"
    },
    "minecraft:birch_fence": {
        "langKey": "tile.birchFence.name"
    },
    "minecraft:birch_fence_gate": {
        "langKey": "tile.birch_fence_gate.name"
    },
    "minecraft:birch_hanging_sign": {
        "langKey": "item.birch_hanging_sign.name"
    },
    "minecraft:birch_leaves": {
        "langKey": "tile.leaves.birch.name"
    },
    "minecraft:birch_log": {
        "langKey": "tile.log.birch.name"
    },
    "minecraft:birch_planks": {
        "langKey": "tile.planks.birch.name"
    },
    "minecraft:birch_pressure_plate": {
        "langKey": "tile.birch_pressure_plate.name"
    },
    "minecraft:birch_sapling": {
        "langKey": "tile.sapling.birch.name"
    },
    "minecraft:birch_sign": {
        "langKey": "item.birch_sign.name"
    },
    "minecraft:birch_slab": {
        "langKey": "tile.wooden_slab.birch.name"
    },
    "minecraft:birch_stairs": {
        "langKey": "tile.birch_stairs.name"
    },
    "minecraft:birch_trapdoor": {
        "langKey": "tile.birch_trapdoor.name"
    },
    "minecraft:birch_wood": {
        "langKey": "tile.wood.birch.name"
    },
    "minecraft:black_bundle": {
        "langKey": "item.black_bundle"
    },
    "minecraft:black_candle": {
        "langKey": "tile.black_candle.name"
    },
    "minecraft:black_carpet": {
        "langKey": "tile.carpet.black.name"
    },
    "minecraft:black_concrete": {
        "langKey": "tile.concrete.black.name"
    },
    "minecraft:black_concrete_powder": {
        "langKey": "tile.concretePowder.black.name"
    },
    "minecraft:black_dye": {
        "langKey": "item.dye.black_new.name"
    },
    "minecraft:black_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.black.name"
    },
    "minecraft:black_shulker_box": {
        "langKey": "tile.shulkerBoxBlack.name"
    },
    "minecraft:black_stained_glass": {
        "langKey": "tile.stained_glass.black.name"
    },
    "minecraft:black_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.black.name"
    },
    "minecraft:black_terracotta": {
        "langKey": "tile.stained_hardened_clay.black.name"
    },
    "minecraft:black_wool": {
        "langKey": "tile.wool.black.name"
    },
    "minecraft:blackstone": {
        "langKey": "tile.blackstone.name"
    },
    "minecraft:blackstone_slab": {
        "langKey": "tile.blackstone_slab.name"
    },
    "minecraft:blackstone_stairs": {
        "langKey": "tile.blackstone_stairs.name"
    },
    "minecraft:blackstone_wall": {
        "langKey": "tile.blackstone_wall.name"
    },
    "minecraft:blade_pottery_shard": {
        "langKey": "item.blade_pottery_shard.name"
    },
    "minecraft:blade_pottery_sherd": {
        "langKey": "item.blade_pottery_sherd.name"
    },
    "minecraft:blast_furnace": {
        "langKey": "tile.blast_furnace.name"
    },
    "minecraft:blaze_powder": {
        "langKey": "item.blaze_powder.name"
    },
    "minecraft:blaze_rod": {
        "langKey": "item.blaze_rod.name"
    },
    "minecraft:blaze_spawn_egg": {
        "langKey": "item.spawn_egg.entity.blaze.name"
    },
    "minecraft:blue_bundle": {
        "langKey": "item.blue_bundle"
    },
    "minecraft:blue_candle": {
        "langKey": "tile.blue_candle.name"
    },
    "minecraft:blue_carpet": {
        "langKey": "tile.carpet.blue.name"
    },
    "minecraft:blue_concrete": {
        "langKey": "tile.concrete.blue.name"
    },
    "minecraft:blue_concrete_powder": {
        "langKey": "tile.concretePowder.blue.name"
    },
    "minecraft:blue_dye": {
        "langKey": "item.dye.blue_new.name"
    },
    "minecraft:blue_egg": {
        "langKey": "item.blue_egg.name"
    },
    "minecraft:blue_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.blue.name"
    },
    "minecraft:blue_ice": {
        "langKey": "tile.blue_ice.name"
    },
    "minecraft:blue_orchid": {
        "langKey": "tile.red_flower.blueOrchid.name"
    },
    "minecraft:blue_shulker_box": {
        "langKey": "tile.shulkerBoxBlue.name"
    },
    "minecraft:blue_stained_glass": {
        "langKey": "tile.stained_glass.blue.name"
    },
    "minecraft:blue_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.blue.name"
    },
    "minecraft:blue_terracotta": {
        "langKey": "tile.stained_hardened_clay.blue.name"
    },
    "minecraft:blue_wool": {
        "langKey": "tile.wool.blue.name"
    },
    "minecraft:bogged_spawn_egg": {
        "langKey": "item.spawn_egg.entity.bogged.name"
    },
    "minecraft:bolt_armor_trim_smithing_template": {
        "langKey": "item.bolt_armor_trim_smithing_template.name"
    },
    "minecraft:bone": {
        "langKey": "item.bone.name"
    },
    "minecraft:bone_block": {
        "langKey": "tile.bone_block.name"
    },
    "minecraft:bone_meal": {
        "langKey": "item.dye.white.name"
    },
    "minecraft:book": {
        "langKey": "item.book.name"
    },
    "minecraft:bookshelf": {
        "langKey": "tile.bookshelf.name"
    },
    "minecraft:border_block": {
        "langKey": "tile.border_block.name"
    },
    "minecraft:bordure_indented_banner_pattern": {
        "langKey": "item.banner_pattern.vines"
    },
    "minecraft:bow": {
        "langKey": "item.bow.name"
    },
    "minecraft:bowl": {
        "langKey": "item.bowl.name"
    },
    "minecraft:brain_coral": {
        "langKey": "tile.coral.pink.name"
    },
    "minecraft:brain_coral_block": {
        "langKey": "tile.coral_block.pink.name"
    },
    "minecraft:brain_coral_fan": {
        "langKey": "tile.coral_fan.pink_fan.name"
    },
    "minecraft:bread": {
        "langKey": "item.bread.name"
    },
    "minecraft:breeze_rod": {
        "langKey": "item.breeze_rod.name"
    },
    "minecraft:breeze_spawn_egg": {
        "langKey": "item.spawn_egg.entity.breeze.name"
    },
    "minecraft:brewer_pottery_shard": {
        "langKey": "item.brewer_pottery_shard.name"
    },
    "minecraft:brewer_pottery_sherd": {
        "langKey": "item.brewer_pottery_sherd.name"
    },
    "minecraft:brewing_stand": {
        "langKey": "item.brewing_stand.name"
    },
    "minecraft:brick": {
        "langKey": "item.brick.name"
    },
    "minecraft:brick_block": {
        "langKey": "tile.brick_block.name"
    },
    "minecraft:brick_slab": {
        "langKey": "tile.double_stone_slab.brick.name"
    },
    "minecraft:brick_stairs": {
        "langKey": "tile.brick_stairs.name"
    },
    "minecraft:brick_wall": {
        "langKey": "tile.cobblestone_wall.brick.name"
    },
    "minecraft:brown_bundle": {
        "langKey": "item.brown_bundle"
    },
    "minecraft:brown_candle": {
        "langKey": "tile.brown_candle.name"
    },
    "minecraft:brown_carpet": {
        "langKey": "tile.carpet.brown.name"
    },
    "minecraft:brown_concrete": {
        "langKey": "tile.concrete.brown.name"
    },
    "minecraft:brown_concrete_powder": {
        "langKey": "tile.concretePowder.brown.name"
    },
    "minecraft:brown_dye": {
        "langKey": "item.dye.brown_new.name"
    },
    "minecraft:brown_egg": {
        "langKey": "item.brown_egg.name"
    },
    "minecraft:brown_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.brown.name"
    },
    "minecraft:brown_mushroom": {
        "langKey": "tile.brown_mushroom.name"
    },
    "minecraft:brown_mushroom_block": {
        "langKey": "tile.brown_mushroom_block.stem.name"
    },
    "minecraft:brown_shulker_box": {
        "langKey": "tile.shulkerBoxBrown.name"
    },
    "minecraft:brown_stained_glass": {
        "langKey": "tile.stained_glass.brown.name"
    },
    "minecraft:brown_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.brown.name"
    },
    "minecraft:brown_terracotta": {
        "langKey": "tile.stained_hardened_clay.brown.name"
    },
    "minecraft:brown_wool": {
        "langKey": "tile.wool.brown.name"
    },
    "minecraft:brush": {
        "langKey": "item.brush.name"
    },
    "minecraft:bubble_coral": {
        "langKey": "tile.coral.purple.name"
    },
    "minecraft:bubble_coral_block": {
        "langKey": "tile.coral_block.purple.name"
    },
    "minecraft:bubble_coral_fan": {
        "langKey": "tile.coral_fan.purple_fan.name"
    },
    "minecraft:bucket": {
        "langKey": "item.bucket.name"
    },
    "minecraft:budding_amethyst": {
        "langKey": "tile.budding_amethyst.name"
    },
    "minecraft:bundle": {
        "langKey": "item.bundle"
    },
    "minecraft:burn_pottery_shard": {
        "langKey": "item.burn_pottery_shard.name"
    },
    "minecraft:burn_pottery_sherd": {
        "langKey": "item.burn_pottery_sherd.name"
    },
    "minecraft:bush": {
        "langKey": "tile.bush.name"
    },
    "minecraft:cactus": {
        "langKey": "tile.cactus.name"
    },
    "minecraft:cactus_flower": {
        "langKey": "tile.cactus_flower.name"
    },
    "minecraft:cake": {
        "langKey": "item.cake.name"
    },
    "minecraft:calcite": {
        "langKey": "tile.calcite.name"
    },
    "minecraft:calibrated_sculk_sensor": {
        "langKey": "tile.calibrated_sculk_sensor.name"
    },
    "minecraft:camel_spawn_egg": {
        "langKey": "item.spawn_egg.entity.camel.name"
    },
    "minecraft:campfire": {
        "langKey": "tile.campfire.name"
    },
    "minecraft:candle": {
        "langKey": "tile.candle.name"
    },
    "minecraft:carrot": {
        "langKey": "item.carrot.name"
    },
    "minecraft:carrot_on_a_stick": {
        "langKey": "item.carrotOnAStick.name"
    },
    "minecraft:cartography_table": {
        "langKey": "tile.cartography_table.name"
    },
    "minecraft:carved_pumpkin": {
        "langKey": "tile.carved_pumpkin.name"
    },
    "minecraft:cat_spawn_egg": {
        "langKey": "item.spawn_egg.entity.cat.name"
    },
    "minecraft:cauldron": {
        "langKey": "item.cauldron.name"
    },
    "minecraft:cave_spider_spawn_egg": {
        "langKey": "item.spawn_egg.entity.cave_spider.name"
    },
    "minecraft:chain": {
        "langKey": "tile.chain.name"
    },
    "minecraft:chain_command_block": {
        "langKey": "tile.chain_command_block.name"
    },
    "minecraft:chainmail_boots": {
        "langKey": "item.chainmail_boots.name"
    },
    "minecraft:chainmail_chestplate": {
        "langKey": "item.chainmail_chestplate.name"
    },
    "minecraft:chainmail_helmet": {
        "langKey": "item.chainmail_helmet.name"
    },
    "minecraft:chainmail_leggings": {
        "langKey": "item.chainmail_leggings.name"
    },
    "minecraft:charcoal": {
        "langKey": "item.charcoal.name"
    },
    "minecraft:cherry_boat": {
        "langKey": "item.boat.cherry.name"
    },
    "minecraft:cherry_button": {
        "langKey": "tile.cherry_button.name"
    },
    "minecraft:cherry_chest_boat": {
        "langKey": "item.chest_boat.cherry.name"
    },
    "minecraft:cherry_door": {
        "langKey": "item.cherry_door.name"
    },
    "minecraft:cherry_fence": {
        "langKey": "tile.cherry_fence.name"
    },
    "minecraft:cherry_fence_gate": {
        "langKey": "tile.cherry_fence_gate.name"
    },
    "minecraft:cherry_hanging_sign": {
        "langKey": "item.cherry_hanging_sign.name"
    },
    "minecraft:cherry_leaves": {
        "langKey": "tile.cherry_leaves.name"
    },
    "minecraft:cherry_log": {
        "langKey": "tile.cherry_log.name"
    },
    "minecraft:cherry_planks": {
        "langKey": "tile.cherry_planks.name"
    },
    "minecraft:cherry_pressure_plate": {
        "langKey": "tile.cherry_pressure_plate.name"
    },
    "minecraft:cherry_sapling": {
        "langKey": "tile.cherry_sapling.name"
    },
    "minecraft:cherry_sign": {
        "langKey": "item.cherry_sign.name"
    },
    "minecraft:cherry_slab": {
        "langKey": "tile.cherry_slab.name"
    },
    "minecraft:cherry_stairs": {
        "langKey": "tile.cherry_stairs.name"
    },
    "minecraft:cherry_trapdoor": {
        "langKey": "tile.cherry_trapdoor.name"
    },
    "minecraft:cherry_wood": {
        "langKey": "tile.cherry_wood.name"
    },
    "minecraft:chest": {
        "langKey": "tile.chest.name"
    },
    "minecraft:chest_minecart": {
        "langKey": "item.chest_minecart.name"
    },
    "minecraft:chicken": {
        "langKey": "item.chicken.name"
    },
    "minecraft:chicken_spawn_egg": {
        "langKey": "item.spawn_egg.entity.chicken.name"
    },
    "minecraft:chipped_anvil": {
        "langKey": "tile.anvil.slightlyDamaged.name"
    },
    "minecraft:chiseled_bookshelf": {
        "langKey": "tile.chiseled_bookshelf.name"
    },
    "minecraft:chiseled_copper": {
        "langKey": "tile.chiseled_copper.name"
    },
    "minecraft:chiseled_deepslate": {
        "langKey": "tile.chiseled_deepslate.name"
    },
    "minecraft:chiseled_nether_bricks": {
        "langKey": "tile.chiseled_nether_bricks.name"
    },
    "minecraft:chiseled_polished_blackstone": {
        "langKey": "tile.chiseled_polished_blackstone.name"
    },
    "minecraft:chiseled_quartz_block": {
        "langKey": "tile.quartz_block.chiseled.name"
    },
    "minecraft:chiseled_red_sandstone": {
        "langKey": "tile.red_sandstone.chiseled.name"
    },
    "minecraft:chiseled_resin_bricks": {
        "langKey": "tile.chiseled_resin_bricks.name"
    },
    "minecraft:chiseled_sandstone": {
        "langKey": "tile.sandstone.chiseled.name"
    },
    "minecraft:chiseled_stone_bricks": {
        "langKey": "tile.stonebrick.chiseled.name"
    },
    "minecraft:chiseled_tuff": {
        "langKey": "tile.chiseled_tuff.name"
    },
    "minecraft:chiseled_tuff_bricks": {
        "langKey": "tile.chiseled_tuff_bricks.name"
    },
    "minecraft:chorus_flower": {
        "langKey": "tile.chorus_flower.name"
    },
    "minecraft:chorus_fruit": {
        "langKey": "item.chorus_fruit.name"
    },
    "minecraft:chorus_plant": {
        "langKey": "tile.chorus_plant.name"
    },
    "minecraft:clay": {
        "langKey": "tile.clay.name"
    },
    "minecraft:clay_ball": {
        "langKey": "item.clay_ball.name"
    },
    "minecraft:clock": {
        "langKey": "item.clock.name"
    },
    "minecraft:closed_eyeblossom": {
        "langKey": "tile.closed_eyeblossom.name"
    },
    "minecraft:coal": {
        "langKey": "item.coal.name"
    },
    "minecraft:coal_block": {
        "langKey": "tile.coal_block.name"
    },
    "minecraft:coal_ore": {
        "langKey": "tile.coal_ore.name"
    },
    "minecraft:coarse_dirt": {
        "langKey": "tile.dirt.coarse.name"
    },
    "minecraft:coast_armor_trim_smithing_template": {
        "langKey": "trim_pattern.coast.name"
    },
    "minecraft:cobbled_deepslate": {
        "langKey": "tile.cobbled_deepslate.name"
    },
    "minecraft:cobbled_deepslate_slab": {
        "langKey": "tile.cobbled_deepslate_slab.name"
    },
    "minecraft:cobbled_deepslate_stairs": {
        "langKey": "tile.cobbled_deepslate_stairs.name"
    },
    "minecraft:cobbled_deepslate_wall": {
        "langKey": "tile.cobbled_deepslate_wall.name"
    },
    "minecraft:cobblestone": {
        "langKey": "tile.cobblestone.name"
    },
    "minecraft:cobblestone_slab": {
        "langKey": "tile.double_stone_slab.cobble.name"
    },
    "minecraft:cobblestone_wall": {
        "langKey": "tile.cobblestone_wall.red_nether_brick.name"
    },
    "minecraft:cocoa_beans": {
        "langKey": "item.dye.brown.name"
    },
    "minecraft:cod": {
        "langKey": "item.fish.name"
    },
    "minecraft:cod_bucket": {
        "langKey": "item.bucketFish.name"
    },
    "minecraft:cod_spawn_egg": {
        "langKey": "item.spawn_egg.entity.cod.name"
    },
    "minecraft:command_block": {
        "langKey": "tile.command_block.name"
    },
    "minecraft:command_block_minecart": {
        "langKey": "item.command_block_minecart.name"
    },
    "minecraft:comparator": {
        "langKey": "item.comparator.name"
    },
    "minecraft:compass": {
        "langKey": "item.compass.name"
    },
    "minecraft:composter": {
        "langKey": "tile.composter.name"
    },
    "minecraft:concrete": {
        "langKey": "tile.concrete.black.name"
    },
    "minecraft:concrete_powder": {
        "langKey": "tile.concretePowder.black.name"
    },
    "minecraft:conduit": {
        "langKey": "tile.conduit.name"
    },
    "minecraft:cooked_beef": {
        "langKey": "item.cooked_beef.name"
    },
    "minecraft:cooked_chicken": {
        "langKey": "item.cooked_chicken.name"
    },
    "minecraft:cooked_cod": {
        "langKey": "item.cooked_fish.name"
    },
    "minecraft:cooked_mutton": {
        "langKey": "item.muttonCooked.name"
    },
    "minecraft:cooked_porkchop": {
        "langKey": "item.cooked_porkchop.name"
    },
    "minecraft:cooked_rabbit": {
        "langKey": "item.cooked_rabbit.name"
    },
    "minecraft:cooked_salmon": {
        "langKey": "item.cooked_salmon.name"
    },
    "minecraft:cookie": {
        "langKey": "item.cookie.name"
    },
    "minecraft:copper_block": {
        "langKey": "tile.copper_block.name"
    },
    "minecraft:copper_bulb": {
        "langKey": "tile.copper_bulb.name"
    },
    "minecraft:copper_door": {
        "langKey": "item.copper_door.name"
    },
    "minecraft:copper_grate": {
        "langKey": "tile.copper_grate.name"
    },
    "minecraft:copper_ingot": {
        "langKey": "item.copper_ingot.name"
    },
    "minecraft:copper_ore": {
        "langKey": "tile.copper_ore.name"
    },
    "minecraft:copper_trapdoor": {
        "langKey": "tile.copper_trapdoor.name"
    },
    "minecraft:coral_block": {
        "langKey": "tile.coral_block.yellow_dead.name"
    },
    "minecraft:coral_fan": {
        "langKey": "tile.corafan.yellow_fan.name"
    },
    "minecraft:coral_fan_dead": {
        "langKey": "tile.coral_fan_dead.yellow_fan.name"
    },
    "minecraft:cornflower": {
        "langKey": "tile.red_flower.cornflower.name"
    },
    "minecraft:cow_spawn_egg": {
        "langKey": "item.spawn_egg.entity.cow.name"
    },
    "minecraft:cracked_deepslate_bricks": {
        "langKey": "tile.cracked_deepslate_bricks.name"
    },
    "minecraft:cracked_deepslate_tiles": {
        "langKey": "tile.cracked_deepslate_tiles.name"
    },
    "minecraft:cracked_nether_bricks": {
        "langKey": "tile.cracked_nether_bricks.name"
    },
    "minecraft:cracked_polished_blackstone_bricks": {
        "langKey": "tile.cracked_polished_blackstone_bricks.name"
    },
    "minecraft:cracked_stone_bricks": {
        "langKey": "tile.stonebrick.cracked.name"
    },
    "minecraft:crafter": {
        "langKey": "tile.crafter.name"
    },
    "minecraft:crafting_table": {
        "langKey": "tile.crafting_table.name"
    },
    "minecraft:creaking_heart": {
        "langKey": "tile.creaking_heart.name"
    },
    "minecraft:creaking_spawn_egg": {
        "langKey": "item.spawn_egg.entity.creaking.name"
    },
    "minecraft:creeper_banner_pattern": {
        "langKey": "item.banner_pattern.creeper"
    },
    "minecraft:creeper_head": {
        "langKey": "item.skull.creeper.name"
    },
    "minecraft:creeper_spawn_egg": {
        "langKey": "item.spawn_egg.entity.creeper.name"
    },
    "minecraft:crimson_button": {
        "langKey": "tile.crimson_button.name"
    },
    "minecraft:crimson_door": {
        "langKey": "item.crimson_door.name"
    },
    "minecraft:crimson_fence": {
        "langKey": "tile.crimson_fence.name"
    },
    "minecraft:crimson_fence_gate": {
        "langKey": "tile.crimson_fence_gate.name"
    },
    "minecraft:crimson_fungus": {
        "langKey": "tile.crimson_fungus.name"
    },
    "minecraft:crimson_hanging_sign": {
        "langKey": "item.crimson_hanging_sign.name"
    },
    "minecraft:crimson_hyphae": {
        "langKey": "tile.crimson_hyphae.name"
    },
    "minecraft:crimson_nylium": {
        "langKey": "tile.crimson_nylium.name"
    },
    "minecraft:crimson_planks": {
        "langKey": "tile.crimson_planks.name"
    },
    "minecraft:crimson_pressure_plate": {
        "langKey": "tile.crimson_pressure_plate.name"
    },
    "minecraft:crimson_roots": {
        "langKey": "tile.crimson_roots.crimsonRoots.name"
    },
    "minecraft:crimson_sign": {
        "langKey": "item.crimson_sign.name"
    },
    "minecraft:crimson_slab": {
        "langKey": "tile.crimson_slab.name"
    },
    "minecraft:crimson_stairs": {
        "langKey": "tile.crimson_stairs.name"
    },
    "minecraft:crimson_stem": {
        "langKey": "tile.crimson_stem.name"
    },
    "minecraft:crimson_trapdoor": {
        "langKey": "tile.crimson_trapdoor.name"
    },
    "minecraft:crossbow": {
        "langKey": "item.crossbow.name"
    },
    "minecraft:crying_obsidian": {
        "langKey": "tile.crying_obsidian.name"
    },
    "minecraft:cut_copper": {
        "langKey": "tile.cut_copper.name"
    },
    "minecraft:cut_copper_slab": {
        "langKey": "tile.cut_copper_slab.name"
    },
    "minecraft:cut_copper_stairs": {
        "langKey": "tile.cut_copper_stairs.name"
    },
    "minecraft:cut_red_sandstone": {
        "langKey": "tile.red_sandstone.cut.name"
    },
    "minecraft:cut_red_sandstone_slab": {
        "langKey": "tile.stone_slab4.cut_red_sandstone.name"
    },
    "minecraft:cut_sandstone": {
        "langKey": "tile.sandstone.cut.name"
    },
    "minecraft:cut_sandstone_slab": {
        "langKey": "tile.stone_slab4.cut_sandstone.name"
    },
    "minecraft:cyan_bundle": {
        "langKey": "item.cyan_bundle"
    },
    "minecraft:cyan_candle": {
        "langKey": "tile.cyan_candle.name"
    },
    "minecraft:cyan_carpet": {
        "langKey": "tile.carpet.cyan.name"
    },
    "minecraft:cyan_concrete": {
        "langKey": "tile.concrete.cyan.name"
    },
    "minecraft:cyan_concrete_powder": {
        "langKey": "tile.concretePowder.cyan.name"
    },
    "minecraft:cyan_dye": {
        "langKey": "item.dye.cyan.name"
    },
    "minecraft:cyan_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.cyan.name"
    },
    "minecraft:cyan_shulker_box": {
        "langKey": "tile.shulkerBoxCyan.name"
    },
    "minecraft:cyan_stained_glass": {
        "langKey": "tile.stained_glass.cyan.name"
    },
    "minecraft:cyan_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.cyan.name"
    },
    "minecraft:cyan_terracotta": {
        "langKey": "tile.stained_hardened_clay.cyan.name"
    },
    "minecraft:cyan_wool": {
        "langKey": "tile.wool.cyan.name"
    },
    "minecraft:damaged_anvil": {
        "langKey": "tile.anvil.veryDamaged.name"
    },
    "minecraft:dandelion": {
        "langKey": "tile.yellow_flower.dandelion.name"
    },
    "minecraft:danger_pottery_shard": {
        "langKey": "item.danger_pottery_shard.name"
    },
    "minecraft:danger_pottery_sherd": {
        "langKey": "item.danger_pottery_sherd.name"
    },
    "minecraft:dark_oak_boat": {
        "langKey": "item.boat.big_oak.name"
    },
    "minecraft:dark_oak_button": {
        "langKey": "tile.dark_oak_button.name"
    },
    "minecraft:dark_oak_chest_boat": {
        "langKey": "item.boat.big_oak.name"
    },
    "minecraft:dark_oak_door": {
        "langKey": "item.dark_oak_door.name"
    },
    "minecraft:dark_oak_fence": {
        "langKey": "tile.darkOakFence.name"
    },
    "minecraft:dark_oak_fence_gate": {
        "langKey": "tile.dark_oak_fence_gate.name"
    },
    "minecraft:dark_oak_hanging_sign": {
        "langKey": "item.dark_oak_hanging_sign.name"
    },
    "minecraft:dark_oak_leaves": {
        "langKey": "tile.leaves.big_oak.name"
    },
    "minecraft:dark_oak_log": {
        "langKey": "tile.log.big_oak.name"
    },
    "minecraft:dark_oak_planks": {
        "langKey": "tile.planks.big_oak.name"
    },
    "minecraft:dark_oak_pressure_plate": {
        "langKey": "tile.dark_oak_pressure_plate.name"
    },
    "minecraft:dark_oak_sapling": {
        "langKey": "tile.sapling.big_oak.name"
    },
    "minecraft:dark_oak_sign": {
        "langKey": "item.darkoak_sign.name"
    },
    "minecraft:dark_oak_slab": {
        "langKey": "tile.wooden_slab.big_oak.name"
    },
    "minecraft:dark_oak_stairs": {
        "langKey": "tile.dark_oak_stairs.name"
    },
    "minecraft:dark_oak_trapdoor": {
        "langKey": "tile.dark_oak_trapdoor.name"
    },
    "minecraft:dark_oak_wood": {
        "langKey": "tile.wood.dark_oak.name"
    },
    "minecraft:dark_prismarine": {
        "langKey": "tile.prismarine.dark.name"
    },
    "minecraft:dark_prismarine_slab": {
        "langKey": "tile.stone_slab2.prismarine.dark.name"
    },
    "minecraft:dark_prismarine_stairs": {
        "langKey": "tile.dark_prismarine_stairs.name"
    },
    "minecraft:daylight_detector": {
        "langKey": "tile.daylight_detector.name"
    },
    "minecraft:dead_brain_coral": {
        "langKey": "tile.coral.pink_dead.name"
    },
    "minecraft:dead_brain_coral_block": {
        "langKey": "tile.coral_block.pink_dead.name"
    },
    "minecraft:dead_brain_coral_fan": {
        "langKey": "tile.coral_fan.pink_fan.name"
    },
    "minecraft:dead_bubble_coral": {
        "langKey": "tile.coral.purple_dead.name"
    },
    "minecraft:dead_bubble_coral_block": {
        "langKey": "tile.coral_block.purple.dead.name"
    },
    "minecraft:dead_bubble_coral_fan": {
        "langKey": "tile.coral_fan_dead.purple_fan.name"
    },
    "minecraft:dead_fire_coral": {
        "langKey": "tile.coral.red_dead.name"
    },
    "minecraft:dead_fire_coral_block": {
        "langKey": "tile.coral_block.red_dead.name"
    },
    "minecraft:dead_fire_coral_fan": {
        "langKey": "tile.coral_fan_dead.red_fan.name"
    },
    "minecraft:dead_horn_coral": {
        "langKey": "tile.coral.yellow_dead.name"
    },
    "minecraft:dead_horn_coral_block": {
        "langKey": "tile.coral_block.yellow_dead.name"
    },
    "minecraft:dead_horn_coral_fan": {
        "langKey": "tile.coral_fan_dead.yellow_fan.name"
    },
    "minecraft:dead_tube_coral": {
        "langKey": "tile.coral_fan_dead.blue_fan.name"
    },
    "minecraft:dead_tube_coral_block": {
        "langKey": "tile.coral_block.blue_dead.name"
    },
    "minecraft:dead_tube_coral_fan": {
        "langKey": "tile.coral_fan_dead.blue_fan.name"
    },
    "minecraft:deadbush": {
        "langKey": "tile.deadbush.name"
    },
    "minecraft:decorated_pot": {
        "langKey": "tile.decorated_pot.name"
    },
    "minecraft:deepslate": {
        "langKey": "tile.deepslate.name"
    },
    "minecraft:deepslate_brick_slab": {
        "langKey": "tile.deepslate_brick_slab.name"
    },
    "minecraft:deepslate_brick_stairs": {
        "langKey": "tile.deepslate_brick_stairs.name"
    },
    "minecraft:deepslate_brick_wall": {
        "langKey": "tile.deepslate_brick_wall.name"
    },
    "minecraft:deepslate_bricks": {
        "langKey": "tile.deepslate_bricks.name"
    },
    "minecraft:deepslate_coal_ore": {
        "langKey": "tile.deepslate_coal_ore.name"
    },
    "minecraft:deepslate_copper_ore": {
        "langKey": "tile.deepslate_copper_ore.name"
    },
    "minecraft:deepslate_diamond_ore": {
        "langKey": "tile.deepslate_diamond_ore.name"
    },
    "minecraft:deepslate_emerald_ore": {
        "langKey": "tile.deepslate_emerald_ore.name"
    },
    "minecraft:deepslate_gold_ore": {
        "langKey": "tile.deepslate_gold_ore.name"
    },
    "minecraft:deepslate_iron_ore": {
        "langKey": "tile.deepslate_iron_ore.name"
    },
    "minecraft:deepslate_lapis_ore": {
        "langKey": "tile.deepslate_lapis_ore.name"
    },
    "minecraft:deepslate_redstone_ore": {
        "langKey": "tile.deepslate_redstone_ore.name"
    },
    "minecraft:deepslate_tile_slab": {
        "langKey": "tile.deepslate_tile_slab.name"
    },
    "minecraft:deepslate_tile_stairs": {
        "langKey": "tile.deepslate_tile_stairs.name"
    },
    "minecraft:deepslate_tile_wall": {
        "langKey": "tile.deepslate_tile_wall.name"
    },
    "minecraft:deepslate_tiles": {
        "langKey": "tile.deepslate_tiles.name"
    },
    "minecraft:deny": {
        "langKey": "tile.deny.name"
    },
    "minecraft:detector_rail": {
        "langKey": "tile.detector_rail.name"
    },
    "minecraft:diamond": {
        "langKey": "item.diamond.name"
    },
    "minecraft:diamond_axe": {
        "langKey": "item.diamond_axe.name"
    },
    "minecraft:diamond_block": {
        "langKey": "tile.diamond_block.name"
    },
    "minecraft:diamond_boots": {
        "langKey": "item.diamond_boots.name"
    },
    "minecraft:diamond_chestplate": {
        "langKey": "item.diamond_chestplate.name"
    },
    "minecraft:diamond_helmet": {
        "langKey": "item.diamond_helmet.name"
    },
    "minecraft:diamond_hoe": {
        "langKey": "item.diamond_hoe.name"
    },
    "minecraft:diamond_horse_armor": {
        "langKey": "item.horsearmordiamond.name"
    },
    "minecraft:diamond_leggings": {
        "langKey": "item.diamond_leggings.name"
    },
    "minecraft:diamond_ore": {
        "langKey": "tile.diamond_ore.name"
    },
    "minecraft:diamond_pickaxe": {
        "langKey": "item.diamond_pickaxe.name"
    },
    "minecraft:diamond_shovel": {
        "langKey": "item.diamond_shovel.name"
    },
    "minecraft:diamond_sword": {
        "langKey": "item.diamond_sword.name"
    },
    "minecraft:diorite": {
        "langKey": "tile.stone.diorite.name"
    },
    "minecraft:diorite_slab": {
        "langKey": "tile.stone_slab3.diorite.name"
    },
    "minecraft:diorite_stairs": {
        "langKey": "tile.diorite_stairs.name"
    },
    "minecraft:diorite_wall": {
        "langKey": "tile.cobblestone_wall.diorite.name"
    },
    "minecraft:dirt": {
        "langKey": "tile.dirt.name"
    },
    "minecraft:dirt_with_roots": {
        "langKey": "tile.dirt_with_roots.name"
    },
    "minecraft:disc_fragment_5": {
        "langKey": "item.disc_fragment_5.desc"
    },
    "minecraft:dispenser": {
        "langKey": "tile.dispenser.name"
    },
    "minecraft:dolphin_spawn_egg": {
        "langKey": "item.spawn_egg.entity.dolphin.name"
    },
    "minecraft:donkey_spawn_egg": {
        "langKey": "item.spawn_egg.entity.donkey.name"
    },
    "minecraft:double_plant": {
        "langKey": "tile.double_plant.name"
    },
    "minecraft:dragon_breath": {
        "langKey": "item.dragon_breath.name"
    },
    "minecraft:dragon_egg": {
        "langKey": "tile.dragon_egg.name"
    },
    "minecraft:dragon_head": {
        "langKey": "item.skull.dragon.name"
    },
    "minecraft:dried_kelp": {
        "langKey": "item.dried_kelp.name"
    },
    "minecraft:dried_kelp_block": {
        "langKey": "tile.dried_kelp_block.name"
    },
    "minecraft:dripstone_block": {
        "langKey": "tile.dripstone_block.name"
    },
    "minecraft:dropper": {
        "langKey": "tile.dropper.name"
    },
    "minecraft:drowned_spawn_egg": {
        "langKey": "item.spawn_egg.entity.drowned.name"
    },
    "minecraft:dune_armor_trim_smithing_template": {
        "langKey": "trim_pattern.dune.name"
    },
    "minecraft:echo_shard": {
        "langKey": "item.echo_shard.name"
    },
    "minecraft:egg": {
        "langKey": "item.egg.name"
    },
    "minecraft:elder_guardian_spawn_egg": {
        "langKey": "item.spawn_egg.entity.elder_guardian.name"
    },
    "minecraft:elytra": {
        "langKey": "item.elytra.name"
    },
    "minecraft:emerald": {
        "langKey": "item.emerald.name"
    },
    "minecraft:emerald_block": {
        "langKey": "tile.emerald_block.name"
    },
    "minecraft:emerald_ore": {
        "langKey": "tile.emerald_ore.name"
    },
    "minecraft:empty_map": {
        "langKey": "item.emptyMap.name"
    },
    "minecraft:enchanted_book": {
        "langKey": "item.enchanted_book.name"
    },
    "minecraft:enchanted_golden_apple": {
        "langKey": "item.appleEnchanted.name"
    },
    "minecraft:enchanting_table": {
        "langKey": "tile.enchanting_table.name"
    },
    "minecraft:end_brick_stairs": {
        "langKey": "tile.end_brick_stairs.name"
    },
    "minecraft:end_bricks": {
        "langKey": "tile.end_bricks.name"
    },
    "minecraft:end_crystal": {
        "langKey": "item.end_crystal.name"
    },
    "minecraft:end_portal_frame": {
        "langKey": "tile.end_portal_frame.name"
    },
    "minecraft:end_rod": {
        "langKey": "tile.end_rod.name"
    },
    "minecraft:end_stone": {
        "langKey": "tile.end_stone.name"
    },
    "minecraft:end_stone_brick_slab": {
        "langKey": "tile.stone_slab3.end_brick.name"
    },
    "minecraft:end_stone_brick_wall": {
        "langKey": "tile.cobblestone_wall.end_brick.name"
    },
    "minecraft:ender_chest": {
        "langKey": "tile.ender_chest.name"
    },
    "minecraft:ender_dragon_spawn_egg": {
        "langKey": "item.spawn_egg.entity.ender_dragon.name"
    },
    "minecraft:ender_eye": {
        "langKey": "item.ender_eye.name"
    },
    "minecraft:ender_pearl": {
        "langKey": "item.ender_pearl.name"
    },
    "minecraft:enderman_spawn_egg": {
        "langKey": "item.spawn_egg.entity.enderman.name"
    },
    "minecraft:endermite_spawn_egg": {
        "langKey": "item.spawn_egg.entity.endermite.name"
    },
    "minecraft:evoker_spawn_egg": {
        "langKey": "item.spawn_egg.entity.evocation_illager.name"
    },
    "minecraft:experience_bottle": {
        "langKey": "item.experience_bottle.name"
    },
    "minecraft:explorer_pottery_shard": {
        "langKey": "item.explorer_pottery_shard.name"
    },
    "minecraft:explorer_pottery_sherd": {
        "langKey": "item.explorer_pottery_sherd.name"
    },
    "minecraft:exposed_chiseled_copper": {
        "langKey": "tile.exposed_chiseled_copper.name"
    },
    "minecraft:exposed_copper": {
        "langKey": "tile.exposed_copper.name"
    },
    "minecraft:exposed_copper_bulb": {
        "langKey": "tile.exposed_copper_bulb.name"
    },
    "minecraft:exposed_copper_door": {
        "langKey": "item.exposed_copper_door.name"
    },
    "minecraft:exposed_copper_grate": {
        "langKey": "tile.exposed_copper_grate.name"
    },
    "minecraft:exposed_copper_trapdoor": {
        "langKey": "tile.exposed_copper_trapdoor.name"
    },
    "minecraft:exposed_cut_copper": {
        "langKey": "tile.exposed_cut_copper.name"
    },
    "minecraft:exposed_cut_copper_slab": {
        "langKey": "tile.exposed_cut_copper_slab.name"
    },
    "minecraft:exposed_cut_copper_stairs": {
        "langKey": "tile.exposed_cut_copper_stairs.name"
    },
    "minecraft:eye_armor_trim_smithing_template": {
        "langKey": "trim_pattern.eye.name"
    },
    "minecraft:farmland": {
        "langKey": "tile.farmland.name"
    },
    "minecraft:feather": {
        "langKey": "item.feather.name"
    },
    "minecraft:fence_gate": {
        "langKey": "tile.fence_gate.name"
    },
    "minecraft:fermented_spider_eye": {
        "langKey": "item.fermented_spider_eye.name"
    },
    "minecraft:fern": {
        "langKey": "tile.tallgrass.fern.name"
    },
    "minecraft:field_masoned_banner_pattern": {
        "langKey": "item.banner_pattern.bricks"
    },
    "minecraft:filled_map": {
        "langKey": "item.map.name"
    },
    "minecraft:fire_charge": {
        "langKey": "item.fireball.name"
    },
    "minecraft:fire_coral": {
        "langKey": "tile.coral.red.name"
    },
    "minecraft:fire_coral_block": {
        "langKey": "tile.coral_block.red.name"
    },
    "minecraft:fire_coral_fan": {
        "langKey": "tile.coral_fan.red_fan.name"
    },
    "minecraft:firefly_bush": {
        "langKey": "tile.firefly_bush.name"
    },
    "minecraft:firework_rocket": {
        "langKey": "item.fireworks.name"
    },
    "minecraft:firework_star": {
        "langKey": "item.fireworksCharge.name"
    },
    "minecraft:fishing_rod": {
        "langKey": "item.fishing_rod.name"
    },
    "minecraft:fletching_table": {
        "langKey": "tile.fletching_table.name"
    },
    "minecraft:flint": {
        "langKey": "item.flint.name"
    },
    "minecraft:flint_and_steel": {
        "langKey": "item.flint_and_steel.name"
    },
    "minecraft:flow_armor_trim_smithing_template": {
        "langKey": "item.flow_armor_trim_smithing_template.name"
    },
    "minecraft:flow_banner_pattern": {
        "langKey": "item.flow_banner_pattern.name"
    },
    "minecraft:flow_pottery_sherd": {
        "langKey": "item.flow_pottery_sherd.name"
    },
    "minecraft:flower_banner_pattern": {
        "langKey": "item.banner_pattern.flower"
    },
    "minecraft:flower_pot": {
        "langKey": "item.flower_pot.name"
    },
    "minecraft:flowering_azalea": {
        "langKey": "tile.flowering_azalea.name"
    },
    "minecraft:fox_spawn_egg": {
        "langKey": "item.spawn_egg.entity.fox.name"
    },
    "minecraft:frame": {
        "langKey": "item.frame.name"
    },
    "minecraft:friend_pottery_shard": {
        "langKey": "item.friend_pottery_shard.name"
    },
    "minecraft:friend_pottery_sherd": {
        "langKey": "item.friend_pottery_sherd.name"
    },
    "minecraft:frog_spawn": {
        "langKey": "tile.frog_spawn.name"
    },
    "minecraft:frog_spawn_egg": {
        "langKey": "item.spawn_egg.entity.frog.name"
    },
    "minecraft:frosted_ice": {
        "langKey": "tile.frosted_ice.name"
    },
    "minecraft:furnace": {
        "langKey": "tile.furnace.name"
    },
    "minecraft:ghast_spawn_egg": {
        "langKey": "item.spawn_egg.entity.ghast.name"
    },
    "minecraft:ghast_tear": {
        "langKey": "item.ghast_tear.name"
    },
    "minecraft:gilded_blackstone": {
        "langKey": "tile.gilded_blackstone.name"
    },
    "minecraft:glass": {
        "langKey": "tile.glass.name"
    },
    "minecraft:glass_bottle": {
        "langKey": "item.glass_bottle.name"
    },
    "minecraft:glass_pane": {
        "langKey": "tile.glass_pane.name"
    },
    "minecraft:glistering_melon_slice": {
        "langKey": "item.speckled_melon.name"
    },
    "minecraft:globe_banner_pattern": {
        "langKey": "item.banner_pattern.globe"
    },
    "minecraft:glow_berries": {
        "langKey": "item.glow_berries.name"
    },
    "minecraft:glow_frame": {
        "langKey": "item.glow_frame.name"
    },
    "minecraft:glow_ink_sac": {
        "langKey": "item.glow_ink_sac.name"
    },
    "minecraft:glow_lichen": {
        "langKey": "tile.glow_lichen.name"
    },
    "minecraft:glow_squid_spawn_egg": {
        "langKey": "item.spawn_egg.entity.glow_squid.name"
    },
    "minecraft:glowstone": {
        "langKey": "tile.glowstone.name"
    },
    "minecraft:glowstone_dust": {
        "langKey": "item.glowstone_dust.name"
    },
    "minecraft:goat_horn": {
        "langKey": "item.goat_horn.name"
    },
    "minecraft:goat_spawn_egg": {
        "langKey": "item.spawn_egg.entity.goat.name"
    },
    "minecraft:gold_block": {
        "langKey": "tile.gold_block.name"
    },
    "minecraft:gold_ingot": {
        "langKey": "item.gold_ingot.name"
    },
    "minecraft:gold_nugget": {
        "langKey": "item.gold_nugget.name"
    },
    "minecraft:gold_ore": {
        "langKey": "tile.gold_ore.name"
    },
    "minecraft:golden_apple": {
        "langKey": "item.golden_apple.name"
    },
    "minecraft:golden_axe": {
        "langKey": "item.golden_axe.name"
    },
    "minecraft:golden_boots": {
        "langKey": "item.golden_boots.name"
    },
    "minecraft:golden_carrot": {
        "langKey": "item.golden_carrot.name"
    },
    "minecraft:golden_chestplate": {
        "langKey": "item.golden_chestplate.name"
    },
    "minecraft:golden_helmet": {
        "langKey": "item.golden_helmet.name"
    },
    "minecraft:golden_hoe": {
        "langKey": "item.golden_hoe.name"
    },
    "minecraft:golden_horse_armor": {
        "langKey": "item.horsearmorgold.name"
    },
    "minecraft:golden_leggings": {
        "langKey": "item.golden_leggings.name"
    },
    "minecraft:golden_pickaxe": {
        "langKey": "item.golden_pickaxe.name"
    },
    "minecraft:golden_rail": {
        "langKey": "tile.golden_rail.name"
    },
    "minecraft:golden_shovel": {
        "langKey": "item.golden_shovel.name"
    },
    "minecraft:golden_sword": {
        "langKey": "item.golden_sword.name"
    },
    "minecraft:granite": {
        "langKey": "tile.stone.granite.name"
    },
    "minecraft:granite_slab": {
        "langKey": "tile.stone_slab3.granite.name"
    },
    "minecraft:granite_stairs": {
        "langKey": "tile.granite_stairs.name"
    },
    "minecraft:granite_wall": {
        "langKey": "tile.cobblestone_wall.granite.name"
    },
    "minecraft:grass": {
        "langKey": "tile.grass.name"
    },
    "minecraft:grass_block": {
        "langKey": "tile.grass.name"
    },
    "minecraft:grass_path": {
        "langKey": "tile.grass_path.name"
    },
    "minecraft:gravel": {
        "langKey": "tile.gravel.name"
    },
    "minecraft:gray_bundle": {
        "langKey": "item.gray_bundle"
    },
    "minecraft:gray_candle": {
        "langKey": "tile.gray_candle.name"
    },
    "minecraft:gray_carpet": {
        "langKey": "tile.carpet.gray.name"
    },
    "minecraft:gray_concrete": {
        "langKey": "tile.concrete.gray.name"
    },
    "minecraft:gray_concrete_powder": {
        "langKey": "tile.concretePowder.gray.name"
    },
    "minecraft:gray_dye": {
        "langKey": "item.dye.gray.name"
    },
    "minecraft:gray_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.gray.name"
    },
    "minecraft:gray_shulker_box": {
        "langKey": "tile.shulkerBoxGray.name"
    },
    "minecraft:gray_stained_glass": {
        "langKey": "tile.stained_glass.gray.name"
    },
    "minecraft:gray_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.gray.name"
    },
    "minecraft:gray_terracotta": {
        "langKey": "tile.stained_hardened_clay.gray.name"
    },
    "minecraft:gray_wool": {
        "langKey": "tile.wool.gray.name"
    },
    "minecraft:green_bundle": {
        "langKey": "item.green_bundle"
    },
    "minecraft:green_candle": {
        "langKey": "tile.green_candle.name"
    },
    "minecraft:green_carpet": {
        "langKey": "tile.carpet.green.name"
    },
    "minecraft:green_concrete": {
        "langKey": "tile.concrete.green.name"
    },
    "minecraft:green_concrete_powder": {
        "langKey": "tile.concretePowder.green.name"
    },
    "minecraft:green_dye": {
        "langKey": "item.dye.green.name"
    },
    "minecraft:green_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.green.name"
    },
    "minecraft:green_shulker_box": {
        "langKey": "tile.shulkerBoxGreen.name"
    },
    "minecraft:green_stained_glass": {
        "langKey": "tile.stained_glass.green.name"
    },
    "minecraft:green_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.green.name"
    },
    "minecraft:green_terracotta": {
        "langKey": "tile.stained_hardened_clay.green.name"
    },
    "minecraft:green_wool": {
        "langKey": "tile.wool.green.name"
    },
    "minecraft:grindstone": {
        "langKey": "tile.grindstone.name"
    },
    "minecraft:guardian_spawn_egg": {
        "langKey": "item.spawn_egg.entity.guardian.name"
    },
    "minecraft:gunpowder": {
        "langKey": "item.gunpowder.name"
    },
    "minecraft:guster_banner_pattern": {
        "langKey": "item.guster_banner_pattern.name"
    },
    "minecraft:guster_pottery_sherd": {
        "langKey": "item.guster_pottery_sherd.name"
    },
    "minecraft:hanging_roots": {
        "langKey": "tile.hanging_roots.name"
    },
    "minecraft:hardened_clay": {
        "langKey": "tile.hardened_clay.name"
    },
    "minecraft:hay_block": {
        "langKey": "tile.hay_block.name"
    },
    "minecraft:heart_of_the_sea": {
        "langKey": "item.heart_of_the_sea.name"
    },
    "minecraft:heart_pottery_shard": {
        "langKey": "item.heart_pottery_shard.name"
    },
    "minecraft:heart_pottery_sherd": {
        "langKey": "item.heart_pottery_sherd.name"
    },
    "minecraft:heartbreak_pottery_shard": {
        "langKey": "item.heartbreak_pottery_shard.name"
    },
    "minecraft:heartbreak_pottery_sherd": {
        "langKey": "item.heartbreak_pottery_sherd.name"
    },
    "minecraft:heavy_core": {
        "langKey": "tile.heavy_core.name"
    },
    "minecraft:heavy_weighted_pressure_plate": {
        "langKey": "tile.heavy_weighted_pressure_plate.name"
    },
    "minecraft:hoglin_spawn_egg": {
        "langKey": "item.spawn_egg.entity.hoglin.name"
    },
    "minecraft:honey_block": {
        "langKey": "tile.honey_block.name"
    },
    "minecraft:honey_bottle": {
        "langKey": "item.honey_bottle.name"
    },
    "minecraft:honeycomb": {
        "langKey": "item.honeycomb.name"
    },
    "minecraft:honeycomb_block": {
        "langKey": "tile.honeycomb_block.name"
    },
    "minecraft:hopper": {
        "langKey": "tile.hopper.name"
    },
    "minecraft:hopper_minecart": {
        "langKey": "item.hopper_minecart.name"
    },
    "minecraft:horn_coral": {
        "langKey": "tile.coral.yellow.name"
    },
    "minecraft:horn_coral_block": {
        "langKey": "tile.coral_block.yellow.name"
    },
    "minecraft:horn_coral_fan": {
        "langKey": "tile.coral_fan.yellow_fan.name"
    },
    "minecraft:horse_spawn_egg": {
        "langKey": "item.spawn_egg.entity.horse.name"
    },
    "minecraft:host_armor_trim_smithing_template": {
        "langKey": "trim_pattern.host.name"
    },
    "minecraft:howl_pottery_shard": {
        "langKey": "item.howl_pottery_shard.name"
    },
    "minecraft:howl_pottery_sherd": {
        "langKey": "item.howl_pottery_sherd.name"
    },
    "minecraft:husk_spawn_egg": {
        "langKey": "item.spawn_egg.entity.husk.name"
    },
    "minecraft:ice": {
        "langKey": "tile.ice.name"
    },
    "minecraft:infested_chiseled_stone_bricks": {
        "langKey": "tile.monster_egg.chiseledbrick.name"
    },
    "minecraft:infested_cobblestone": {
        "langKey": "tile.monster_egg.cobble.name"
    },
    "minecraft:infested_cracked_stone_bricks": {
        "langKey": "tile.monster_egg.crackedbrick.name"
    },
    "minecraft:infested_deepslate": {
        "langKey": "tile.infested_deepslate.name"
    },
    "minecraft:infested_mossy_stone_bricks": {
        "langKey": "tile.monster_egg.mossybrick.name"
    },
    "minecraft:infested_stone": {
        "langKey": "tile.monster_egg.name"
    },
    "minecraft:infested_stone_bricks": {
        "langKey": "tile.monster_egg.brick.name"
    },
    "minecraft:ink_sac": {
        "langKey": "item.dye.black.name"
    },
    "minecraft:iron_axe": {
        "langKey": "item.iron_axe.name"
    },
    "minecraft:iron_bars": {
        "langKey": "tile.iron_bars.name"
    },
    "minecraft:iron_block": {
        "langKey": "tile.iron_block.name"
    },
    "minecraft:iron_boots": {
        "langKey": "item.iron_boots.name"
    },
    "minecraft:iron_chestplate": {
        "langKey": "item.iron_chestplate.name"
    },
    "minecraft:iron_door": {
        "langKey": "item.iron_door.name"
    },
    "minecraft:iron_golem_spawn_egg": {
        "langKey": "item.spawn_egg.entity.iron_golem.name"
    },
    "minecraft:iron_helmet": {
        "langKey": "item.iron_helmet.name"
    },
    "minecraft:iron_hoe": {
        "langKey": "item.iron_hoe.name"
    },
    "minecraft:iron_horse_armor": {
        "langKey": "item.horsearmoriron.name"
    },
    "minecraft:iron_ingot": {
        "langKey": "item.iron_ingot.name"
    },
    "minecraft:iron_leggings": {
        "langKey": "item.iron_leggings.name"
    },
    "minecraft:iron_nugget": {
        "langKey": "item.iron_nugget.name"
    },
    "minecraft:iron_ore": {
        "langKey": "tile.iron_ore.name"
    },
    "minecraft:iron_pickaxe": {
        "langKey": "item.iron_pickaxe.name"
    },
    "minecraft:iron_shovel": {
        "langKey": "item.iron_shovel.name"
    },
    "minecraft:iron_sword": {
        "langKey": "item.iron_sword.name"
    },
    "minecraft:iron_trapdoor": {
        "langKey": "tile.iron_trapdoor.name"
    },
    "minecraft:jigsaw": {
        "langKey": "tile.jigsaw.name"
    },
    "minecraft:jukebox": {
        "langKey": "tile.jukebox.name"
    },
    "minecraft:jungle_boat": {
        "langKey": "item.boat.jungle.name"
    },
    "minecraft:jungle_button": {
        "langKey": "tile.jungle_button.name"
    },
    "minecraft:jungle_chest_boat": {
        "langKey": "item.chest_boat.jungle.name"
    },
    "minecraft:jungle_door": {
        "langKey": "item.jungle_door.name"
    },
    "minecraft:jungle_fence": {
        "langKey": "tile.jungleFence.name"
    },
    "minecraft:jungle_fence_gate": {
        "langKey": "tile.jungle_fence_gate.name"
    },
    "minecraft:jungle_hanging_sign": {
        "langKey": "item.jungle_hanging_sign.name"
    },
    "minecraft:jungle_leaves": {
        "langKey": "tile.leaves.jungle.name"
    },
    "minecraft:jungle_log": {
        "langKey": "tile.log.jungle.name"
    },
    "minecraft:jungle_planks": {
        "langKey": "tile.planks.jungle.name"
    },
    "minecraft:jungle_pressure_plate": {
        "langKey": "tile.jungle_pressure_plate.name"
    },
    "minecraft:jungle_sapling": {
        "langKey": "tile.sapling.jungle.name"
    },
    "minecraft:jungle_sign": {
        "langKey": "item.jungle_sign.name"
    },
    "minecraft:jungle_slab": {
        "langKey": "tile.wooden_slab.jungle.name"
    },
    "minecraft:jungle_stairs": {
        "langKey": "tile.jungle_stairs.name"
    },
    "minecraft:jungle_trapdoor": {
        "langKey": "tile.jungle_trapdoor.name"
    },
    "minecraft:jungle_wood": {
        "langKey": "tile.wood.jungle.name"
    },
    "minecraft:kelp": {
        "langKey": "item.kelp.name"
    },
    "minecraft:ladder": {
        "langKey": "tile.ladder.name"
    },
    "minecraft:lantern": {
        "langKey": "tile.lantern.name"
    },
    "minecraft:lapis_block": {
        "langKey": "tile.lapis_block.name"
    },
    "minecraft:lapis_lazuli": {
        "langKey": "item.dye.blue.name"
    },
    "minecraft:lapis_ore": {
        "langKey": "tile.lapis_ore.name"
    },
    "minecraft:large_amethyst_bud": {
        "langKey": "tile.large_amethyst_bud.name"
    },
    "minecraft:large_fern": {
        "langKey": "tile.double_plant.fern.name"
    },
    "minecraft:lava_bucket": {
        "langKey": "item.bucketLava.name"
    },
    "minecraft:lead": {
        "langKey": "item.lead.name"
    },
    "minecraft:leaf_litter": {
        "langKey": "tile.leaf_litter.name"
    },
    "minecraft:leather": {
        "langKey": "item.leather.name"
    },
    "minecraft:leather_boots": {
        "langKey": "item.leather_boots.name"
    },
    "minecraft:leather_chestplate": {
        "langKey": "item.leather_chestplate.name"
    },
    "minecraft:leather_helmet": {
        "langKey": "item.leather_helmet.name"
    },
    "minecraft:leather_horse_armor": {
        "langKey": "item.horsearmorleather.name"
    },
    "minecraft:leather_leggings": {
        "langKey": "item.leather_leggings.name"
    },
    "minecraft:leaves": {
        "langKey": "item.leaves.name"
    },
    "minecraft:leaves2": {
        "langKey": "tile.leaves2.big_oak.name"
    },
    "minecraft:lectern": {
        "langKey": "tile.lectern.name"
    },
    "minecraft:lever": {
        "langKey": "tile.lever.name"
    },
    "minecraft:light_block_0": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_1": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_10": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_11": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_12": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_13": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_14": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_15": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_2": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_3": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_4": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_5": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_6": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_7": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_8": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_block_9": {
        "langKey": "tile.light_block.name"
    },
    "minecraft:light_blue_bundle": {
        "langKey": "item.light_blue_bundle"
    },
    "minecraft:light_blue_candle": {
        "langKey": "tile.light_blue_candle.name"
    },
    "minecraft:light_blue_carpet": {
        "langKey": "tile.carpet.lightBlue.name"
    },
    "minecraft:light_blue_concrete": {
        "langKey": "tile.concrete.lightBlue.name"
    },
    "minecraft:light_blue_concrete_powder": {
        "langKey": "tile.concretePowder.lightBlue.name"
    },
    "minecraft:light_blue_dye": {
        "langKey": "item.dye.lightBlue.name"
    },
    "minecraft:light_blue_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.light_blue.name"
    },
    "minecraft:light_blue_shulker_box": {
        "langKey": "tile.shulkerBoxLightBlue.name"
    },
    "minecraft:light_blue_stained_glass": {
        "langKey": "tile.stained_glass.light_blue.name"
    },
    "minecraft:light_blue_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.light_blue.name"
    },
    "minecraft:light_blue_terracotta": {
        "langKey": "tile.stained_hardened_clay.lightBlue.name"
    },
    "minecraft:light_blue_wool": {
        "langKey": "tile.wool.lightBlue.name"
    },
    "minecraft:light_gray_bundle": {
        "langKey": "item.light_gray_bundle"
    },
    "minecraft:light_gray_candle": {
        "langKey": "tile.light_gray_candle.name"
    },
    "minecraft:light_gray_carpet": {
        "langKey": "tile.carpet.silver.name"
    },
    "minecraft:light_gray_concrete": {
        "langKey": "tile.concrete.silver.name"
    },
    "minecraft:light_gray_concrete_powder": {
        "langKey": "tile.concretePowder.silver.name"
    },
    "minecraft:light_gray_dye": {
        "langKey": "item.dye.silver.name"
    },
    "minecraft:light_gray_shulker_box": {
        "langKey": "tile.shulkerBoxSilver.name"
    },
    "minecraft:light_gray_stained_glass": {
        "langKey": "tile.stained_glass.silver.name"
    },
    "minecraft:light_gray_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.silver.name"
    },
    "minecraft:light_gray_terracotta": {
        "langKey": "tile.stained_hardened_clay.silver.name"
    },
    "minecraft:light_gray_wool": {
        "langKey": "tile.wool.silver.name"
    },
    "minecraft:light_weighted_pressure_plate": {
        "langKey": "tile.light_weighted_pressure_plate.name"
    },
    "minecraft:lightning_rod": {
        "langKey": "tile.lightning_rod.name"
    },
    "minecraft:lilac": {
        "langKey": "tile.double_plant.syringa.name"
    },
    "minecraft:lily_of_the_valley": {
        "langKey": "tile.red_flower.lilyOfTheValley.name"
    },
    "minecraft:lime_bundle": {
        "langKey": "item.lime_bundle"
    },
    "minecraft:lime_candle": {
        "langKey": "tile.lime_candle.name"
    },
    "minecraft:lime_carpet": {
        "langKey": "tile.carpet.lime.name"
    },
    "minecraft:lime_concrete": {
        "langKey": "tile.concrete.lime.name"
    },
    "minecraft:lime_concrete_powder": {
        "langKey": "tile.concretePowder.lime.name"
    },
    "minecraft:lime_dye": {
        "langKey": "item.dye.lime.name"
    },
    "minecraft:lime_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.lime.name"
    },
    "minecraft:lime_shulker_box": {
        "langKey": "tile.shulkerBoxLime.name"
    },
    "minecraft:lime_stained_glass": {
        "langKey": "tile.stained_glass.lime.name"
    },
    "minecraft:lime_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.lime.name"
    },
    "minecraft:lime_terracotta": {
        "langKey": "tile.stained_hardened_clay.lime.name"
    },
    "minecraft:lime_wool": {
        "langKey": "tile.wool.lime.name"
    },
    "minecraft:lingering_potion": {
        "langKey": "potion.moveSlowdown.linger.name"
    },
    "minecraft:lit_pumpkin": {
        "langKey": "tile.lit_pumpkin.name"
    },
    "minecraft:llama_spawn_egg": {
        "langKey": "item.spawn_egg.entity.llama.name"
    },
    "minecraft:lodestone": {
        "langKey": "tile.lodestone.name"
    },
    "minecraft:lodestone_compass": {
        "langKey": "item.lodestonecompass.name"
    },
    "minecraft:loom": {
        "langKey": "tile.loom.name"
    },
    "minecraft:mace": {
        "langKey": "item.mace.name"
    },
    "minecraft:magenta_bundle": {
        "langKey": "item.magenta_bundle"
    },
    "minecraft:magenta_candle": {
        "langKey": "tile.magenta_candle.name"
    },
    "minecraft:magenta_carpet": {
        "langKey": "tile.carpet.magenta.name"
    },
    "minecraft:magenta_concrete": {
        "langKey": "tile.concrete.magenta.name"
    },
    "minecraft:magenta_concrete_powder": {
        "langKey": "tile.concretePowder.magenta.name"
    },
    "minecraft:magenta_dye": {
        "langKey": "item.dye.magenta.name"
    },
    "minecraft:magenta_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.magenta.name"
    },
    "minecraft:magenta_shulker_box": {
        "langKey": "tile.shulkerBoxMagenta.name"
    },
    "minecraft:magenta_stained_glass": {
        "langKey": "tile.stained_glass.magenta.name"
    },
    "minecraft:magenta_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.magenta.name"
    },
    "minecraft:magenta_terracotta": {
        "langKey": "tile.stained_hardened_clay.magenta.name"
    },
    "minecraft:magenta_wool": {
        "langKey": "tile.wool.magenta.name"
    },
    "minecraft:magma": {
        "langKey": "tile.magma.name"
    },
    "minecraft:magma_cream": {
        "langKey": "item.magma_cream.name"
    },
    "minecraft:magma_cube_spawn_egg": {
        "langKey": "item.spawn_egg.entity.magma_cube.name"
    },
    "minecraft:mangrove_boat": {
        "langKey": "item.boat.mangrove.name"
    },
    "minecraft:mangrove_button": {
        "langKey": "tile.mangrove_button.name"
    },
    "minecraft:mangrove_chest_boat": {
        "langKey": "item.chest_boat.mangrove.name"
    },
    "minecraft:mangrove_door": {
        "langKey": "item.mangrove_door.name"
    },
    "minecraft:mangrove_fence": {
        "langKey": "tile.mangrove_fence.name"
    },
    "minecraft:mangrove_fence_gate": {
        "langKey": "tile.mangrove_fence_gate.name"
    },
    "minecraft:mangrove_hanging_sign": {
        "langKey": "item.mangrove_hanging_sign.name"
    },
    "minecraft:mangrove_leaves": {
        "langKey": "tile.mangrove_leaves.name"
    },
    "minecraft:mangrove_log": {
        "langKey": "tile.mangrove_log.name"
    },
    "minecraft:mangrove_planks": {
        "langKey": "tile.mangrove_planks.name"
    },
    "minecraft:mangrove_pressure_plate": {
        "langKey": "tile.mangrove_pressure_plate.name"
    },
    "minecraft:mangrove_propagule": {
        "langKey": "tile.mangrove_propagule.name"
    },
    "minecraft:mangrove_roots": {
        "langKey": "tile.mangrove_roots.name"
    },
    "minecraft:mangrove_sign": {
        "langKey": "item.mangrove_sign.name"
    },
    "minecraft:mangrove_slab": {
        "langKey": "tile.mangrove_slab.name"
    },
    "minecraft:mangrove_stairs": {
        "langKey": "tile.mangrove_stairs.name"
    },
    "minecraft:mangrove_trapdoor": {
        "langKey": "tile.mangrove_trapdoor.name"
    },
    "minecraft:mangrove_wood": {
        "langKey": "tile.mangrove_wood.name"
    },
    "minecraft:medium_amethyst_bud": {
        "langKey": "tile.medium_amethyst_bud.name"
    },
    "minecraft:melon_block": {
        "langKey": "tile.melon_block.name"
    },
    "minecraft:melon_seeds": {
        "langKey": "item.melon_seeds.name"
    },
    "minecraft:melon_slice": {
        "langKey": "item.melon.name"
    },
    "minecraft:milk_bucket": {
        "langKey": "item.milk.name"
    },
    "minecraft:minecart": {
        "langKey": "item.minecart.name"
    },
    "minecraft:miner_pottery_shard": {
        "langKey": "item.miner_pottery_shard.name"
    },
    "minecraft:miner_pottery_sherd": {
        "langKey": "item.miner_pottery_sherd.name"
    },
    "minecraft:mob_spawner": {
        "langKey": "tile.mob_spawner.name"
    },
    "minecraft:mojang_banner_pattern": {
        "langKey": "item.banner_pattern.thing"
    },
    "minecraft:monster_egg": {
        "langKey": "tile.monster_egg.name"
    },
    "minecraft:mooshroom_spawn_egg": {
        "langKey": "item.spawn_egg.entity.mooshroom.name"
    },
    "minecraft:moss_block": {
        "langKey": "tile.moss_block.name"
    },
    "minecraft:moss_carpet": {
        "langKey": "tile.moss_carpet.name"
    },
    "minecraft:mossy_cobblestone": {
        "langKey": "tile.mossy_cobblestone.name"
    },
    "minecraft:mossy_cobblestone_slab": {
        "langKey": "tile.stone_slab2.mossy_cobblestone.name"
    },
    "minecraft:mossy_cobblestone_stairs": {
        "langKey": "tile.mossy_cobblestone_stairs.name"
    },
    "minecraft:mossy_cobblestone_wall": {
        "langKey": "tile.cobblestone_wall.mossy.name"
    },
    "minecraft:mossy_stone_brick_slab": {
        "langKey": "tile.stone_slab4.mossy_stone_brick.name"
    },
    "minecraft:mossy_stone_brick_stairs": {
        "langKey": "tile.mossy_stone_brick_stairs.name"
    },
    "minecraft:mossy_stone_brick_wall": {
        "langKey": "tile.cobblestone_wall.mossy_stone_brick.name"
    },
    "minecraft:mossy_stone_bricks": {
        "langKey": "tile.stonebrick.mossy.name"
    },
    "minecraft:mourner_pottery_shard": {
        "langKey": "item.mourner_pottery_shard.name"
    },
    "minecraft:mourner_pottery_sherd": {
        "langKey": "item.mourner_pottery_sherd.name"
    },
    "minecraft:mud": {
        "langKey": "tile.mud.name"
    },
    "minecraft:mud_brick_slab": {
        "langKey": "tile.mud_brick_slab.name"
    },
    "minecraft:mud_brick_stairs": {
        "langKey": "tile.mud_brick_stairs.name"
    },
    "minecraft:mud_brick_wall": {
        "langKey": "tile.mud_brick_wall.name"
    },
    "minecraft:mud_bricks": {
        "langKey": "tile.mud_bricks.name"
    },
    "minecraft:muddy_mangrove_roots": {
        "langKey": "tile.muddy_mangrove_roots.name"
    },
    "minecraft:mule_spawn_egg": {
        "langKey": "item.spawn_egg.entity.mule.name"
    },
    "minecraft:mushroom_stem": {
        "langKey": "tile.brown_mushroom_block.stem.name"
    },
    "minecraft:mushroom_stew": {
        "langKey": "item.mushroom_stew.name"
    },
    "minecraft:music_disc_11": {
        "langKey": "item.record_11.desc"
    },
    "minecraft:music_disc_13": {
        "langKey": "item.record_13.desc"
    },
    "minecraft:music_disc_5": {
        "langKey": "item.record_5.desc"
    },
    "minecraft:music_disc_blocks": {
        "langKey": "item.record_blocks.desc"
    },
    "minecraft:music_disc_cat": {
        "langKey": "item.record_cat.desc"
    },
    "minecraft:music_disc_chirp": {
        "langKey": "item.record_chirp.desc"
    },
    "minecraft:music_disc_creator": {
        "langKey": "item.record_creator.desc"
    },
    "minecraft:music_disc_creator_music_box": {
        "langKey": "item.record_creator_music_box.desc"
    },
    "minecraft:music_disc_far": {
        "langKey": "item.record_far.desc"
    },
    "minecraft:music_disc_mall": {
        "langKey": "item.record_mall.desc"
    },
    "minecraft:music_disc_mellohi": {
        "langKey": "item.record_mellohi.desc"
    },
    "minecraft:music_disc_otherside": {
        "langKey": "item.record_otherside.desc"
    },
    "minecraft:music_disc_pigstep": {
        "langKey": "item.record_pigstep.desc"
    },
    "minecraft:music_disc_precipice": {
        "langKey": "item.record_precipice.desc"
    },
    "minecraft:music_disc_relic": {
        "langKey": "item.record_relic.desc"
    },
    "minecraft:music_disc_stal": {
        "langKey": "item.record_stal.desc"
    },
    "minecraft:music_disc_strad": {
        "langKey": "item.record_strad.desc"
    },
    "minecraft:music_disc_wait": {
        "langKey": "item.record_wait.desc"
    },
    "minecraft:music_disc_ward": {
        "langKey": "item.record_ward.desc"
    },
    "minecraft:mutton": {
        "langKey": "item.muttonRaw.name"
    },
    "minecraft:mycelium": {
        "langKey": "tile.mycelium.name"
    },
    "minecraft:name_tag": {
        "langKey": "item.name_tag.name"
    },
    "minecraft:nautilus_shell": {
        "langKey": "item.nautilus_shell.name"
    },
    "minecraft:nether_brick": {
        "langKey": "tile.nether_brick.name"
    },
    "minecraft:nether_brick_fence": {
        "langKey": "tile.nether_brick_fence.name"
    },
    "minecraft:nether_brick_slab": {
        "langKey": "tile.double_stone_slab.nether_brick.name"
    },
    "minecraft:nether_brick_stairs": {
        "langKey": "tile.nether_brick_stairs.name"
    },
    "minecraft:nether_brick_wall": {
        "langKey": "tile.cobblestone_wall.nether_brick.name"
    },
    "minecraft:nether_gold_ore": {
        "langKey": "tile.nether_gold_ore.name"
    },
    "minecraft:nether_sprouts": {
        "langKey": "tile.nether_sprouts.name"
    },
    "minecraft:nether_star": {
        "langKey": "item.netherStar.name"
    },
    "minecraft:nether_wart": {
        "langKey": "item.nether_wart.name"
    },
    "minecraft:nether_wart_block": {
        "langKey": "tile.nether_wart_block.name"
    },
    "minecraft:netherbrick": {
        "langKey": "item.netherbrick.name"
    },
    "minecraft:netherite_axe": {
        "langKey": "item.netherite_axe.name"
    },
    "minecraft:netherite_block": {
        "langKey": "tile.netherite_block.name"
    },
    "minecraft:netherite_boots": {
        "langKey": "item.netherite_boots.name"
    },
    "minecraft:netherite_chestplate": {
        "langKey": "item.netherite_chestplate.name"
    },
    "minecraft:netherite_helmet": {
        "langKey": "item.netherite_helmet.name"
    },
    "minecraft:netherite_hoe": {
        "langKey": "item.netherite_hoe.name"
    },
    "minecraft:netherite_ingot": {
        "langKey": "item.netherite_ingot.name"
    },
    "minecraft:netherite_leggings": {
        "langKey": "item.netherite_leggings.name"
    },
    "minecraft:netherite_pickaxe": {
        "langKey": "item.netherite_pickaxe.name"
    },
    "minecraft:netherite_scrap": {
        "langKey": "item.netherite_scrap.name"
    },
    "minecraft:netherite_shovel": {
        "langKey": "item.netherite_shovel.name"
    },
    "minecraft:netherite_sword": {
        "langKey": "item.netherite_sword.name"
    },
    "minecraft:netherite_upgrade_smithing_template": {
        "langKey": "upgrade.netherite_upgrade.name"
    },
    "minecraft:netherrack": {
        "langKey": "tile.netherrack.name"
    },
    "minecraft:normal_stone_slab": {
        "langKey": "tile.double_stone_slab.stone.name"
    },
    "minecraft:normal_stone_stairs": {
        "langKey": "tile.normal_stone_stairs.name"
    },
    "minecraft:noteblock": {
        "langKey": "tile.noteblock.name"
    },
    "minecraft:oak_boat": {
        "langKey": "item.boat.oak.name"
    },
    "minecraft:oak_chest_boat": {
        "langKey": "item.chest_boat.oak.name"
    },
    "minecraft:oak_fence": {
        "langKey": "tile.fence.name"
    },
    "minecraft:oak_hanging_sign": {
        "langKey": "item.oak_hanging_sign.name"
    },
    "minecraft:oak_leaves": {
        "langKey": "tile.leaves.oak.name"
    },
    "minecraft:oak_log": {
        "langKey": "tile.log.oak.name"
    },
    "minecraft:oak_planks": {
        "langKey": "tile.planks.oak.name"
    },
    "minecraft:oak_sapling": {
        "langKey": "tile.sapling.oak.name"
    },
    "minecraft:oak_sign": {
        "langKey": "item.sign.name"
    },
    "minecraft:oak_slab": {
        "langKey": "tile.wooden_slab.oak.name"
    },
    "minecraft:oak_stairs": {
        "langKey": "tile.oak_stairs.name"
    },
    "minecraft:oak_wood": {
        "langKey": "tile.wood.oak.name"
    },
    "minecraft:observer": {
        "langKey": "tile.observer.name"
    },
    "minecraft:obsidian": {
        "langKey": "tile.obsidian.name"
    },
    "minecraft:ocelot_spawn_egg": {
        "langKey": "item.spawn_egg.entity.ocelot.name"
    },
    "minecraft:ochre_froglight": {
        "langKey": "tile.ochre_froglight.name"
    },
    "minecraft:ominous_bottle": {
        "langKey": "item.ominous_bottle.name"
    },
    "minecraft:ominous_trial_key": {
        "langKey": "item.ominous_trial_key.name"
    },
    "minecraft:open_eyeblossom": {
        "langKey": "tile.open_eyeblossom.name"
    },
    "minecraft:orange_bundle": {
        "langKey": "item.orange_bundle"
    },
    "minecraft:orange_candle": {
        "langKey": "tile.orange_candle.name"
    },
    "minecraft:orange_carpet": {
        "langKey": "tile.carpet.orange.name"
    },
    "minecraft:orange_concrete": {
        "langKey": "tile.concrete.orange.name"
    },
    "minecraft:orange_concrete_powder": {
        "langKey": "tile.concretePowder.orange.name"
    },
    "minecraft:orange_dye": {
        "langKey": "item.dye.orange.name"
    },
    "minecraft:orange_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.orange.name"
    },
    "minecraft:orange_shulker_box": {
        "langKey": "tile.shulkerBoxOrange.name"
    },
    "minecraft:orange_stained_glass": {
        "langKey": "tile.stained_glass.orange.name"
    },
    "minecraft:orange_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.orange.name"
    },
    "minecraft:orange_terracotta": {
        "langKey": "tile.stained_hardened_clay.orange.name"
    },
    "minecraft:orange_tulip": {
        "langKey": "tile.red_flower.tulipOrange.name"
    },
    "minecraft:orange_wool": {
        "langKey": "tile.wool.orange.name"
    },
    "minecraft:oxeye_daisy": {
        "langKey": "tile.red_flower.oxeyeDaisy.name"
    },
    "minecraft:oxidized_chiseled_copper": {
        "langKey": "tile.oxidized_chiseled_copper.name"
    },
    "minecraft:oxidized_copper": {
        "langKey": "tile.oxidized_copper.name"
    },
    "minecraft:oxidized_copper_bulb": {
        "langKey": "tile.oxidized_copper_bulb.name"
    },
    "minecraft:oxidized_copper_door": {
        "langKey": "item.oxidized_copper_door.name"
    },
    "minecraft:oxidized_copper_grate": {
        "langKey": "tile.oxidized_copper_grate.name"
    },
    "minecraft:oxidized_copper_trapdoor": {
        "langKey": "tile.oxidized_copper_trapdoor.name"
    },
    "minecraft:oxidized_cut_copper": {
        "langKey": "tile.oxidized_cut_copper.name"
    },
    "minecraft:oxidized_cut_copper_slab": {
        "langKey": "tile.oxidized_cut_copper_slab.name"
    },
    "minecraft:oxidized_cut_copper_stairs": {
        "langKey": "tile.oxidized_cut_copper_stairs.name"
    },
    "minecraft:packed_ice": {
        "langKey": "tile.packed_ice.name"
    },
    "minecraft:packed_mud": {
        "langKey": "tile.packed_mud.name"
    },
    "minecraft:painting": {
        "langKey": "item.painting.name"
    },
    "minecraft:pale_hanging_moss": {
        "langKey": "tile.pale_hanging_moss.name"
    },
    "minecraft:pale_moss_block": {
        "langKey": "tile.pale_moss_block.name"
    },
    "minecraft:pale_moss_carpet": {
        "langKey": "tile.pale_moss_carpet.name"
    },
    "minecraft:pale_oak_boat": {
        "langKey": "item.boat.pale_oak.name"
    },
    "minecraft:pale_oak_button": {
        "langKey": "tile.pale_oak_button.name"
    },
    "minecraft:pale_oak_chest_boat": {
        "langKey": "item.chest_boat.pale_oak.name"
    },
    "minecraft:pale_oak_door": {
        "langKey": "item.pale_oak_door.name"
    },
    "minecraft:pale_oak_fence": {
        "langKey": "tile.pale_oak_fence.name"
    },
    "minecraft:pale_oak_fence_gate": {
        "langKey": "tile.pale_oak_fence_gate.name"
    },
    "minecraft:pale_oak_hanging_sign": {
        "langKey": "item.pale_oak_hanging_sign.name"
    },
    "minecraft:pale_oak_leaves": {
        "langKey": "tile.pale_oak_leaves.name"
    },
    "minecraft:pale_oak_log": {
        "langKey": "tile.pale_oak_log.name"
    },
    "minecraft:pale_oak_planks": {
        "langKey": "tile.pale_oak_planks.name"
    },
    "minecraft:pale_oak_pressure_plate": {
        "langKey": "tile.pale_oak_pressure_plate.name"
    },
    "minecraft:pale_oak_sapling": {
        "langKey": "tile.pale_oak_sapling.name"
    },
    "minecraft:pale_oak_sign": {
        "langKey": "item.pale_oak_sign.name"
    },
    "minecraft:pale_oak_slab": {
        "langKey": "tile.pale_oak_slab.name"
    },
    "minecraft:pale_oak_stairs": {
        "langKey": "tile.pale_oak_stairs.name"
    },
    "minecraft:pale_oak_trapdoor": {
        "langKey": "tile.pale_oak_trapdoor.name"
    },
    "minecraft:pale_oak_wood": {
        "langKey": "tile.pale_oak_wood.name"
    },
    "minecraft:panda_spawn_egg": {
        "langKey": "item.spawn_egg.entity.panda.name"
    },
    "minecraft:paper": {
        "langKey": "item.paper.name"
    },
    "minecraft:parrot_spawn_egg": {
        "langKey": "item.spawn_egg.entity.parrot.name"
    },
    "minecraft:pearlescent_froglight": {
        "langKey": "tile.pearlescent_froglight.name"
    },
    "minecraft:peony": {
        "langKey": "tile.double_plant.paeonia.name"
    },
    "minecraft:petrified_oak_slab": {
        "langKey": "tile.double_stone_slab.wood.name"
    },
    "minecraft:phantom_membrane": {
        "langKey": "item.phantom_membrane.name"
    },
    "minecraft:phantom_spawn_egg": {
        "langKey": "item.spawn_egg.entity.phantom.name"
    },
    "minecraft:pig_spawn_egg": {
        "langKey": "item.spawn_egg.entity.pig.name"
    },
    "minecraft:piglin_banner_pattern": {
        "langKey": "item.banner_pattern.piglin"
    },
    "minecraft:piglin_brute_spawn_egg": {
        "langKey": "item.spawn_egg.entity.piglin_brute.name"
    },
    "minecraft:piglin_head": {
        "langKey": "item.skull.piglin.name"
    },
    "minecraft:piglin_spawn_egg": {
        "langKey": "item.spawn_egg.entity.piglin.name"
    },
    "minecraft:pillager_spawn_egg": {
        "langKey": "item.spawn_egg.entity.pillager.name"
    },
    "minecraft:pink_bundle": {
        "langKey": "item.pink_bundle"
    },
    "minecraft:pink_candle": {
        "langKey": "tile.pink_candle.name"
    },
    "minecraft:pink_carpet": {
        "langKey": "tile.carpet.pink.name"
    },
    "minecraft:pink_concrete": {
        "langKey": "tile.concrete.pink.name"
    },
    "minecraft:pink_concrete_powder": {
        "langKey": "tile.concretePowder.pink.name"
    },
    "minecraft:pink_dye": {
        "langKey": "item.dye.pink.name"
    },
    "minecraft:pink_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.pink.name"
    },
    "minecraft:pink_petals": {
        "langKey": "tile.pink_petals.name"
    },
    "minecraft:pink_shulker_box": {
        "langKey": "tile.shulkerBoxPink.name"
    },
    "minecraft:pink_stained_glass": {
        "langKey": "tile.stained_glass.pink.name"
    },
    "minecraft:pink_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.pink.name"
    },
    "minecraft:pink_terracotta": {
        "langKey": "tile.stained_hardened_clay.pink.name"
    },
    "minecraft:pink_tulip": {
        "langKey": "tile.red_flower.tulipPink.name"
    },
    "minecraft:pink_wool": {
        "langKey": "tile.wool.pink.name"
    },
    "minecraft:piston": {
        "langKey": "tile.piston.name"
    },
    "minecraft:pitcher_plant": {
        "langKey": "tile.pitcher_plant.name"
    },
    "minecraft:pitcher_pod": {
        "langKey": "item.pitcher_pod.name"
    },
    "minecraft:planks": {
        "langKey": "tile.planks.name"
    },
    "minecraft:player_head": {
        "langKey": "item.skull.char.name"
    },
    "minecraft:plenty_pottery_shard": {
        "langKey": "item.plenty_pottery_shard.name"
    },
    "minecraft:plenty_pottery_sherd": {
        "langKey": "item.plenty_pottery_sherd.name"
    },
    "minecraft:podzol": {
        "langKey": "tile.podzol.name"
    },
    "minecraft:pointed_dripstone": {
        "langKey": "tile.pointed_dripstone.name"
    },
    "minecraft:poisonous_potato": {
        "langKey": "item.poisonous_potato.name"
    },
    "minecraft:polar_bear_spawn_egg": {
        "langKey": "item.spawn_egg.entity.polar_bear.name"
    },
    "minecraft:polished_andesite": {
        "langKey": "tile.stone.andesiteSmooth.name"
    },
    "minecraft:polished_andesite_slab": {
        "langKey": "tile.stone_slab3.andesite.smooth.name"
    },
    "minecraft:polished_andesite_stairs": {
        "langKey": "tile.polished_andesite_stairs.name"
    },
    "minecraft:polished_basalt": {
        "langKey": "tile.polished_basalt.name"
    },
    "minecraft:polished_blackstone": {
        "langKey": "tile.polished_blackstone.name"
    },
    "minecraft:polished_blackstone_brick_slab": {
        "langKey": "tile.polished_blackstone_brick_slab.name"
    },
    "minecraft:polished_blackstone_brick_stairs": {
        "langKey": "tile.polished_blackstone_brick_stairs.name"
    },
    "minecraft:polished_blackstone_brick_wall": {
        "langKey": "tile.polished_blackstone_brick_wall.name"
    },
    "minecraft:polished_blackstone_bricks": {
        "langKey": "tile.polished_blackstone_bricks.name"
    },
    "minecraft:polished_blackstone_button": {
        "langKey": "tile.polished_blackstone_button.name"
    },
    "minecraft:polished_blackstone_pressure_plate": {
        "langKey": "tile.polished_blackstone_pressure_plate.name"
    },
    "minecraft:polished_blackstone_slab": {
        "langKey": "tile.polished_blackstone_slab.name"
    },
    "minecraft:polished_blackstone_stairs": {
        "langKey": "tile.polished_blackstone_stairs.name"
    },
    "minecraft:polished_blackstone_wall": {
        "langKey": "tile.polished_blackstone_wall.name"
    },
    "minecraft:polished_deepslate": {
        "langKey": "tile.polished_deepslate.name"
    },
    "minecraft:polished_deepslate_slab": {
        "langKey": "tile.polished_deepslate_slab.name"
    },
    "minecraft:polished_deepslate_stairs": {
        "langKey": "tile.polished_deepslate_stairs.name"
    },
    "minecraft:polished_deepslate_wall": {
        "langKey": "tile.polished_deepslate_wall.name"
    },
    "minecraft:polished_diorite": {
        "langKey": "tile.stone.dioriteSmooth.name"
    },
    "minecraft:polished_diorite_slab": {
        "langKey": "tile.stone_slab3.diorite.smooth.name"
    },
    "minecraft:polished_diorite_stairs": {
        "langKey": "tile.polished_diorite_stairs.name"
    },
    "minecraft:polished_granite": {
        "langKey": "tile.stone.graniteSmooth.name"
    },
    "minecraft:polished_granite_slab": {
        "langKey": "tile.stone_slab3.granite.smooth.name"
    },
    "minecraft:polished_granite_stairs": {
        "langKey": "tile.polished_granite_stairs.name"
    },
    "minecraft:polished_tuff": {
        "langKey": "tile.polished_tuff.name"
    },
    "minecraft:polished_tuff_slab": {
        "langKey": "tile.polished_tuff_slab.name"
    },
    "minecraft:polished_tuff_stairs": {
        "langKey": "tile.polished_tuff_stairs.name"
    },
    "minecraft:polished_tuff_wall": {
        "langKey": "tile.polished_tuff_wall.name"
    },
    "minecraft:popped_chorus_fruit": {
        "langKey": "item.chorus_fruit_popped.name"
    },
    "minecraft:poppy": {
        "langKey": "tile.red_flower.poppy.name"
    },
    "minecraft:porkchop": {
        "langKey": "item.porkchop.name"
    },
    "minecraft:potato": {
        "langKey": "item.potato.name"
    },
    "minecraft:potion": {
        "langKey": "potion.moveSlowdown.name"
    },
    "minecraft:powder_snow_bucket": {
        "langKey": "item.bucketPowderSnow.name"
    },
    "minecraft:prismarine": {
        "langKey": "tile.prismarine.bricks.name"
    },
    "minecraft:prismarine_brick_slab": {
        "langKey": "tile.stone_slab2.prismarine.bricks.name"
    },
    "minecraft:prismarine_bricks": {
        "langKey": "tile.prismarine.bricks.name"
    },
    "minecraft:prismarine_bricks_stairs": {
        "langKey": "tile.prismarine_bricks_stairs.name"
    },
    "minecraft:prismarine_crystals": {
        "langKey": "item.prismarine_crystals.name"
    },
    "minecraft:prismarine_shard": {
        "langKey": "item.prismarine_shard.name"
    },
    "minecraft:prismarine_slab": {
        "langKey": "tile.stone_slab2.prismarine.rough.name"
    },
    "minecraft:prismarine_stairs": {
        "langKey": "tile.prismarine_stairs.name"
    },
    "minecraft:prismarine_wall": {
        "langKey": "tile.cobblestone_wall.prismarine.name"
    },
    "minecraft:prize_pottery_shard": {
        "langKey": "item.prize_pottery_shard.name"
    },
    "minecraft:prize_pottery_sherd": {
        "langKey": "item.prize_pottery_sherd.name"
    },
    "minecraft:pufferfish": {
        "langKey": "item.pufferfish.name"
    },
    "minecraft:pufferfish_bucket": {
        "langKey": "item.bucketPuffer.name"
    },
    "minecraft:pufferfish_spawn_egg": {
        "langKey": "item.spawn_egg.entity.pufferfish.name"
    },
    "minecraft:pumpkin": {
        "langKey": "tile.pumpkin.name"
    },
    "minecraft:pumpkin_pie": {
        "langKey": "item.pumpkin_pie.name"
    },
    "minecraft:pumpkin_seeds": {
        "langKey": "item.pumpkin_seeds.name"
    },
    "minecraft:purple_bundle": {
        "langKey": "item.purple_bundle"
    },
    "minecraft:purple_candle": {
        "langKey": "tile.purple_candle.name"
    },
    "minecraft:purple_carpet": {
        "langKey": "tile.carpet.purple.name"
    },
    "minecraft:purple_concrete": {
        "langKey": "tile.concrete.purple.name"
    },
    "minecraft:purple_concrete_powder": {
        "langKey": "tile.concretePowder.purple.name"
    },
    "minecraft:purple_dye": {
        "langKey": "item.dye.purple.name"
    },
    "minecraft:purple_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.purple.name"
    },
    "minecraft:purple_shulker_box": {
        "langKey": "tile.shulkerBoxPurple.name"
    },
    "minecraft:purple_stained_glass": {
        "langKey": "tile.stained_glass.purple.name"
    },
    "minecraft:purple_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.purple.name"
    },
    "minecraft:purple_terracotta": {
        "langKey": "tile.stained_hardened_clay.purple.name"
    },
    "minecraft:purple_wool": {
        "langKey": "tile.wool.purple.name"
    },
    "minecraft:purpur_block": {
        "langKey": "tile.purpur_block.lines.name"
    },
    "minecraft:purpur_pillar": {
        "langKey": "tile.purpur_block.lines.name"
    },
    "minecraft:purpur_slab": {
        "langKey": "tile.stone_slab2.purpur.name"
    },
    "minecraft:purpur_stairs": {
        "langKey": "tile.purpur_stairs.name"
    },
    "minecraft:quartz": {
        "langKey": "item.quartz.name"
    },
    "minecraft:quartz_block": {
        "langKey": "tile.quartz_block.name"
    },
    "minecraft:quartz_bricks": {
        "langKey": "tile.quartz_bricks.name"
    },
    "minecraft:quartz_ore": {
        "langKey": "tile.quartz_ore.name"
    },
    "minecraft:quartz_pillar": {
        "langKey": "tile.quartz_block.lines.name"
    },
    "minecraft:quartz_slab": {
        "langKey": "tile.double_stone_slab.quartz.name"
    },
    "minecraft:quartz_stairs": {
        "langKey": "tile.quartz_stairs.name"
    },
    "minecraft:rabbit": {
        "langKey": "item.rabbit.name"
    },
    "minecraft:rabbit_foot": {
        "langKey": "item.rabbit_foot.name"
    },
    "minecraft:rabbit_hide": {
        "langKey": "item.rabbit_hide.name"
    },
    "minecraft:rabbit_spawn_egg": {
        "langKey": "item.spawn_egg.entity.rabbit.name"
    },
    "minecraft:rabbit_stew": {
        "langKey": "item.rabbit_stew.name"
    },
    "minecraft:rail": {
        "langKey": "tile.rail.name"
    },
    "minecraft:raiser_armor_trim_smithing_template": {
        "langKey": "trim_pattern.raiser.name"
    },
    "minecraft:ravager_spawn_egg": {
        "langKey": "item.spawn_egg.entity.ravager.name"
    },
    "minecraft:raw_copper": {
        "langKey": "item.raw_copper.name"
    },
    "minecraft:raw_copper_block": {
        "langKey": "tile.raw_copper_block.name"
    },
    "minecraft:raw_gold": {
        "langKey": "item.raw_gold.name"
    },
    "minecraft:raw_gold_block": {
        "langKey": "tile.raw_gold_block.name"
    },
    "minecraft:raw_iron": {
        "langKey": "item.raw_iron.name"
    },
    "minecraft:raw_iron_block": {
        "langKey": "tile.raw_iron_block.name"
    },
    "minecraft:recovery_compass": {
        "langKey": "item.recovery_compass.name"
    },
    "minecraft:red_bundle": {
        "langKey": "item.red_bundle"
    },
    "minecraft:red_candle": {
        "langKey": "tile.red_candle.name"
    },
    "minecraft:red_carpet": {
        "langKey": "tile.carpet.red.name"
    },
    "minecraft:red_concrete": {
        "langKey": "tile.concrete.red.name"
    },
    "minecraft:red_concrete_powder": {
        "langKey": "tile.concretePowder.red.name"
    },
    "minecraft:red_dye": {
        "langKey": "item.dye.red.name"
    },
    "minecraft:red_flower": {
        "langKey": "tile.red_flower.lilyOfTheValley.name"
    },
    "minecraft:red_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.red.name"
    },
    "minecraft:red_mushroom": {
        "langKey": "tile.red_mushroom.name"
    },
    "minecraft:red_mushroom_block": {
        "langKey": "tile.red_mushroom_block.name"
    },
    "minecraft:red_nether_brick": {
        "langKey": "tile.red_nether_brick.name"
    },
    "minecraft:red_nether_brick_slab": {
        "langKey": "tile.stone_slab2.red_nether_brick.name"
    },
    "minecraft:red_nether_brick_stairs": {
        "langKey": "tile.red_nether_brick_stairs.name"
    },
    "minecraft:red_nether_brick_wall": {
        "langKey": "tile.cobblestone_wall.red_nether_brick.name"
    },
    "minecraft:red_sand": {
        "langKey": "tile.sand.red.name"
    },
    "minecraft:red_sandstone": {
        "langKey": "tile.red_sandstone.name"
    },
    "minecraft:red_sandstone_slab": {
        "langKey": "tile.double_stone_slab2.red_sandstone.name"
    },
    "minecraft:red_sandstone_stairs": {
        "langKey": "tile.red_sandstone_stairs.name"
    },
    "minecraft:red_sandstone_wall": {
        "langKey": "tile.cobblestone_wall.red_sandstone.name"
    },
    "minecraft:red_shulker_box": {
        "langKey": "tile.shulkerBoxRed.name"
    },
    "minecraft:red_stained_glass": {
        "langKey": "tile.stained_glass.red.name"
    },
    "minecraft:red_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.red.name"
    },
    "minecraft:red_terracotta": {
        "langKey": "tile.stained_hardened_clay.red.name"
    },
    "minecraft:red_tulip": {
        "langKey": "tile.red_flower.tulipRed.name"
    },
    "minecraft:red_wool": {
        "langKey": "tile.wool.red.name"
    },
    "minecraft:redstone": {
        "langKey": "item.redstone.name"
    },
    "minecraft:redstone_block": {
        "langKey": "tile.redstone_block.name"
    },
    "minecraft:redstone_lamp": {
        "langKey": "tile.redstone_lamp.name"
    },
    "minecraft:redstone_ore": {
        "langKey": "tile.redstone_ore.name"
    },
    "minecraft:redstone_torch": {
        "langKey": "tile.redstone_torch.name"
    },
    "minecraft:reinforced_deepslate": {
        "langKey": "tile.reinforced_deepslate.name"
    },
    "minecraft:repeater": {
        "langKey": "item.repeater.name"
    },
    "minecraft:repeating_command_block": {
        "langKey": "tile.repeating_command_block.name"
    },
    "minecraft:resin_block": {
        "langKey": "tile.resin_block.name"
    },
    "minecraft:resin_brick": {
        "langKey": "item.resin_brick.name"
    },
    "minecraft:resin_brick_slab": {
        "langKey": "tile.resin_brick_slab.name"
    },
    "minecraft:resin_brick_stairs": {
        "langKey": "tile.resin_brick_stairs.name"
    },
    "minecraft:resin_brick_wall": {
        "langKey": "tile.resin_brick_wall.name"
    },
    "minecraft:resin_bricks": {
        "langKey": "tile.resin_bricks.name"
    },
    "minecraft:resin_clump": {
        "langKey": "tile.resin_clump.name"
    },
    "minecraft:respawn_anchor": {
        "langKey": "tile.respawn_anchor.name"
    },
    "minecraft:rib_armor_trim_smithing_template": {
        "langKey": "trim_pattern.rib.name"
    },
    "minecraft:rose_bush": {
        "langKey": "tile.double_plant.rose.name"
    },
    "minecraft:rotten_flesh": {
        "langKey": "item.rotten_flesh.name"
    },
    "minecraft:saddle": {
        "langKey": "item.saddle.name"
    },
    "minecraft:salmon": {
        "langKey": "item.salmon.name"
    },
    "minecraft:salmon_bucket": {
        "langKey": "item.bucketSalmon.name"
    },
    "minecraft:salmon_spawn_egg": {
        "langKey": "item.spawn_egg.entity.salmon.name"
    },
    "minecraft:sand": {
        "langKey": "tile.sand.name"
    },
    "minecraft:sandstone": {
        "langKey": "tile.sandstone.name"
    },
    "minecraft:sandstone_slab": {
        "langKey": "tile.double_stone_slab.sand.name"
    },
    "minecraft:sandstone_stairs": {
        "langKey": "tile.sandstone_stairs.name"
    },
    "minecraft:sandstone_wall": {
        "langKey": "tile.cobblestone_wall.sandstone.name"
    },
    "minecraft:sapling": {
        "langKey": "tile.sapling.big_oak.name"
    },
    "minecraft:scaffolding": {
        "langKey": "tile.scaffolding.name"
    },
    "minecraft:scrape_pottery_sherd": {
        "langKey": "item.scrape_pottery_sherd.name"
    },
    "minecraft:sculk": {
        "langKey": "tile.sculk.name"
    },
    "minecraft:sculk_catalyst": {
        "langKey": "tile.sculk_catalyst.name"
    },
    "minecraft:sculk_sensor": {
        "langKey": "tile.sculk_sensor.name"
    },
    "minecraft:sculk_shrieker": {
        "langKey": "tile.sculk_shrieker.name"
    },
    "minecraft:sculk_vein": {
        "langKey": "tile.sculk_vein.name"
    },
    "minecraft:scute": {
        "langKey": "item.turtle_shell_piece.name"
    },
    "minecraft:sea_lantern": {
        "langKey": "tile.seaLantern.name"
    },
    "minecraft:sea_pickle": {
        "langKey": "tile.sea_pickle.name"
    },
    "minecraft:seagrass": {
        "langKey": "tile.seagrass.seagrass.name"
    },
    "minecraft:sentry_armor_trim_smithing_template": {
        "langKey": "trim_pattern.sentry.name"
    },
    "minecraft:shaper_armor_trim_smithing_template": {
        "langKey": "trim_pattern.shaper.name"
    },
    "minecraft:sheaf_pottery_shard": {
        "langKey": "item.sheaf_pottery_shard.name"
    },
    "minecraft:sheaf_pottery_sherd": {
        "langKey": "item.sheaf_pottery_sherd.name"
    },
    "minecraft:shears": {
        "langKey": "item.shears.name"
    },
    "minecraft:sheep_spawn_egg": {
        "langKey": "item.spawn_egg.entity.sheep.name"
    },
    "minecraft:shelter_pottery_shard": {
        "langKey": "item.shelter_pottery_shard.name"
    },
    "minecraft:shelter_pottery_sherd": {
        "langKey": "item.shelter_pottery_sherd.name"
    },
    "minecraft:shield": {
        "langKey": "item.shield.name"
    },
    "minecraft:short_dry_grass": {
        "langKey": "tile.short_dry_grass.name"
    },
    "minecraft:short_grass": {
        "langKey": "tile.tallgrass.grass.name"
    },
    "minecraft:shroomlight": {
        "langKey": "tile.shroomlight.name"
    },
    "minecraft:shulker_box": {
        "langKey": "tile.shulkerBoxBlack.name"
    },
    "minecraft:shulker_shell": {
        "langKey": "item.shulker_shell.name"
    },
    "minecraft:shulker_spawn_egg": {
        "langKey": "item.spawn_egg.entity.shulker.name"
    },
    "minecraft:silence_armor_trim_smithing_template": {
        "langKey": "trim_pattern.silence.name"
    },
    "minecraft:silver_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.silver.name"
    },
    "minecraft:silverfish_spawn_egg": {
        "langKey": "item.spawn_egg.entity.silverfish.name"
    },
    "minecraft:skeleton_horse_spawn_egg": {
        "langKey": "item.spawn_egg.entity.skeleton_horse.name"
    },
    "minecraft:skeleton_skull": {
        "langKey": "item.skull.skeleton.name"
    },
    "minecraft:skeleton_spawn_egg": {
        "langKey": "item.spawn_egg.entity.skeleton.name"
    },
    "minecraft:skull": {
        "langKey": "item.skull.player.name"
    },
    "minecraft:skull_banner_pattern": {
        "langKey": "item.banner_pattern.skull"
    },
    "minecraft:skull_pottery_shard": {
        "langKey": "item.skull_pottery_shard.name"
    },
    "minecraft:skull_pottery_sherd": {
        "langKey": "item.skull_pottery_sherd.name"
    },
    "minecraft:slime": {
        "langKey": "tile.slime.name"
    },
    "minecraft:slime_ball": {
        "langKey": "item.slime_ball.name"
    },
    "minecraft:slime_spawn_egg": {
        "langKey": "item.spawn_egg.entity.slime.name"
    },
    "minecraft:small_amethyst_bud": {
        "langKey": "tile.small_amethyst_bud.name"
    },
    "minecraft:small_dripleaf_block": {
        "langKey": "tile.small_dripleaf_block.name"
    },
    "minecraft:smithing_table": {
        "langKey": "tile.smithing_table.name"
    },
    "minecraft:smoker": {
        "langKey": "tile.smoker.name"
    },
    "minecraft:smooth_basalt": {
        "langKey": "tile.smooth_basalt.name"
    },
    "minecraft:smooth_quartz": {
        "langKey": "tile.quartz_block.smooth.name"
    },
    "minecraft:smooth_quartz_slab": {
        "langKey": "tile.stone_slab4.smooth_quartz.name"
    },
    "minecraft:smooth_quartz_stairs": {
        "langKey": "tile.smooth_quartz_stairs.name"
    },
    "minecraft:smooth_red_sandstone": {
        "langKey": "tile.red_sandstone.smooth.name"
    },
    "minecraft:smooth_red_sandstone_slab": {
        "langKey": "tile.stone_slab3.red_sandstone.smooth.name"
    },
    "minecraft:smooth_red_sandstone_stairs": {
        "langKey": "tile.smooth_red_sandstone_stairs.name"
    },
    "minecraft:smooth_sandstone": {
        "langKey": "tile.sandstone.smooth.name"
    },
    "minecraft:smooth_sandstone_slab": {
        "langKey": "tile.stone_slab2.sandstone.smooth.name"
    },
    "minecraft:smooth_sandstone_stairs": {
        "langKey": "tile.smooth_sandstone_stairs.name"
    },
    "minecraft:smooth_stone": {
        "langKey": "tile.smooth_stone.name"
    },
    "minecraft:smooth_stone_slab": {
        "langKey": "tile.stone_slab.stone.name"
    },
    "minecraft:sniffer_egg": {
        "langKey": "tile.sniffer_egg.name"
    },
    "minecraft:sniffer_spawn_egg": {
        "langKey": "item.spawn_egg.entity.sniffer.name"
    },
    "minecraft:snort_pottery_shard": {
        "langKey": "item.snort_pottery_shard.name"
    },
    "minecraft:snort_pottery_sherd": {
        "langKey": "item.snort_pottery_sherd.name"
    },
    "minecraft:snout_armor_trim_smithing_template": {
        "langKey": "trim_pattern.snout.name"
    },
    "minecraft:snow": {
        "langKey": "tile.snow.name"
    },
    "minecraft:snow_golem_spawn_egg": {
        "langKey": "item.spawn_egg.entity.snow_golem.name"
    },
    "minecraft:snow_layer": {
        "langKey": "tile.snow_layer.name"
    },
    "minecraft:snowball": {
        "langKey": "item.snowball.name"
    },
    "minecraft:soul_campfire": {
        "langKey": "tile.soul_campfire.name"
    },
    "minecraft:soul_lantern": {
        "langKey": "tile.soul_lantern.name"
    },
    "minecraft:soul_sand": {
        "langKey": "tile.soul_sand.name"
    },
    "minecraft:soul_soil": {
        "langKey": "tile.soul_soil.name"
    },
    "minecraft:soul_torch": {
        "langKey": "tile.soul_torch.name"
    },
    "minecraft:spider_eye": {
        "langKey": "item.spider_eye.name"
    },
    "minecraft:spider_spawn_egg": {
        "langKey": "item.spawn_egg.entity.spider.name"
    },
    "minecraft:spire_armor_trim_smithing_template": {
        "langKey": "trim_pattern.spire.name"
    },
    "minecraft:splash_potion": {
        "langKey": "potion.moveSlowdown.splash.name"
    },
    "minecraft:sponge": {
        "langKey": "tile.sponge.wet.name"
    },
    "minecraft:spore_blossom": {
        "langKey": "tile.spore_blossom.name"
    },
    "minecraft:spruce_boat": {
        "langKey": "item.boat.spruce.name"
    },
    "minecraft:spruce_button": {
        "langKey": "tile.spruce_button.name"
    },
    "minecraft:spruce_chest_boat": {
        "langKey": "item.chest_boat.spruce.name"
    },
    "minecraft:spruce_door": {
        "langKey": "item.spruce_door.name"
    },
    "minecraft:spruce_fence": {
        "langKey": "tile.spruceFence.name"
    },
    "minecraft:spruce_fence_gate": {
        "langKey": "tile.spruce_fence_gate.name"
    },
    "minecraft:spruce_hanging_sign": {
        "langKey": "item.spruce_hanging_sign.name"
    },
    "minecraft:spruce_leaves": {
        "langKey": "tile.leaves.spruce.name"
    },
    "minecraft:spruce_log": {
        "langKey": "tile.log.spruce.name"
    },
    "minecraft:spruce_planks": {
        "langKey": "tile.planks.spruce.name"
    },
    "minecraft:spruce_pressure_plate": {
        "langKey": "tile.spruce_pressure_plate.name"
    },
    "minecraft:spruce_sapling": {
        "langKey": "tile.sapling.spruce.name"
    },
    "minecraft:spruce_sign": {
        "langKey": "item.spruce_sign.name"
    },
    "minecraft:spruce_slab": {
        "langKey": "tile.wooden_slab.spruce.name"
    },
    "minecraft:spruce_stairs": {
        "langKey": "tile.spruce_stairs.name"
    },
    "minecraft:spruce_trapdoor": {
        "langKey": "tile.spruce_trapdoor.name"
    },
    "minecraft:spruce_wood": {
        "langKey": "tile.wood.spruce.name"
    },
    "minecraft:spyglass": {
        "langKey": "item.spyglass.name"
    },
    "minecraft:squid_spawn_egg": {
        "langKey": "item.spawn_egg.entity.squid.name"
    },
    "minecraft:stained_glass": {
        "langKey": "tile.stained_glass.black.name"
    },
    "minecraft:stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.black.name"
    },
    "minecraft:stained_hardened_clay": {
        "langKey": "tile.stained_hardened_clay.name"
    },
    "minecraft:stick": {
        "langKey": "item.stick.name"
    },
    "minecraft:sticky_piston": {
        "langKey": "tile.sticky_piston.name"
    },
    "minecraft:stone": {
        "langKey": "tile.stone.stone.name"
    },
    "minecraft:stone_axe": {
        "langKey": "item.stone_axe.name"
    },
    "minecraft:stone_block_slab": {
        "langKey": "tile.stone_slab.name"
    },
    "minecraft:stone_block_slab2": {
        "langKey": "tile.stone_slab2.red_nether_brick.name"
    },
    "minecraft:stone_block_slab3": {
        "langKey": "tile.stone_slab3.granite.smooth.name"
    },
    "minecraft:stone_block_slab4": {
        "langKey": "tile.stone_slab4.cut_red_sandstone.name"
    },
    "minecraft:stone_brick_slab": {
        "langKey": "tile.double_stone_slab.smoothStoneBrick.name"
    },
    "minecraft:stone_brick_stairs": {
        "langKey": "tile.stone_brick_stairs.name"
    },
    "minecraft:stone_brick_wall": {
        "langKey": "tile.cobblestone_wall.stone_brick.name"
    },
    "minecraft:stone_bricks": {
        "langKey": "tile.stonebrick.default.name"
    },
    "minecraft:stone_button": {
        "langKey": "tile.stone_button.name"
    },
    "minecraft:stone_hoe": {
        "langKey": "item.stone_hoe.name"
    },
    "minecraft:stone_pickaxe": {
        "langKey": "item.stone_pickaxe.name"
    },
    "minecraft:stone_pressure_plate": {
        "langKey": "tile.stone_pressure_plate.name"
    },
    "minecraft:stone_shovel": {
        "langKey": "item.stone_shovel.name"
    },
    "minecraft:stone_stairs": {
        "langKey": "tile.stone_stairs.name"
    },
    "minecraft:stone_sword": {
        "langKey": "item.stone_sword.name"
    },
    "minecraft:stonebrick": {
        "langKey": "tile.stonebrick.name"
    },
    "minecraft:stonecutter_block": {
        "langKey": "tile.stonecutter_block.name"
    },
    "minecraft:stray_spawn_egg": {
        "langKey": "item.spawn_egg.entity.stray.name"
    },
    "minecraft:strider_spawn_egg": {
        "langKey": "item.spawn_egg.entity.strider.name"
    },
    "minecraft:string": {
        "langKey": "item.string.name"
    },
    "minecraft:stripped_acacia_log": {
        "langKey": "tile.stripped_acacia_log.name"
    },
    "minecraft:stripped_acacia_wood": {
        "langKey": "tile.wood.stripped.acacia.name"
    },
    "minecraft:stripped_bamboo_block": {
        "langKey": "tile.stripped_bamboo_block.name"
    },
    "minecraft:stripped_birch_log": {
        "langKey": "tile.stripped_birch_log.name"
    },
    "minecraft:stripped_birch_wood": {
        "langKey": "tile.wood.stripped.birch.name"
    },
    "minecraft:stripped_cherry_log": {
        "langKey": "tile.stripped_cherry_log.name"
    },
    "minecraft:stripped_cherry_wood": {
        "langKey": "tile.stripped_cherry_wood.name"
    },
    "minecraft:stripped_crimson_hyphae": {
        "langKey": "tile.stripped_crimson_hyphae.name"
    },
    "minecraft:stripped_crimson_stem": {
        "langKey": "tile.stripped_crimson_stem.name"
    },
    "minecraft:stripped_dark_oak_log": {
        "langKey": "tile.stripped_dark_oak_log.name"
    },
    "minecraft:stripped_dark_oak_wood": {
        "langKey": "tile.wood.stripped.dark_oak.name"
    },
    "minecraft:stripped_jungle_log": {
        "langKey": "tile.stripped_jungle_log.name"
    },
    "minecraft:stripped_jungle_wood": {
        "langKey": "tile.wood.stripped.jungle.name"
    },
    "minecraft:stripped_mangrove_log": {
        "langKey": "tile.stripped_mangrove_log.name"
    },
    "minecraft:stripped_mangrove_wood": {
        "langKey": "tile.stripped_mangrove_wood.name"
    },
    "minecraft:stripped_oak_log": {
        "langKey": "tile.stripped_oak_log.name"
    },
    "minecraft:stripped_oak_wood": {
        "langKey": "tile.wood.stripped.oak.name"
    },
    "minecraft:stripped_pale_oak_log": {
        "langKey": "tile.stripped_pale_oak_log.name"
    },
    "minecraft:stripped_pale_oak_wood": {
        "langKey": "tile.stripped_pale_oak_wood.name"
    },
    "minecraft:stripped_spruce_log": {
        "langKey": "tile.stripped_spruce_log.name"
    },
    "minecraft:stripped_spruce_wood": {
        "langKey": "tile.wood.stripped.spruce.name"
    },
    "minecraft:stripped_warped_hyphae": {
        "langKey": "tile.stripped_warped_hyphae.name"
    },
    "minecraft:stripped_warped_stem": {
        "langKey": "tile.stripped_warped_stem.name"
    },
    "minecraft:structure_block": {
        "langKey": "tile.structure_block.name"
    },
    "minecraft:structure_void": {
        "langKey": "tile.structure_void.name"
    },
    "minecraft:sugar": {
        "langKey": "item.sugar.name"
    },
    "minecraft:sugar_cane": {
        "langKey": "item.reeds.name"
    },
    "minecraft:sunflower": {
        "langKey": "tile.double_plant.sunflower.name"
    },
    "minecraft:suspicious_gravel": {
        "langKey": "tile.suspicious_gravel.name"
    },
    "minecraft:suspicious_sand": {
        "langKey": "tile.suspicious_sand.name"
    },
    "minecraft:suspicious_stew": {
        "langKey": "item.suspicious_stew.name"
    },
    "minecraft:sweet_berries": {
        "langKey": "item.sweet_berries.name"
    },
    "minecraft:tadpole_bucket": {
        "langKey": "item.bucketTadpole.name"
    },
    "minecraft:tadpole_spawn_egg": {
        "langKey": "item.spawn_egg.entity.tadpole.name"
    },
    "minecraft:tall_dry_grass": {
        "langKey": "tile.tall_dry_grass.name"
    },
    "minecraft:tall_grass": {
        "langKey": "tile.double_plant.grass.name"
    },
    "minecraft:tallgrass": {
        "langKey": "tile.tallgrass.name"
    },
    "minecraft:target": {
        "langKey": "tile.target.name"
    },
    "minecraft:tide_armor_trim_smithing_template": {
        "langKey": "trim_pattern.tide.name"
    },
    "minecraft:tinted_glass": {
        "langKey": "tile.tinted_glass.name"
    },
    "minecraft:tnt": {
        "langKey": "tile.tnt.name"
    },
    "minecraft:tnt_minecart": {
        "langKey": "item.tnt_minecart.name"
    },
    "minecraft:torch": {
        "langKey": "tile.torch.name"
    },
    "minecraft:torchflower": {
        "langKey": "tile.torchflower.name"
    },
    "minecraft:torchflower_seeds": {
        "langKey": "item.torchflower_seeds.name"
    },
    "minecraft:totem_of_undying": {
        "langKey": "item.totem.name"
    },
    "minecraft:trader_llama_spawn_egg": {
        "langKey": "item.spawn_egg.entity.trader_llama.name"
    },
    "minecraft:trapdoor": {
        "langKey": "tile.trapdoor.name"
    },
    "minecraft:trapped_chest": {
        "langKey": "tile.trapped_chest.name"
    },
    "minecraft:trial_key": {
        "langKey": "item.trial_key.name"
    },
    "minecraft:trial_spawner": {
        "langKey": "tile.trial_spawner.name"
    },
    "minecraft:trident": {
        "langKey": "item.trident.name"
    },
    "minecraft:tripwire_hook": {
        "langKey": "tile.tripwire_hook.name"
    },
    "minecraft:tropical_fish": {
        "langKey": "item.clownfish.name"
    },
    "minecraft:tropical_fish_bucket": {
        "langKey": "item.bucketTropical.name"
    },
    "minecraft:tropical_fish_spawn_egg": {
        "langKey": "item.spawn_egg.entity.tropicalfish.name"
    },
    "minecraft:tube_coral": {
        "langKey": "tile.coral_fan.blue_fan.name"
    },
    "minecraft:tube_coral_block": {
        "langKey": "tile.coral_block.blue.name"
    },
    "minecraft:tube_coral_fan": {
        "langKey": "tile.coral_fan.blue_fan.name"
    },
    "minecraft:tuff": {
        "langKey": "tile.tuff.name"
    },
    "minecraft:tuff_brick_slab": {
        "langKey": "tile.tuff_brick_slab.name"
    },
    "minecraft:tuff_brick_stairs": {
        "langKey": "tile.tuff_brick_stairs.name"
    },
    "minecraft:tuff_brick_wall": {
        "langKey": "tile.tuff_brick_wall.name"
    },
    "minecraft:tuff_bricks": {
        "langKey": "tile.tuff_bricks.name"
    },
    "minecraft:tuff_slab": {
        "langKey": "tile.tuff_slab.name"
    },
    "minecraft:tuff_stairs": {
        "langKey": "tile.tuff_stairs.name"
    },
    "minecraft:tuff_wall": {
        "langKey": "tile.tuff_wall.name"
    },
    "minecraft:turtle_egg": {
        "langKey": "tile.turtle_egg.name"
    },
    "minecraft:turtle_helmet": {
        "langKey": "item.turtle_helmet.name"
    },
    "minecraft:turtle_scute": {
        "langKey": "item.turtle_shell_piece.name"
    },
    "minecraft:turtle_spawn_egg": {
        "langKey": "item.spawn_egg.entity.turtle.name"
    },
    "minecraft:twisting_vines": {
        "langKey": "tile.twisting_vines.name"
    },
    "minecraft:undyed_shulker_box": {
        "langKey": "tile.shulkerBox.name"
    },
    "minecraft:vault": {
        "langKey": "tile.vault.name"
    },
    "minecraft:verdant_froglight": {
        "langKey": "tile.verdant_froglight.name"
    },
    "minecraft:vex_armor_trim_smithing_template": {
        "langKey": "trim_pattern.vex.name"
    },
    "minecraft:vex_spawn_egg": {
        "langKey": "item.spawn_egg.entity.vex.name"
    },
    "minecraft:villager_spawn_egg": {
        "langKey": "item.spawn_egg.entity.villager.name"
    },
    "minecraft:vindicator_spawn_egg": {
        "langKey": "item.spawn_egg.entity.vindicator.name"
    },
    "minecraft:vine": {
        "langKey": "tile.vine.name"
    },
    "minecraft:wandering_trader_spawn_egg": {
        "langKey": "item.spawn_egg.entity.wandering_trader.name"
    },
    "minecraft:ward_armor_trim_smithing_template": {
        "langKey": "trim_pattern.ward.name"
    },
    "minecraft:warden_spawn_egg": {
        "langKey": "item.spawn_egg.entity.warden.name"
    },
    "minecraft:warped_button": {
        "langKey": "tile.warped_button.name"
    },
    "minecraft:warped_door": {
        "langKey": "item.warped_door.name"
    },
    "minecraft:warped_fence": {
        "langKey": "tile.warped_fence.name"
    },
    "minecraft:warped_fence_gate": {
        "langKey": "tile.warped_fence_gate.name"
    },
    "minecraft:warped_fungus": {
        "langKey": "tile.warped_fungus.name"
    },
    "minecraft:warped_fungus_on_a_stick": {
        "langKey": "item.warped_fungus_on_a_stick.name"
    },
    "minecraft:warped_hanging_sign": {
        "langKey": "item.warped_hanging_sign.name"
    },
    "minecraft:warped_hyphae": {
        "langKey": "tile.warped_hyphae.name"
    },
    "minecraft:warped_nylium": {
        "langKey": "tile.warped_nylium.name"
    },
    "minecraft:warped_planks": {
        "langKey": "tile.warped_planks.name"
    },
    "minecraft:warped_pressure_plate": {
        "langKey": "tile.warped_pressure_plate.name"
    },
    "minecraft:warped_roots": {
        "langKey": "tile.warped_roots.warpedRoots.name"
    },
    "minecraft:warped_sign": {
        "langKey": "item.warped_sign.name"
    },
    "minecraft:warped_slab": {
        "langKey": "tile.warped_slab.name"
    },
    "minecraft:warped_stairs": {
        "langKey": "tile.warped_stairs.name"
    },
    "minecraft:warped_stem": {
        "langKey": "tile.warped_stem.name"
    },
    "minecraft:warped_trapdoor": {
        "langKey": "tile.warped_trapdoor.name"
    },
    "minecraft:warped_wart_block": {
        "langKey": "tile.warped_wart_block.name"
    },
    "minecraft:water_bucket": {
        "langKey": "item.bucketWater.name"
    },
    "minecraft:waterlily": {
        "langKey": "tile.waterlily.name"
    },
    "minecraft:waxed_chiseled_copper": {
        "langKey": "tile.waxed_chiseled_copper.name"
    },
    "minecraft:waxed_copper": {
        "langKey": "tile.waxed_copper.name"
    },
    "minecraft:waxed_copper_bulb": {
        "langKey": "tile.waxed_copper_bulb.name"
    },
    "minecraft:waxed_copper_door": {
        "langKey": "item.waxed_copper_door.name"
    },
    "minecraft:waxed_copper_grate": {
        "langKey": "tile.waxed_copper_grate.name"
    },
    "minecraft:waxed_copper_trapdoor": {
        "langKey": "tile.waxed_copper_trapdoor.name"
    },
    "minecraft:waxed_cut_copper": {
        "langKey": "tile.waxed_cut_copper.name"
    },
    "minecraft:waxed_cut_copper_slab": {
        "langKey": "tile.waxed_cut_copper_slab.name"
    },
    "minecraft:waxed_cut_copper_stairs": {
        "langKey": "tile.waxed_cut_copper_stairs.name"
    },
    "minecraft:waxed_exposed_chiseled_copper": {
        "langKey": "tile.waxed_exposed_chiseled_copper.name"
    },
    "minecraft:waxed_exposed_copper": {
        "langKey": "tile.waxed_exposed_copper.name"
    },
    "minecraft:waxed_exposed_copper_bulb": {
        "langKey": "tile.waxed_exposed_copper_bulb.name"
    },
    "minecraft:waxed_exposed_copper_door": {
        "langKey": "item.waxed_exposed_copper_door.name"
    },
    "minecraft:waxed_exposed_copper_grate": {
        "langKey": "tile.waxed_exposed_copper_grate.name"
    },
    "minecraft:waxed_exposed_copper_trapdoor": {
        "langKey": "tile.waxed_exposed_copper_trapdoor.name"
    },
    "minecraft:waxed_exposed_cut_copper": {
        "langKey": "tile.waxed_exposed_cut_copper.name"
    },
    "minecraft:waxed_exposed_cut_copper_slab": {
        "langKey": "tile.waxed_exposed_cut_copper_slab.name"
    },
    "minecraft:waxed_exposed_cut_copper_stairs": {
        "langKey": "tile.waxed_exposed_cut_copper_stairs.name"
    },
    "minecraft:waxed_oxidized_chiseled_copper": {
        "langKey": "tile.waxed_oxidized_chiseled_copper.name"
    },
    "minecraft:waxed_oxidized_copper": {
        "langKey": "tile.waxed_oxidized_copper.name"
    },
    "minecraft:waxed_oxidized_copper_bulb": {
        "langKey": "tile.waxed_oxidized_copper_bulb.name"
    },
    "minecraft:waxed_oxidized_copper_door": {
        "langKey": "item.waxed_oxidized_copper_door.name"
    },
    "minecraft:waxed_oxidized_copper_grate": {
        "langKey": "tile.waxed_oxidized_copper_grate.name"
    },
    "minecraft:waxed_oxidized_copper_trapdoor": {
        "langKey": "tile.waxed_oxidized_copper_trapdoor.name"
    },
    "minecraft:waxed_oxidized_cut_copper": {
        "langKey": "tile.waxed_oxidized_cut_copper.name"
    },
    "minecraft:waxed_oxidized_cut_copper_slab": {
        "langKey": "tile.waxed_oxidized_cut_copper_slab.name"
    },
    "minecraft:waxed_oxidized_cut_copper_stairs": {
        "langKey": "tile.waxed_oxidized_cut_copper_stairs.name"
    },
    "minecraft:waxed_weathered_chiseled_copper": {
        "langKey": "tile.waxed_weathered_chiseled_copper.name"
    },
    "minecraft:waxed_weathered_copper": {
        "langKey": "tile.waxed_weathered_copper.name"
    },
    "minecraft:waxed_weathered_copper_bulb": {
        "langKey": "tile.waxed_weathered_copper_bulb.name"
    },
    "minecraft:waxed_weathered_copper_door": {
        "langKey": "item.waxed_weathered_copper_door.name"
    },
    "minecraft:waxed_weathered_copper_grate": {
        "langKey": "tile.waxed_weathered_copper_grate.name"
    },
    "minecraft:waxed_weathered_copper_trapdoor": {
        "langKey": "tile.waxed_weathered_copper_trapdoor.name"
    },
    "minecraft:waxed_weathered_cut_copper": {
        "langKey": "tile.waxed_weathered_cut_copper.name"
    },
    "minecraft:waxed_weathered_cut_copper_slab": {
        "langKey": "tile.waxed_weathered_cut_copper_slab.name"
    },
    "minecraft:waxed_weathered_cut_copper_stairs": {
        "langKey": "tile.waxed_weathered_cut_copper_stairs.name"
    },
    "minecraft:wayfinder_armor_trim_smithing_template": {
        "langKey": "trim_pattern.wayfinder.name"
    },
    "minecraft:weathered_chiseled_copper": {
        "langKey": "tile.weathered_chiseled_copper.name"
    },
    "minecraft:weathered_copper": {
        "langKey": "tile.weathered_copper.name"
    },
    "minecraft:weathered_copper_bulb": {
        "langKey": "tile.weathered_copper_bulb.name"
    },
    "minecraft:weathered_copper_door": {
        "langKey": "item.weathered_copper_door.name"
    },
    "minecraft:weathered_copper_grate": {
        "langKey": "tile.weathered_copper_grate.name"
    },
    "minecraft:weathered_copper_trapdoor": {
        "langKey": "tile.weathered_copper_trapdoor.name"
    },
    "minecraft:weathered_cut_copper": {
        "langKey": "tile.weathered_cut_copper.name"
    },
    "minecraft:weathered_cut_copper_slab": {
        "langKey": "tile.weathered_cut_copper_slab.name"
    },
    "minecraft:weathered_cut_copper_stairs": {
        "langKey": "tile.weathered_cut_copper_stairs.name"
    },
    "minecraft:web": {
        "langKey": "tile.web.name"
    },
    "minecraft:weeping_vines": {
        "langKey": "tile.weeping_vines.name"
    },
    "minecraft:wet_sponge": {
        "langKey": "tile.sponge.wet.name"
    },
    "minecraft:wheat": {
        "langKey": "item.wheat.name"
    },
    "minecraft:wheat_seeds": {
        "langKey": "item.wheat_seeds.name"
    },
    "minecraft:white_bundle": {
        "langKey": "item.white_bundle"
    },
    "minecraft:white_candle": {
        "langKey": "tile.white_candle.name"
    },
    "minecraft:white_carpet": {
        "langKey": "tile.carpet.white.name"
    },
    "minecraft:white_concrete": {
        "langKey": "tile.concrete.white.name"
    },
    "minecraft:white_concrete_powder": {
        "langKey": "tile.concretePowder.white.name"
    },
    "minecraft:white_dye": {
        "langKey": "item.dye.white_new.name"
    },
    "minecraft:white_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.white.name"
    },
    "minecraft:white_shulker_box": {
        "langKey": "tile.shulkerBoxWhite.name"
    },
    "minecraft:white_stained_glass": {
        "langKey": "tile.stained_glass.white.name"
    },
    "minecraft:white_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.white.name"
    },
    "minecraft:white_terracotta": {
        "langKey": "tile.stained_hardened_clay.white.name"
    },
    "minecraft:white_tulip": {
        "langKey": "tile.red_flower.tulipWhite.name"
    },
    "minecraft:white_wool": {
        "langKey": "tile.wool.white.name"
    },
    "minecraft:wild_armor_trim_smithing_template": {
        "langKey": "trim_pattern.wild.name"
    },
    "minecraft:wildflowers": {
        "langKey": "tile.wildflowers.name"
    },
    "minecraft:wind_charge": {
        "langKey": "item.wind_charge.name"
    },
    "minecraft:witch_spawn_egg": {
        "langKey": "item.spawn_egg.entity.witch.name"
    },
    "minecraft:wither_rose": {
        "langKey": "tile.wither_rose.name"
    },
    "minecraft:wither_skeleton_skull": {
        "langKey": "item.skull.wither.name"
    },
    "minecraft:wither_skeleton_spawn_egg": {
        "langKey": "item.spawn_egg.entity.wither_skeleton.name"
    },
    "minecraft:wither_spawn_egg": {
        "langKey": "item.spawn_egg.entity.wither.name"
    },
    "minecraft:wolf_armor": {
        "langKey": "item.wolf_armor.name"
    },
    "minecraft:wolf_spawn_egg": {
        "langKey": "item.spawn_egg.entity.wolf.name"
    },
    "minecraft:wood": {
        "langKey": "tile.wood.dark_oak.name"
    },
    "minecraft:wooden_axe": {
        "langKey": "item.wooden_axe.name"
    },
    "minecraft:wooden_button": {
        "langKey": "tile.wooden_button.name"
    },
    "minecraft:wooden_door": {
        "langKey": "item.wooden_door.name"
    },
    "minecraft:wooden_hoe": {
        "langKey": "item.wooden_hoe.name"
    },
    "minecraft:wooden_pickaxe": {
        "langKey": "item.wooden_pickaxe.name"
    },
    "minecraft:wooden_pressure_plate": {
        "langKey": "tile.wooden_pressure_plate.name"
    },
    "minecraft:wooden_shovel": {
        "langKey": "item.wooden_shovel.name"
    },
    "minecraft:wooden_slab": {
        "langKey": "tile.wooden_slab.name"
    },
    "minecraft:wooden_sword": {
        "langKey": "item.wooden_sword.name"
    },
    "minecraft:writable_book": {
        "langKey": "item.writable_book.name"
    },
    "minecraft:yellow_bundle": {
        "langKey": "item.yellow_bundle"
    },
    "minecraft:yellow_candle": {
        "langKey": "tile.yellow_candle.name"
    },
    "minecraft:yellow_carpet": {
        "langKey": "tile.carpet.yellow.name"
    },
    "minecraft:yellow_concrete": {
        "langKey": "tile.concrete.yellow.name"
    },
    "minecraft:yellow_concrete_powder": {
        "langKey": "tile.concretePowder.yellow.name"
    },
    "minecraft:yellow_dye": {
        "langKey": "item.dye.yellow.name"
    },
    "minecraft:yellow_flower": {
        "langKey": "tile.yellow_flower.dandelion.name"
    },
    "minecraft:yellow_glazed_terracotta": {
        "langKey": "tile.glazedTerracotta.yellow.name"
    },
    "minecraft:yellow_shulker_box": {
        "langKey": "tile.shulkerBoxYellow.name"
    },
    "minecraft:yellow_stained_glass": {
        "langKey": "tile.stained_glass.yellow.name"
    },
    "minecraft:yellow_stained_glass_pane": {
        "langKey": "tile.stained_glass_pane.yellow.name"
    },
    "minecraft:yellow_terracotta": {
        "langKey": "tile.stained_hardened_clay.yellow.name"
    },
    "minecraft:yellow_wool": {
        "langKey": "tile.wool.yellow.name"
    },
    "minecraft:zoglin_spawn_egg": {
        "langKey": "item.spawn_egg.entity.zoglin.name"
    },
    "minecraft:zombie_head": {
        "langKey": "item.skull.zombie.name"
    },
    "minecraft:zombie_horse_spawn_egg": {
        "langKey": "item.spawn_egg.entity.zombie_horse.name"
    },
    "minecraft:zombie_pigman_spawn_egg": {
        "langKey": "item.spawn_egg.entity.zombie_pigman.name"
    },
    "minecraft:zombie_spawn_egg": {
        "langKey": "item.spawn_egg.entity.zombie.name"
    },
    "minecraft:zombie_villager_spawn_egg": {
        "langKey": "item.spawn_egg.entity.zombie_villager.name"
    },
    "sand.red": {
        "langKey": "tile.sand.red.name"
    },
    "shulkerBoxWhite": {
        "langKey": "tile.shulkerBoxWhite.name"
    },
    "stained_glass.white": {
        "langKey": "tile.stained_glass.white.name"
    },
    "stained_glass_pane.white": {
        "langKey": "tile.stained_glass_pane.white.name"
    }
};
