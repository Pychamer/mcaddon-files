var _a;
import { addName } from "./namespace";
/**
 * Class representing a text format (§) with color and style for text.
 */
export class TextFormat {
    constructor(code) {
        this.code = code;
    }
    static create(code) {
        const f = function (string) {
            return f.code + string + "§r";
        };
        const textFormatAlt = new TextFormat(code);
        Object.assign(f, textFormatAlt);
        Object.setPrototypeOf(f, TextFormat.prototype);
        return f;
    }
    toString() {
        return this.code;
    }
}
_a = TextFormat;
// Color Definitions
TextFormat.black = _a.create("§0");
TextFormat.dark_blue = _a.create("§1");
TextFormat.dark_green = _a.create("§2");
TextFormat.dark_aqua = _a.create("§3");
TextFormat.dark_red = _a.create("§4");
TextFormat.dark_purple = _a.create("§5");
TextFormat.gold = _a.create("§6");
TextFormat.gray = _a.create("§7");
TextFormat.dark_gray = _a.create("§8");
TextFormat.blue = _a.create("§9");
TextFormat.green = _a.create("§a");
TextFormat.aqua = _a.create("§b");
TextFormat.red = _a.create("§c");
TextFormat.light_purple = _a.create("§d");
TextFormat.yellow = _a.create("§e");
TextFormat.white = _a.create("§f");
TextFormat.minecoin_gold = _a.create("§g");
TextFormat.material_quartz = _a.create("§h");
TextFormat.material_iron = _a.create("§i");
TextFormat.material_netherite = _a.create("§j");
TextFormat.material_redstone = _a.create("§m");
TextFormat.material_copper = _a.create("§n");
TextFormat.material_gold = _a.create("§p");
TextFormat.material_emerald = _a.create("§q");
TextFormat.material_diamond = _a.create("§s");
TextFormat.material_lapis = _a.create("§t");
TextFormat.material_amethyst = _a.create("§u");
// Style Definitions
TextFormat.obfuscated = _a.create("§k");
TextFormat.bold = _a.create("§l");
TextFormat.italic = _a.create("§o");
TextFormat.reset = _a.create("§r");
/**
 * @remarks Handles the translation of a lang key with arguments.
 * @param key The lang key to translate. Automatically prefixed with the global namespace if no namespace is provided.
 * @param withArgs Arguments passed to `with` in the translation. Defaults to a newline.
 * @returns The formatted translation rawmessage.
 */
export function translate(key, withArgs = ["\n"]) {
    const args = withArgs.map(arg => typeof arg === "string" ? { text: arg } : arg);
    key = key.includes(":") ? key : addName(key);
    return { translate: key, with: { rawtext: args } };
}
