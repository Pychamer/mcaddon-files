import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onFrogUse(player) {
    utils.mclog(`${player.nameTag} Used Frog Weapon`);
    mc.world.playSound("ldz_240409:weapon.frog.use", player.location);
    utils.getEntitiesFromRaySafe(player.dimension, player.getHeadLocation().down(0.05), player.getViewDirection(), { maxDistance: 10 }).forEach(hit => {
        if (hit.entity.typeId === "minecraft:item") {
            hit.entity.applyImpulse(player.getHeadLocation().subtract(hit.entity.location).normalize().multiply(hit.distance * 0.2));
        }
    });
}
export const FROG_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_frog", range: 10, damage: 4.1, minAngle: 4, maxAngle: 4, hitCallbacks: [onHitWithFrog] });
function onHitWithFrog(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
