import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onCreakingUse(player) {
    utils.mclog(`${player.nameTag} Used Creaking Weapon`);
    mc.world.playSound("ldz_240409:player.weapon_creaking.swing", player.location);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    new utils.Projectile(player.getHeadLocation().add(player.getViewDirection().multiply(1.5)), player.dimension, "ldz_240409:weapon_creaking_projectile", player.getViewDirection().multiply(1.5), player, {
        power: 1.5,
        gravity: 0,
        hit_sound: "",
        on_hit: {
            damage: 3,
            destroy_on_hit: true,
            hit_callback(projectile, hitEntities, hitBlock) {
                // utils.mclog(`${projectile.Owner?.nameTag} Hit ${hitEntities.length} entities with Creaking Weapon`);
                hitEntities.forEach(entity => {
                    if (entity.isOnGround) {
                        let existingBramble = utils.getEntitiesSafe(entity.dimension, { type: "ldz_240409:weapon_creaking_bramble", location: entity.location, maxDistance: 1 });
                        if (existingBramble.length > 0)
                            return;
                        let bramble = entity.dimension.spawnEntity("ldz_240409:weapon_creaking_bramble", entity.location);
                        entity.playSoundAt("ldz_240409:entity.weapon_creaking_bramble.spawn");
                        entity.addEffect("slowness", 100, { amplifier: 100, showParticles: false });
                        entity.clearVelocity();
                        const location = bramble.location;
                        utils.waitForLoopEvent(20, () => {
                            if (!bramble.isValid() || !entity.isValid())
                                return true;
                            entity.applyDamage(1, { damagingEntity: player, cause: mc.EntityDamageCause.entityAttack });
                            entity.playSoundAt("ldz_240409:entity.weapon_creaking_bramble.choke");
                            return !bramble.isValid() && !entity.isValid();
                        });
                        utils.waitForLoopEvent(5, () => {
                            if (!bramble.isValid()) {
                                player.playSound("ldz_240409:entity.weapon_creaking_bramble.break", { location: location });
                                return true;
                            }
                            ;
                            if (!entity.isValid())
                                return;
                            entity.teleport(bramble.location);
                            entity.clearVelocity();
                            return !bramble.isValid() && !entity.isValid();
                        });
                    }
                    else {
                        entity.applyDamage(3, { damagingEntity: player, cause: mc.EntityDamageCause.entityAttack });
                    }
                });
            },
        }
    });
    player.playSound("ldz_240409:weapon.creaking.shoot");
}
// export const CREAKING_ATTACK = new utils.MeleeAttack({attackID: "ldz_240409:weapon_creaking", damage: 4.1, delay: 0.1, hitCallbacks: [onHitWithCreaking], maxAngle: 5, minAngle: -5})
// function onHitWithCreaking(player: utils.SafetyCheckedPlayer, entity: utils.SafetyCheckedEntity) {
// 	if (entity.isValid()) {
// 		mc.world.playSound("ldz_240409:player.weapon_creaking.hit", player.location);
// 		utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
// 		//entity.dimension.spawnParticle("ldz_240409:weapon_chicken_impact", entity.location.up());
// 	}
// }
