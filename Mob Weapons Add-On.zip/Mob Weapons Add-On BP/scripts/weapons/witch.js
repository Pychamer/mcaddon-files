import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onWitchUse(player) {
    var _a;
    const healing = (_a = player.getDynamicProperty("witch_weapon_healing_mode")) !== null && _a !== void 0 ? _a : false;
    if (player.isSneaking) {
        player.setDynamicProperty("witch_weapon_healing_mode", !healing);
        player.playSound("ldz_240409:weapon.witch.switch");
        return;
    }
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    if (healing) {
        const potionParticleVariables = new mc.MolangVariableMap();
        potionParticleVariables.setColorRGB("color", { red: 0.67, green: 0.09, blue: 0.09 });
        new utils.Projectile(player.getHeadLocation().add(player.getViewDirection().multiply(1)), player.dimension, "ldz_240409:weapon_witch_projectile_2", player.getViewDirection(), player, {
            power: 1,
            gravity: 0.1,
            shoot_sound: "ldz_240409:weapon.witch.shoot",
            hit_sound: "random.glass",
            faceDirection: false,
            on_hit: {
                destroy_on_hit: true,
                damage: 0,
                hit_callback(projectile, hitEntities, hitBlock) {
                    if (hitBlock || hitEntities.length > 0) {
                        projectile.Entity.dimension.spawnParticle("ldz_240409:weapon_witch_potion_aoe", projectile.Entity.location, potionParticleVariables);
                    }
                    if (hitBlock) {
                        hitBlock.block.dimension.getEntities({ location: hitBlock.block.location, maxDistance: 2 }).forEach((entity) => {
                            entity.addEffect("instant_health", 1);
                        });
                        return;
                    }
                    hitEntities.forEach((entity) => {
                        entity.dimension.getEntities({ location: entity.location, maxDistance: 2 }).forEach((entity) => {
                            entity.addEffect("instant_health", 1);
                        });
                    });
                    projectile.Entity.remove();
                },
            }
        });
    }
    else {
        const potionParticleVariables = new mc.MolangVariableMap();
        potionParticleVariables.setColorRGB("color", { red: 0.53, green: 0.31, blue: 0.33 });
        new utils.Projectile(player.getHeadLocation().add(player.getViewDirection().multiply(1)), player.dimension, "ldz_240409:weapon_witch_projectile_1", player.getViewDirection(), player, {
            power: 1,
            gravity: 0.1,
            shoot_sound: "ldz_240409:weapon.witch.shoot",
            hit_sound: "random.glass",
            faceDirection: false,
            on_hit: {
                destroy_on_hit: true,
                hit_callback(projectile, hitEntities, hitBlock) {
                    if (hitBlock || hitEntities.length > 0) {
                        projectile.Entity.dimension.spawnParticle("ldz_240409:weapon_witch_potion_aoe", projectile.Entity.location, potionParticleVariables);
                    }
                    if (hitBlock) {
                        hitBlock.block.dimension.getEntities({ location: hitBlock.block.location, maxDistance: 2 }).forEach((entity) => {
                            entity.addEffect("instant_damage", 1);
                        });
                        return;
                    }
                    hitEntities.forEach((entity) => {
                        entity.dimension.getEntities({ location: entity.location, maxDistance: 2 }).forEach((entity) => {
                            entity.addEffect("instant_damage", 1);
                        });
                    });
                },
            }
        });
    }
}
