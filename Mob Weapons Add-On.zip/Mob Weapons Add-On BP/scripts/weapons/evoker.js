import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const LAUNCH_DISTANCE = 10;
export function onEvokerUse(player) {
    utils.mclog(`${player.nameTag} Used Evoker Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    mc.world.playSound('ldz_240409:weapon.evoker.use', player.location);
    player.addEffect("resistance", 5, { amplifier: 10, showParticles: false });
    launchFangs(player.getViewDirection(), player);
}
async function launchFangs(direction, player) {
    for (let index = 2; index <= LAUNCH_DISTANCE; index++) {
        const origin = player.location.add({ x: direction.x * index, y: 3, z: direction.z * index });
        const block = player.dimension.getBlockFromRay(origin, utils.Vector3.DOWN, { includeLiquidBlocks: true, includePassableBlocks: false, maxDistance: 10 });
        let target = origin;
        if (block) {
            target = new utils.Vector3(block.block.location).add(block.faceLocation);
        }
        else {
            target.y = player.location.y;
        }
        utils.runCommand(`summon evocation_fang ${target}`, player);
        await utils.waitForTicks(1);
        utils.runCommand(`execute positioned ${target} run tag @e[type=evocation_fang,r=1,c=1] add ldz_240409:player_spawned`, player);
    }
}
mc.world.afterEvents.entityHurt.subscribe(event => {
    const victim = event.hurtEntity;
    const attacker = event.damageSource.damagingEntity;
    if (attacker && attacker.isValid() && victim && victim.isValid()) {
        if (attacker.typeId === "minecraft:evocation_fang" && attacker.hasTag("ldz_240409:player_spawned")) {
            victim.applyDamage(9, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: attacker });
        }
    }
});
