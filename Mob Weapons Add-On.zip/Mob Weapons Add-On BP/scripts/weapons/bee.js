import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onBeeUse(player) {
    utils.mclog(`${player.nameTag} Used Bee Weapon`);
    player.playSound("ldz_240409:weapon.bee.use");
}
export const BEE_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_bee", delay: 0.1, damage: 6, hitCallbacks: [onHitWithBee] });
function onHitWithBee(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
        player.playSound("ldz_240409:weapon.bee.impact");
        entity.addEffect("fatal_poison", 80, { amplifier: 2 });
    }
}
