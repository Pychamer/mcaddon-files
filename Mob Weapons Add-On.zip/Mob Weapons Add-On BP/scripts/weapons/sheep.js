import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const WOOL_IDS = {
    0: "minecraft:black_wool",
    1: "minecraft:blue_wool",
    2: "minecraft:brown_wool",
    3: "minecraft:cyan_wool",
    4: "minecraft:gray_wool",
    5: "minecraft:green_wool",
    6: "minecraft:light_blue_wool",
    7: "minecraft:lime_wool",
    8: "minecraft:magenta_wool",
    9: "minecraft:orange_wool",
    10: "minecraft:pink_wool",
    11: "minecraft:purple_wool",
    12: "minecraft:red_wool",
    13: "minecraft:light_gray_wool",
    14: "minecraft:white_wool",
    15: "minecraft:yellow_wool",
};
const REPLACE_WHITELIST = [
    "minecraft:air",
    "minecraft:water",
    "minecraft:vine",
    "minecraft:seagrass",
    "minecraft:tallgrass",
    "minecraft:double_plant",
];
export function onSheepUse(player) {
    utils.mclog(`${player.nameTag} Used Sheep Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    new utils.Projectile(player.getHeadLocation().add(player.getViewDirection()), player.dimension, "ldz_240409:weapon_sheep_projectile", player.getViewDirection(), player, {
        power: 2.5,
        gravity: 0,
        shoot_sound: "ldz_240409:weapon.sheep.shoot",
        hit_sound: "",
        stick_in_ground: true,
        on_hit: {
            destroy_on_hit: true,
            damage: 6,
            knockback: true,
            hit_callback: spawnWool,
        }
    });
}
async function spawnWool(proj, hitEntities, hitBlock) {
    const projectile = proj.Entity;
    const woolColor = projectile.getProperty("ldz_240409:color");
    if (!projectile.isValid())
        return;
    if (hitBlock && hitEntities.length === 0) {
        projectile.runCommand("execute positioned ^ ^ ^-0.25 align xyz run tp ~0.5 ~ ~0.5");
        if (projectile.getRotation().x < 70)
            await utils.waitForTicks(2);
        if (!projectile.isValid())
            return;
        const block = projectile.dimension.getBlock(projectile.location);
        if (block && REPLACE_WHITELIST.some((whitelistItem) => block.permutation.matches(whitelistItem))) {
            projectile.runCommand(`setblock ~ ~ ~ ${WOOL_IDS[woolColor]}`);
        }
        const variables = new mc.MolangVariableMap();
        variables.setFloat("color", woolColor);
        try {
            projectile.dimension.spawnParticle("ldz_240409:weapon_sheep_projectile_setblock", projectile.location, variables);
        }
        catch (_a) {
            utils.mcerror("Failed to play particle");
        }
        projectile.runCommand("playsound ldz_240409:entity.weapon_sheep_projectile.impact @a ~ ~ ~ 4");
        const nearbyPlayer = utils.getEntitiesSafe(projectile.dimension, { type: "player", location: projectile.location, maxDistance: 1, closest: 1 })[0];
        if (nearbyPlayer) {
            nearbyPlayer.teleport(nearbyPlayer.location.up());
        }
        projectile.remove();
        return;
    }
    if (hitEntities.length > 0) {
        await utils.waitForTicks(3);
        if (!projectile.isValid())
            return;
        const variables = new mc.MolangVariableMap();
        variables.setFloat("color", woolColor);
        try {
            projectile.dimension.spawnParticle("ldz_240409:weapon_sheep_projectile_hit", projectile.location, variables);
        }
        catch (_b) {
            utils.mcerror("Failed to play particle");
        }
        projectile.runCommand("playsound ldz_240409:entity.weapon_sheep_projectile.impact @a ~ ~ ~ 1");
        // projectile.remove();
        projectile.setProperty("hide", true);
        return;
    }
}
