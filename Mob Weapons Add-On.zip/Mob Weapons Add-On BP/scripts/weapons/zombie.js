import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
function initializeZombie() {
    mc.system.afterEvents.scriptEventReceive.subscribe(event => {
        if (event.id === "ldz_240409:zombie_bomb_behavior") {
            if (event.sourceEntity && event.sourceEntity.isValid()) {
                zombieBehavior(new utils.SafetyCheckedEntity(event.sourceEntity));
            }
        }
    });
}
initializeZombie();
export function onZombieUse(player) {
    utils.mclog(`${player.nameTag} Used Zombie Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    const playerLoc = new utils.Vector3(player.location);
    const playerRot = player.getRotation();
    // const zombieBomb = new utils.SafetyCheckedEntity(player.dimension.spawnEntity("ldz_240409:zombie_bomb", player.location));
    player.runCommand(`summon ldz_240409:zombie_bomb ${playerLoc} ${playerRot.y} ${playerRot.x}`);
    player.runCommand(`execute rotated ~ 0 run playsound ldz_240409:entity.zombie_bomb.fuse @a ^ ^ ^0`);
    player.runCommand(`execute rotated ~ 0 run playsound ldz_240409:entity.zombie_bomb.fuse @a ^ ^ ^5`);
    const zombieBomb = utils.getEntitiesSafe(player.dimension, { location: player.location, maxDistance: 1, type: "ldz_240409:zombie_bomb" })[0];
    if (!zombieBomb.isValid())
        return;
    zombieBomb.setDynamicProperty("ldz_240409:owner", player.id);
    zombieBehavior(zombieBomb);
}
function zombieBehavior(entity) {
    // Constants
    const checkDistance = 1;
    const speed = 0.25;
    const jumpHeight = 0.6;
    const extraGravity = 0.2;
    utils.waitForLoopEvent(0, () => {
        if (!entity.isValid())
            return true;
        // Check blocks in front
        const radians = (entity.getRotation().y + 90) * Math.PI / 180;
        const dir = new utils.Vector3({ x: Math.cos(radians), y: 0, z: Math.sin(radians) });
        const bottomBlock = entity.dimension.getBlockFromRay(entity.location, dir, { maxDistance: checkDistance, includeLiquidBlocks: false, includePassableBlocks: false });
        const topBlock = entity.dimension.getBlockFromRay(entity.location.up(), dir, { maxDistance: checkDistance, includeLiquidBlocks: false, includePassableBlocks: false });
        // Check if jump should be reset
        if (entity.isOnGround)
            entity.setDynamicProperty(utils.GlobalNamespace.Namespace + "jumped", false);
        const jumped = entity.getDynamicProperty(utils.GlobalNamespace.Namespace + "jumped");
        // Move zombie forward
        if ((!jumped && entity.isOnGround) || (jumped && entity.getVelocity().y <= 0)) {
            entity.applyKnockback(dir.x, dir.z, speed, -extraGravity);
        }
        // Make zombie jump
        if (!jumped && bottomBlock && !topBlock && entity.isOnGround) {
            entity.applyKnockback(dir.x, dir.z, speed, jumpHeight);
            entity.setDynamicProperty(utils.GlobalNamespace.Namespace + "jumped", true);
        }
        const nearbyMonsters = utils.getEntitiesSafe(entity.dimension, { location: entity.location, maxDistance: 1, families: ["monster"] });
        let nearbyPlayers = utils.getEntitiesSafe(entity.dimension, { location: entity.location, maxDistance: 1, type: "player" });
        const ownerId = entity.getDynamicProperty("ldz_240409:owner");
        nearbyPlayers = nearbyPlayers.filter(player => player.id !== ownerId);
        if (nearbyMonsters.length || nearbyPlayers.length) {
            entity.triggerEvent("minecraft:explode");
        }
        return false;
    });
}
