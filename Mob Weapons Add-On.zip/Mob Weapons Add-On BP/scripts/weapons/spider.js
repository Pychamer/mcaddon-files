import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onSpiderUse(player) {
    utils.mclog(`${player.nameTag} Used Spider Weapon`);
    mc.world.playSound("ldz_240409:weapon.spider.use", player.location);
    mc.world.playSound("ldz_240409:weapon.spider.whip_crack", player.location);
}
export const SPIDER_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_spider", damage: 6, delay: 0.3, range: 6, minAngle: -25, maxAngle: 25, hitCallbacks: [onHitWithSpider] });
function onHitWithSpider(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
