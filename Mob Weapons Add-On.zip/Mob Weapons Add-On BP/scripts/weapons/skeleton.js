import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onSkeletonUse(player) {
    utils.mclog(`${player.nameTag} Used Skeleton Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_skeleton_projectile", player.getViewDirection(), player, {
        power: 2,
        stick_in_ground: true,
        hit_sound: "ldz_240409:entity.weapon_skeleton_projectile.impact",
        shoot_sound: "ldz_240409:weapon.skeleton.shoot",
        lifetime_seconds: 50,
        on_hit: {
            hit_callback(projectile, entities) {
                utils.waitForEvent(10, () => {
                    projectile.Entity.triggerEvent("on_ground");
                });
                utils.waitForEvent(90, () => {
                    if (projectile.Entity.isValid())
                        projectile.Entity.triggerEvent("set_is_active_to_true");
                });
                const onRemove = () => {
                    mc.world.afterEvents.entityRemove.unsubscribe(onRemove);
                    mc.world.afterEvents.dataDrivenEntityTrigger.unsubscribe(onActivate);
                };
                const onActivate = (event) => {
                    mc.world.afterEvents.entityRemove.unsubscribe(onRemove);
                    mc.world.afterEvents.dataDrivenEntityTrigger.unsubscribe(onActivate);
                    mc.world.playSound("ldz_240409:entity.weapon_skeleton_projectile.activate", event.entity.location);
                    utils.getEntitiesSafe(event.entity.dimension, {
                        location: event.entity.location,
                        maxDistance: 5,
                        excludeTypes: ["minecraft:item"],
                        excludeFamilies: ["ldz_240409"],
                        excludeNames: [player.name]
                    }).forEach(victim => {
                        utils.mclog(victim.typeId);
                        try {
                            victim.applyDamage(15, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: player.UnsafeEntity });
                        }
                        catch (error) {
                            utils.mcwarn(`Cannot Apply Damage To ${victim.typeId}`);
                        }
                    });
                    utils.waitForEvent(60, () => {
                        if (event.entity.isValid()) {
                            event.entity.triggerEvent("set_is_active_to_false");
                        }
                    });
                    utils.waitForEvent(70, () => {
                        if (event.entity.isValid()) {
                            event.entity.dimension.spawnParticle("ldz_240409:weapon_skeleton_projectile_break", event.entity.location);
                            mc.world.playSound("ldz_240409:entity.weapon_skeleton_projectile.break", event.entity.location);
                            event.entity.remove();
                        }
                    });
                };
                mc.world.afterEvents.entityRemove.subscribe(onRemove, { entities: [projectile.Entity.UnsafeEntity] });
                mc.world.afterEvents.dataDrivenEntityTrigger.subscribe(onActivate, { entities: [projectile.Entity.UnsafeEntity], eventTypes: ["set_is_active_to_true"] });
            },
        }
    });
}
