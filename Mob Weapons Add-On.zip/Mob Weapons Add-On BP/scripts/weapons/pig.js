import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onPigUse(player) {
    utils.mclog(`${player.nameTag} Used Pig Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    player.playSound('ldz_240409:weapon.pig.sizzle');
    new utils.Projectile(player.getHeadLocation().add(player.getViewDirection()), player.dimension, "ldz_240409:weapon_pig_projectile", player.getViewDirection(), player, {
        faceDirection: false,
        power: 1.2,
        stick_in_ground: true,
        shoot_sound: "ldz_240409:weapon.pig.shoot",
        hit_sound: "ldz_240409:entity.weapon_pig_projectile.impact",
        on_hit: {
            damage: 7,
            knockback: true,
            destroy_on_hit: true,
            hit_callback(projectile) {
                projectile.Entity.dimension.spawnParticle("ldz_240409:weapon_pig_projectile_break", projectile.Entity.location);
                projectile.Entity.remove();
            },
        },
    });
}
