import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const SHOOT_BURST_DURATION = 3 * mc.TicksPerSecond;
export function onSnowGolemUse(player) {
    utils.mclog(`${player.nameTag} used Snow Golem Weapon`);
    startShooting(player);
}
function startShooting(player) {
    let isActive = true;
    utils.waitForLoopEvent(2, () => {
        if (!isActive || !player.isValid() || !isPlayerHoldingSnowGolemWeapon(player)) {
            stopShooting();
            return true;
        }
        player.playAnimation(`animation.ldz_240409.player.weapon_snow_golem.attack.third_person.held`, {
            stopExpression: "!q.is_using_item",
            nextState: "default",
            blendOutTime: 0.2,
            controller: `weapon_snow_golem.third_person`,
        });
        new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_snow_golem_projectile", player.getViewDirection(), player, {
            lifetime_seconds: 3,
            stick_in_ground: false,
            power: 2,
            gravity: 0.0075,
            offset: { x: 0, y: -0.2, z: 0 },
            faceDirection: true,
            shoot_sound: "ldz_240409:weapon.snow_golem.shoot",
            hit_sound: "ldz_240409:weapon.snow_golem.hit",
            on_hit: {
                destroy_on_hit: true,
                damage: 1,
                knockback: true,
                hit_callback(projectile, hitEntities, hitBlock) {
                    projectile.Entity.dimension.spawnParticle('ldz_240409:weapon_snow_golem_projectile_impact', projectile.Entity.location);
                    projectile.Entity.runCommand('fill ~~-1~ ~~1~ air replace fire');
                    projectile.Entity.playSoundAt("ldz_240409:weapon.snow_golem.extinguish");
                    if (hitEntities) {
                        hitEntities.forEach(entity => {
                            if (entity.isValid() && entity.typeId !== "ldz_240409:weapon_snow_golem_projectile" && entity.typeId !== "minecraft:item" && !entity.matches({ gameMode: mc.GameMode.creative })) {
                                entity.extinguishFire();
                            }
                        });
                    }
                }
            }
        });
    });
    const endActiveEvent = (event) => {
        if (event.source.id === player.id) {
            stopShooting();
        }
    };
    mc.world.afterEvents.itemStopUse.subscribe(endActiveEvent);
    utils.waitForEvent(SHOOT_BURST_DURATION, stopShooting); // Automatically stop after duration
    function stopShooting() {
        isActive = false;
        mc.world.afterEvents.itemStopUse.unsubscribe(endActiveEvent);
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
export const SNOW_GOLEM_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_snow_golem", damage: 5 });
function isPlayerHoldingSnowGolemWeapon(player) {
    var _a;
    return ((_a = player.MainHand) === null || _a === void 0 ? void 0 : _a.typeId) === "ldz_240409:weapon_snow_golem";
}
