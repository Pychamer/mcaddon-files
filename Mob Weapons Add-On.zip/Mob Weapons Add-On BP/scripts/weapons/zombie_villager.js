import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const MAX_MOB_HIT_RANGE = 3;
const MAX_BLOCK_BREAK_RANGE = 7;
const BLOCK_PARTICLE_MAP = {
    "minecraft:nether_wart_block": "ldz_240409:weapon_zombie_villager_nether_wart_block",
    "minecraft:warped_wart_block": "ldz_240409:weapon_zombie_villager_warped_wart_block",
    "minecraft:shroomlight": "ldz_240409:weapon_zombie_villager_shroomlight",
    "minecraft:leaf_litter": "ldz_240409:weapon_zombie_villager_leaf_litter",
    "minecraft:tall_grass": "ldz_240409:weapon_zombie_villager_grass",
    "minecraft:short_grass": "ldz_240409:weapon_zombie_villager_grass",
    "minecraft:large_fern": "ldz_240409:weapon_zombie_villager_fern",
    "minecraft:fern": "ldz_240409:weapon_zombie_villager_fern",
    "minecraft:bush": "ldz_240409:weapon_zombie_villager_fern",
    "minecraft:vine": "ldz_240409:weapon_zombie_villager_vines",
    "minecraft:weeping_vines": "ldz_240409:weapon_zombie_villager_weeping_vines",
    "minecraft:twisting_vines": "ldz_240409:weapon_zombie_villager_twisting_vines",
    "minecraft:pale_hanging_moss": "ldz_240409:weapon_zombie_villager_leaves_pale_oak",
    "minecraft:acacia_leaves": "ldz_240409:weapon_zombie_villager_leaves_acacia",
    "minecraft:azalea_leaves": "ldz_240409:weapon_zombie_villager_leaves_azalea",
    "minecraft:azalea_leaves_flowered": "ldz_240409:weapon_zombie_villager_leaves_azalea_flowered",
    "minecraft:birch_leaves": "ldz_240409:weapon_zombie_villager_leaves_birch",
    "minecraft:cherry_leaves": "ldz_240409:weapon_zombie_villager_leaves_cherry",
    "minecraft:dark_oak_leaves": "ldz_240409:weapon_zombie_villager_leaves_dark_oak",
    "minecraft:jungle_leaves": "ldz_240409:weapon_zombie_villager_leaves_jungle",
    "minecraft:mangrove_leaves": "ldz_240409:weapon_zombie_villager_leaves_mangrove",
    "minecraft:oak_leaves": "ldz_240409:weapon_zombie_villager_leaves_oak",
    "minecraft:pale_oak_leaves": "ldz_240409:weapon_zombie_villager_leaves_pale_oak",
    "minecraft:spruce_leaves": "ldz_240409:weapon_zombie_villager_leaves_spruce",
    "minecraft:mushroom_stem": "ldz_240409:weapon_zombie_villager_mushroom_stem_block",
    "minecraft:red_mushroom_block": "ldz_240409:weapon_zombie_villager_red_mushroom_block",
    "minecraft:brown_mushroom_block": "ldz_240409:weapon_zombie_villager_brown_mushroom_block",
    "minecraft:oak_log": "ldz_240409:weapon_zombie_villager_log_oak",
    "minecraft:spruce_log": "ldz_240409:weapon_zombie_villager_log_spruce",
    "minecraft:birch_log": "ldz_240409:weapon_zombie_villager_log_birch",
    "minecraft:jungle_log": "ldz_240409:weapon_zombie_villager_log_jungle",
    "minecraft:acacia_log": "ldz_240409:weapon_zombie_villager_log_acacia",
    "minecraft:dark_oak_log": "ldz_240409:weapon_zombie_villager_log_dark_oak",
    "minecraft:mangrove_log": "ldz_240409:weapon_zombie_villager_log_mangrove",
    "minecraft:cherry_log": "ldz_240409:weapon_zombie_villager_log_cherry",
    "minecraft:pale_oak_log": "ldz_240409:weapon_zombie_villager_log_pale_oak",
    "minecraft:crimson_stem": "ldz_240409:weapon_zombie_villager_log_crimson",
    "minecraft:warped_stem": "ldz_240409:weapon_zombie_villager_log_warped",
    "minecraft:stripped_oak_log": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:stripped_spruce_log": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:stripped_birch_log": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:stripped_jungle_log": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:stripped_acacia_log": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:stripped_dark_oak_log": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:stripped_mangrove_log": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:stripped_cherry_log": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:stripped_pale_oak_log": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:stripped_crimson_stem": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:stripped_warped_stem": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:oak_planks": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_planks": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_planks": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_planks": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_planks": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_planks": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_planks": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_planks": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_planks": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_planks": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_planks": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:oak_stairs": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_stairs": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_stairs": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_stairs": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_stairs": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_stairs": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_stairs": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_stairs": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_stairs": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_stairs": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_stairs": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:oak_double_slab": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_double_slab": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_double_slab": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_double_slab": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_double_slab": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_double_slab": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_double_slab": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_double_slab": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_double_slab": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_double_slab": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_double_slab": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:oak_slab": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_slab": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_slab": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_slab": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_slab": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_slab": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_slab": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_slab": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_slab": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_slab": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_slab": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:oak_fence": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_fence": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_fence": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_fence": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_fence": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_fence": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_fence": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_fence": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_fence": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_fence": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_fence": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:fence_gate": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_fence_gate": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_fence_gate": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_fence_gate": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_fence_gate": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_fence_gate": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_fence_gate": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_fence_gate": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_fence_gate": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_fence_gate": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_fence_gate": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:wooden_door": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_door": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_door": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_door": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_door": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_door": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_door": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_door": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_door": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_door": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_door": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
    "minecraft:trapdoor": "ldz_240409:weapon_zombie_villager_log_oak_stripped",
    "minecraft:spruce_trapdoor": "ldz_240409:weapon_zombie_villager_log_spruce_stripped",
    "minecraft:birch_trapdoor": "ldz_240409:weapon_zombie_villager_log_birch_stripped",
    "minecraft:jungle_trapdoor": "ldz_240409:weapon_zombie_villager_log_jungle_stripped",
    "minecraft:acacia_trapdoor": "ldz_240409:weapon_zombie_villager_log_acacia_stripped",
    "minecraft:dark_oak_trapdoor": "ldz_240409:weapon_zombie_villager_log_dark_oak_stripped",
    "minecraft:mangrove_trapdoor": "ldz_240409:weapon_zombie_villager_log_mangrove_stripped",
    "minecraft:cherry_trapdoor": "ldz_240409:weapon_zombie_villager_log_cherry_stripped",
    "minecraft:pale_oak_trapdoor": "ldz_240409:weapon_zombie_villager_log_pale_oak_stripped",
    "minecraft:crimson_trapdoor": "ldz_240409:weapon_zombie_villager_log_crimson_stripped",
    "minecraft:warped_trapdoor": "ldz_240409:weapon_zombie_villager_log_warped_stripped",
};
const FAST_BREAK_BLOCKS = [
    'leaf_litter',
    'leaves',
    'grass',
    'vine',
    'fern',
    'bush',
    'moss'
];
export function onZombieVillagerUse(player) {
    utils.abortEvents(getLoopId(player.id));
    utils.mclog(`${player.nameTag} Used Zombie Villager Weapon`);
    player.dimension.playSound("ldz_240409:weapon.zombie_villager.trigger", player.location);
    startChainsawLoops(player);
}
export function startChainsawLoops(player) {
    let isActive = true;
    const item = player.MainHand;
    if (!item)
        throw new Error("Chainsaw weapon not found in main hand.");
    const damageComponent = item.getComponent(mc.ItemDurabilityComponent.componentId);
    if (!damageComponent)
        throw new Error("Chainsaw weapon has no durability component.");
    const maxDurability = damageComponent.maxDurability;
    const starterDamage = damageComponent.damage;
    let additionalDamage = 0;
    let cachedLogTypeId;
    let blockBreakProgress = 0;
    utils.waitForLoopEvent(1, () => {
        if (!isActive || !player.isValid() || !isPlayerHoldingZombieVillagerWeapon(player)) {
            stopChainsaw();
            return true;
        }
        if (starterDamage + additionalDamage >= maxDurability) {
            stopChainsaw();
            return true;
        }
        const dimension = player.dimension;
        const headLocation = player.getHeadLocation();
        const viewDirection = player.getViewDirection();
        let victims = [];
        utils.getEntitiesFromRaySafe(dimension, headLocation, viewDirection, { maxDistance: MAX_MOB_HIT_RANGE, families: ['monster'] }).forEach(monster => victims.push(monster.entity));
        utils.getEntitiesFromRaySafe(dimension, headLocation, viewDirection, { maxDistance: MAX_MOB_HIT_RANGE, families: ['mob'] }).forEach(mob => victims.push(mob.entity));
        for (const victim of victims) {
            victim.applyDamage(3, { damagingEntity: player.UnsafeEntity, cause: mc.EntityDamageCause.entityAttack });
            additionalDamage += 1;
        }
        ;
        const log = getLog();
        if (log) {
            const location = new utils.Vector3(log.location);
            const particleId = BLOCK_PARTICLE_MAP[log.typeId];
            let breakDuration = 15;
            FAST_BREAK_BLOCKS.forEach(block => { if (log.typeId.includes(block))
                breakDuration = 1; });
            dimension.spawnParticle(particleId, location.up(0.4));
            if (log.typeId !== cachedLogTypeId) {
                blockBreakProgress = 0;
                cachedLogTypeId = log.typeId;
            }
            blockBreakProgress += 1;
            if (blockBreakProgress >= breakDuration) {
                const { x, y, z } = log.location;
                dimension.runCommand(`setblock ${x} ${y} ${z} air destroy`);
                blockBreakProgress = 0;
                cachedLogTypeId = undefined;
                additionalDamage += 1;
            }
        }
        else {
            blockBreakProgress = 0;
            cachedLogTypeId = undefined;
        }
    });
    player.dimension.playSound("ldz_240409:weapon.zombie_villager.trigger", player.location);
    utils.waitForLoopEvent(11, () => {
        if (!isActive || !player.isValid() || !isPlayerHoldingZombieVillagerWeapon(player)) {
            stopChainsaw();
            return true;
        }
        player.dimension.playSound("ldz_240409:weapon.zombie_villager.trigger", player.location);
    }, undefined, false);
    function getLog() {
        const hitBlock = player.dimension.getBlockFromRay(player.getHeadLocation(), player.getViewDirection(), { maxDistance: MAX_BLOCK_BREAK_RANGE });
        if (!hitBlock)
            return undefined;
        if (!(hitBlock.block.typeId in BLOCK_PARTICLE_MAP))
            return undefined;
        return hitBlock.block;
    }
    const stopUseEvent = (event) => {
        if (event.source.id === player.id) {
            isActive = false;
            cachedLogTypeId = undefined;
            blockBreakProgress = 0;
            mc.world.afterEvents.itemStopUse.unsubscribe(stopUseEvent);
            utils.abortEvents(getLoopId(player.id));
        }
    };
    mc.world.afterEvents.itemStopUse.subscribe(stopUseEvent);
    function stopChainsaw() {
        isActive = false;
        mc.world.afterEvents.itemStopUse.unsubscribe(stopUseEvent);
        const gamemode = player.getGameMode();
        if (gamemode === mc.GameMode.survival || gamemode === mc.GameMode.adventure)
            utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -additionalDamage);
    }
}
export const ZOMBIE_VILLAGER_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_zombie_villager", damage: 5 });
function getLoopId(playerId) {
    return `ZombieVillagerWeaponLoop_${playerId}`;
}
function isPlayerHoldingZombieVillagerWeapon(player) {
    var _a, _b;
    return ((_b = (_a = player.Equipment) === null || _a === void 0 ? void 0 : _a.getEquipment(mc.EquipmentSlot.Mainhand)) === null || _b === void 0 ? void 0 : _b.typeId) === "ldz_240409:weapon_zombie_villager";
}
