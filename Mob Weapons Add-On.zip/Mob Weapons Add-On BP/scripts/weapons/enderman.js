import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onEndermanUse(player) {
    utils.mclog(`${player.nameTag} Used Enderman Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    //mc.world.playSound("ldz_240409:weapon.enderman.shoot", player.getHeadLocation());
    new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_enderman_projectile", player.getViewDirection(), player, {
        power: 2.5,
        gravity: 0,
        shoot_sound: "ldz_240409:weapon.enderman.shoot",
        hit_sound: '',
        on_hit: {
            damage: 4,
            destroy_on_hit: true,
            hit_callback(projectile, hitEntities) {
                hitEntities.filter(entity => entity.id !== projectile.Entity.id).forEach(entity => {
                    endermanTeleport(entity, player);
                });
            },
        }
    });
}
async function endermanTeleport(entity, player) {
    let locX = entity.location.x;
    let locY = entity.location.y;
    let locZ = entity.location.z;
    for (let i = 0; i < 3; i++) {
        entity.applyDamage(i + 1, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: player });
        entity.dimension.spawnParticle('ldz_240409:vanilla_teleport', entity.location);
        player.playSound("ldz_240409:weapon.enderman.teleport");
        let location = new utils.Vector3({ x: locX + utils.getRandomInteger(-3, 3), y: locY, z: locZ + utils.getRandomInteger(-3, 3) });
        let checks = 0;
        while ((utils.getBlockStateAtLocation(location) === utils.state.solid || utils.getBlockStateAtLocation(location.add({ x: 0, y: 1, z: 0 })) === utils.state.solid) && checks < 20) {
            location = new utils.Vector3({ x: locX + utils.getRandomInteger(-3, 3), y: locY, z: locZ + utils.getRandomInteger(-3, 3) });
            checks++;
        }
        entity.teleport(new utils.Vector3(location));
        await utils.waitForTicks(6);
    }
}
