import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
class HomingProjectile extends utils.Projectile {
    updateDirection(newDirection) {
        this.Direction = newDirection;
    }
}
export async function onShulkerUse(player) {
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    const projectile = new HomingProjectile(player.getHeadLocation().add(player.getViewDirection().multiply(1)), player.dimension, "ldz_240409:weapon_shulker_projectile", player.getViewDirection(), player, {
        gravity: 0,
        power: 1,
        hit_sound: "mob.shulker.bullet.hit",
        shoot_sound: "ldz_240409:weapon.shulker.shoot",
        on_hit: {
            destroy_on_hit: true,
            hit_callback: (projectile, hitEntities, hitBlock) => {
                hitEntities.forEach((entity) => {
                    entity.addEffect("levitation", 40, { amplifier: 1 });
                });
            }
        }
    });
    let entities = getEntitiesFromView(player, 10);
    utils.waitForLoopEvent(0, () => {
        if (!projectile.Entity.isValid())
            return true;
        const firstValidEntity = entities.find((entity) => entity.isValid() && entity.id !== player.id);
        if (firstValidEntity) {
            projectile.updateDirection(firstValidEntity.location.subtract(projectile.Entity.location).normalize().multiply(0.5));
        }
    });
}
function getEntitiesFromView(entity, maxDistance) {
    const origin = entity.getHeadLocation();
    const families = ["mob"];
    const includePassableBlocks = false;
    const options = { maxDistance, families, includePassableBlocks };
    const out = [];
    utils.getEntitiesSafe(entity.dimension, { location: origin, maxDistance: maxDistance * 2, families }).forEach((target) => {
        if (target.id === entity.id)
            return;
        const viewDot = entity.getViewDotProduct(target.location);
        const isInAttackView = viewDot > 0.95;
        utils.mclog(`Checking ${target.typeId} ${viewDot}`);
        const targetDistance = entity.location.distance(target.location);
        const viewObscured = entity.getBlockFromViewDirection({ maxDistance: targetDistance });
        const isVisible = !viewObscured;
        if (isInAttackView && isVisible) {
            out.push(target);
        }
    });
    return out;
}
