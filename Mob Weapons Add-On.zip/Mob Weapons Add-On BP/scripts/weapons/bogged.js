import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onBoggedUse(player) {
    utils.mclog(`${player.nameTag} Used Bogged Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    for (let count = 0; count < 3; count++) {
        //mc.world.playSound("ldz_240409:weapon.bogged.shoot", player.getHeadLocation());
        mc.world.playSound("ldz_240409:weapon.bogged.shoot2", player.getHeadLocation());
        new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_bogged_projectile", player.getViewDirection(), player, {
            lifetime_seconds: 3,
            stick_in_ground: true,
            power: 2.5,
            gravity: 0.0075,
            offset: { x: 0, y: -0.2, z: 0 },
            faceDirection: true,
            shoot_sound: "ldz_240409:weapon.bogged.shoot",
            hit_sound: "ldz_240409:entity.weapon_bogged_projectile.impact",
            on_hit: {
                destroy_on_hit: true,
                damage: 5,
                knockback: true,
                hit_callback(projectile, hitEntities) {
                    if (hitEntities) {
                        hitEntities.forEach(entity => {
                            if (entity.isValid() && entity.typeId !== "ldz_240409:weapon_bogged_projectile" && entity.typeId !== "minecraft:item" && !entity.matches({ gameMode: mc.GameMode.creative })) {
                                entity.addEffect("fatal_poison", 80, { showParticles: true, amplifier: 2 });
                                mc.world.playSound("ldz_240409:entity.weapon_bogged_projectile.impact", entity.location, { pitch: 1.0, "volume": 5 });
                            }
                        });
                    }
                }
            }
        });
        await utils.waitForTicks(5);
    }
}
