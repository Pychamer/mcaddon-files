import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const VORTEX_RADIUS = 2.5;
const VORTEX_MOVE_SPEED_MULTIPLIER = 1.0;
const SWIRL_DAMAGE_AMOUNT = 6;
const VERTICAL_FLING_STRENGTH = 0.9;
const DISSIPATION_MIN_SPEED = 0.08;
async function initializeBreeze() {
    await utils.waitForWorldLoad();
    utils.runCommand("event entity @e[type=ldz_240409:weapon_breeze_projectile] despawn");
}
initializeBreeze();
export function onBreezeUse(player) {
    utils.mclog(`${player.nameTag} Used Breeze Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    const vortex = new utils.SafetyCheckedEntity(player.dimension.spawnEntity("ldz_240409:weapon_breeze_projectile", player.location));
    vortex.addEffect("slow_falling", 1000, { showParticles: false });
    // const playerYRotation = player.getRotation().y;
    const moveDirection = player.getViewDirection();
    const startTick = mc.system.currentTick;
    const endTick = mc.system.currentTick + 100;
    const movementThread = mc.system.runInterval(() => {
        if (!vortex.isValid()) {
            mc.system.clearRun(movementThread);
            return;
        }
        if (mc.system.currentTick >= endTick) {
            mc.system.clearRun(movementThread);
            vortex.runCommand("playsound ldz_240409:entity.weapon_breeze_projectile.extinguish @a ~ ~ ~");
            vortex.remove();
            return;
        }
        vortex.runCommand("fill ~-0.5 ~-1 ~-0.5 ~0.5 ~4 ~0.5 air replace fire");
        vortex.runCommand("fill ~-0.5 ~-1 ~-0.5 ~0.5 ~4 ~0.5 air replace soul_fire");
        vortex.runCommand("fill ~-0.5 ~-1 ~-0.5 ~0.5 ~4 ~0.5 campfire[\"extinguished\"=true] replace campfire");
        vortex.runCommand("fill ~-0.5 ~-1 ~-0.5 ~0.5 ~4 ~0.5 soul_campfire[\"extinguished\"=true] replace soul_campfire");
        const velocity = vortex.getVelocity();
        const speed = velocity.distance(new utils.Vector3(0));
        if (mc.system.currentTick > startTick + 1 && speed < DISSIPATION_MIN_SPEED) {
            mc.system.clearRun(movementThread);
            vortex.runCommand("playsound ldz_240409:entity.weapon_breeze_projectile.extinguish @a ~ ~ ~");
            vortex.remove();
            return;
        }
        if (vortex.isOnGround) {
            vortex.applyImpulse(moveDirection.multiply(0.2 * VORTEX_MOVE_SPEED_MULTIPLIER));
        }
        else {
            vortex.applyImpulse(moveDirection.multiply(0.04 * VORTEX_MOVE_SPEED_MULTIPLIER));
        }
    });
    const damageThread = mc.system.runInterval(() => {
        if (!vortex.isValid()) {
            mc.system.clearRun(damageThread);
            return;
        }
        utils.getEntitiesSafe(vortex.dimension, {
            location: vortex.location,
            maxDistance: VORTEX_RADIUS,
            excludeTypes: ["minecraft:item", "minecraft:xp_orb", "ldz_240409:weapon_breeze_projectile"]
        }).forEach(entity => {
            if (entity.id === player.id)
                return;
            swirlSequence(entity, player);
        });
    }, 10);
}
async function swirlSequence(entity, owner) {
    if (!entity.isValid())
        return;
    const horizontal = 2;
    const vertical = 0.1;
    try {
        entity.applyKnockback(0.5, 0.0, horizontal, vertical);
    }
    catch (error) {
        utils.mcwarn(`Cannot Apply Vortex To ${entity.typeId}`);
        return;
    }
    await utils.waitForTicks(2);
    if (!entity.isValid())
        return;
    entity.applyKnockback(0.0, 0.5, horizontal, vertical);
    await utils.waitForTicks(2);
    if (!entity.isValid())
        return;
    entity.applyKnockback(-0.5, 0.0, horizontal, vertical);
    await utils.waitForTicks(2);
    if (!entity.isValid())
        return;
    entity.applyKnockback(0.0, -0.5, horizontal, vertical);
    await utils.waitForTicks(2);
    if (!entity.isValid())
        return;
    entity.applyDamage(SWIRL_DAMAGE_AMOUNT, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: owner.UnsafeEntity });
    entity.applyKnockback(0.0, 0.0, 0.0, VERTICAL_FLING_STRENGTH);
}
