import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onPolarBearUse(player) {
    utils.mclog(`${player.nameTag} Used Polar Bear Weapon`);
    mc.world.playSound("ldz_240409:weapon.polar_bear.use", player.location);
}
export const POLAR_BEAR_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_polar_bear", damage: 4.1, delay: 0, hitCallbacks: [onHitWithPolarBear], maxAngle: 5, minAngle: -5 });
function onHitWithPolarBear(player, entity) {
    if (entity.isValid()) {
        //mc.world.playSound("ldz_240409:player.weapon_polar_bear.hit", player.location);
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
