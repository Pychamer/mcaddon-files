import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onRavagerUse(player) {
    utils.mclog(`${player.nameTag} Used Ravager Weapon`);
    mc.world.playSound("ldz_240409:weapon.ravager.use", player.location);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    await utils.waitForTicks(1);
    mc.world.playSound("ldz_240409:weapon.ravager.impact", player.location);
    const entities = player.dimension.getEntities({ location: player.getHeadLocation().add(player.getViewDirection().multiply(5)), maxDistance: 5 });
    entities.forEach(entity => {
        if (entity.id === player.id)
            return;
        try {
            entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.5);
            entity.applyDamage(4.1);
        }
        catch (e) {
            utils.mclog(`Error applying damage to ${entity.nameTag}: ${e}`);
        }
    });
}
export const RAVAGER_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_ravager", damage: 4.1, delay: 0.1, hitCallbacks: [onHitWithRavager], maxAngle: 8, minAngle: -8 });
function onHitWithRavager(player, entity) {
    if (entity.isValid()) {
        utils.mclog(`${player.nameTag} hit ${entity.nameTag} with Ravager Weapon`);
        entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.5);
    }
}
