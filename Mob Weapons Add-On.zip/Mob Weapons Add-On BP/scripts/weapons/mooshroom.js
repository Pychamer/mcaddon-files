import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const BLOCKS_TO_DESTROY = [
    "minecraft:tall_grass",
    "minecraft:short_grass",
    "minecraft:tall_dry_grass",
    "minecraft:short_dry_grass",
    "minecraft:fern",
    "minecraft:large_fern",
    "minecraft:vine",
    "minecraft:weeping_vines",
    "minecraft:bush",
    "minecraft:firefly_bush",
    "minecraft:leaf_litter"
];
export async function onMooshroomUse(player) {
    utils.mclog(`${player.nameTag} Used Mooshroom Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    player.playSound("ldz_240409:weapon.mooshroom.swing");
    await utils.waitForTicks(4);
    player.playSound("ldz_240409:weapon.mooshroom.impact");
    const entities = player.dimension.getEntities({ location: player.getHeadLocation().add(player.getViewDirection().multiply(2)), maxDistance: 3 });
    entities.forEach(entity => {
        if (entity.id === player.id)
            return;
        try {
            entity.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 3, 0.5);
            entity.applyDamage(4.1);
        }
        catch (e) {
            utils.mclog(`Error applying damage to ${entity.nameTag}: ${e}`);
        }
    });
    let direction = player.getViewDirection().normalize().multiply({ x: 1, y: 0, z: 1 });
    let start = player.location.add(direction).add({ x: -2, y: -1, z: -2 }).round();
    for (let x = 0; x < 4; x++) {
        for (let y = 0; y < 3; y++) {
            for (let z = 0; z < 4; z++) {
                let block = player.dimension.getBlock(start.add({ x: x, y: y, z: z }));
                for (let i = 0; i < BLOCKS_TO_DESTROY.length; i++) {
                    if (block === null || block === void 0 ? void 0 : block.permutation.matches(BLOCKS_TO_DESTROY[i])) {
                        player.dimension.runCommand(`setblock ${start.add({ x: x, y: y, z: z })} air destroy`);
                    }
                }
            }
        }
    }
}
export const MOOSHROOM_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_mooshroom", damage: 4, delay: 0.2, hitCallbacks: [onHitWithMooshroom], maxAngle: 15, minAngle: -10, duration: 0.5 });
function onHitWithMooshroom(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
