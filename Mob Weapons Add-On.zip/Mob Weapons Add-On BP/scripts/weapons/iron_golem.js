import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onIronGolemUse(player) {
    utils.mclog(`${player.nameTag} Used Iron Golem Weapon`);
    player.runCommand("playsound ldz_240409:weapon.iron_golem.use @a ~ ~ ~");
}
export const GOLEM_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_golem", hitCallbacks: [onHitWithGolem], damage: 0 });
function onHitWithGolem(player, entity) {
    if (entity.isValid()) {
        utils.getEntitiesSafe(player.dimension, { location: entity.location, maxDistance: 1.5, families: ["mob"] }).forEach(e => {
            var _a;
            utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
            const health = (_a = e.Health) === null || _a === void 0 ? void 0 : _a.currentValue;
            if (!health)
                return;
            let damage = 6;
            if (health <= damage)
                damage = health - 1;
            e.applyDamage(damage, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: player.UnsafeEntity });
            e.applyKnockback(0, 0, 0, 1);
        });
        utils.getEntitiesSafe(player.dimension, { location: entity.location, maxDistance: 1.5, families: ["player"] }).forEach(e => {
            var _a;
            if (e.id === player.id)
                return;
            utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
            const health = (_a = e.Health) === null || _a === void 0 ? void 0 : _a.currentValue;
            if (!health)
                return;
            let damage = 6;
            if (health <= damage)
                damage = health - 1;
            e.applyDamage(damage, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: player.UnsafeEntity });
            e.applyKnockback(0, 0, 0, 1);
        });
    }
    player.playSound("ldz_240409:weapon.iron_golem.impact");
}
