import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onCamelUse(player) {
    utils.mclog(`${player.nameTag} Used Camel Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    player.playSound("ldz_240409:weapon.camel.slice");
    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 0, 0.2);
    await utils.waitForTicks(2);
    player.applyKnockback(player.getViewDirection().x, player.getViewDirection().z, 7, 0.5);
    await utils.waitForTicks(2);
    utils.waitForEvent(0, () => {
        if (player.isOnGround)
            return true;
        player.dimension.getEntities({ location: player.location, maxDistance: 4 }).forEach((entity) => {
            if (entity.id === player.id)
                return;
            entity.applyDamage(6, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: player.UnsafeEntity });
        });
    });
}
export const CAMEL_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_camel", damage: 6, delay: 0, hitCallbacks: [onHitWithCamel], maxAngle: 15, minAngle: -10, duration: 0.5 });
function onHitWithCamel(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
