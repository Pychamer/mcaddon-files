import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onWitherUse(player) {
    utils.mclog(`${player.nameTag} Used Wither Weapon`);
    mc.world.playSound("ldz_240409:weapon.wither.load", player.location);
    let startTime = mc.system.currentTick;
    const onItemRelease = (event) => {
        var _a;
        if (((_a = event.itemStack) === null || _a === void 0 ? void 0 : _a.typeId) === "ldz_240409:weapon_wither", event.source.id === player.id) {
            mc.world.playSound("ldz_240409:weapon.wither.shoot", player.location);
            utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
            new utils.Projectile(player.getHeadLocation().add(player.getViewDirection()), player.dimension, "ldz_240409:weapon_wither_projectile", player.getViewDirection(), player, {
                power: utils.clamp((mc.system.currentTick - startTime) / 10, 0.1, 2),
                hit_sound: "",
                on_hit: {
                    damage: utils.clamp((mc.system.currentTick - startTime) / 10, 0.1, 7),
                    destroy_on_hit: true,
                    damageSource: "owner",
                    canHurtDragon: true,
                    multiple_targets: false,
                    hit_callback(projectile, hitEntities, hitBlock) {
                        var _a;
                        utils.mclog(`${(_a = projectile.Owner) === null || _a === void 0 ? void 0 : _a.nameTag} hit ${hitEntities.length} entities with Wither Weapon`);
                        let location = {
                            dimension: player.dimension,
                            x: projectile.Entity.location.x,
                            y: projectile.Entity.location.y,
                            z: projectile.Entity.location.z
                        };
                        location.dimension.createExplosion(location, 1, {
                            breaksBlocks: true
                        });
                        if (hitEntities) {
                            hitEntities.forEach(entity => {
                                entity.addEffect("wither", 200);
                            });
                        }
                    },
                }
            });
            mc.world.afterEvents.itemReleaseUse.unsubscribe(onItemRelease);
        }
    };
    mc.world.afterEvents.itemReleaseUse.subscribe(onItemRelease);
}
// export const WITHER_ATTACK = new utils.MeleeAttack({attackID: "ldz_240409:weapon_wither", damage: 4.1, delay: 0.1, hitCallbacks: [onHitWithWither], maxAngle: 5, minAngle: -5})
// function onHitWithWither(player: utils.SafetyCheckedPlayer, entity: utils.SafetyCheckedEntity) {
// 	if (entity.isValid()) {
// 		mc.world.playSound("ldz_240409:player.weapon_wither.impact", player.location);
// 		utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
// 		//entity.dimension.spawnParticle("ldz_240409:weapon_chicken_impact", entity.location.up());
// 	}
// }
