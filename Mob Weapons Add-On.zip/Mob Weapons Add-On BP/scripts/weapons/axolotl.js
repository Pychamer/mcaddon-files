import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onAxolotlUse(player) {
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    utils.mclog(`${player.nameTag} Used Axolotl Weapon`);
    player.playSound("ldz_240409:weapon.axolotl.swing");
}
export const AXOLOTL_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_axolotl", damage: 4.1, delay: 0.08, hitCallbacks: [onHitWithAxolotl], maxAngle: 15, minAngle: -10, duration: 0.5 });
function onHitWithAxolotl(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
