import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onWolfUse(player) {
    utils.mclog(`${player.nameTag} Used Wolf Weapon`);
    mc.world.playSound("ldz_240409:weapon.wolf.use", player.location);
}
export const WOLF_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_wolf", damage: 4.1, delay: 0, hitCallbacks: [onHitWithWolf], maxAngle: 15, minAngle: -10, duration: 0.5 });
function onHitWithWolf(player, entity) {
    if (entity.isValid()) {
        //mc.world.playSound("ldz_240409:player.weapon_wolf.hit", player.location);
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
