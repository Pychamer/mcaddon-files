import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onPiglinUse(player) {
    utils.mclog(`${player.nameTag} Used Piglin Weapon`);
    player.playSound('ldz_240409:weapon.piglin.use');
}
export const PIGLIN_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_piglin", hitCallbacks: [onHitWithPiglin], range: 5, damage: 6, delay: 0.05, minAngle: 11, maxAngle: 11 });
function onHitWithPiglin(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
        player.playSound('ldz_240409:weapon.piglin.impact');
        player.playSound('ldz_240409:weapon.piglin.coins');
        entity.dimension.spawnParticle("ldz_240409:weapon_piglin_impact", entity.location);
    }
}
