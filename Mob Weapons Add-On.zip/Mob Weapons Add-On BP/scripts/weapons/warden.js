import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const RANGE = 15;
export async function onWardenUse(player) {
    utils.mclog(`${player.nameTag} Used Warden Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    mc.world.playSound("ldz_240409:weapon.warden.use", player.getHeadLocation());
    await utils.waitForTicks(4);
    mc.world.playSound("ldz_240409:weapon.warden.sonic_boom", player.location);
    const origin = player.getHeadLocation();
    const direction = player.getViewDirection();
    for (let index = 1; index < RANGE; index++) {
        player.dimension.spawnParticle("ldz_240409:weapon_warden_sonic_boom", origin.add(direction.multiply(index)));
    }
}
export const WARDEN_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_warden", delay: 0.2, maxAngle: 5, minAngle: 5, range: RANGE, damage: 12, piercing: true });
