import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onTurtleUse(player) {
    utils.mclog(`${player.nameTag} Used Turtle Weapon`);
    player.runCommand("playsound ldz_240409:weapon.iron_golem.use @a ~ ~ ~");
    throwWeapon(player);
}
const FLIGHT_MAX_DURATION = 1 * mc.TicksPerSecond;
const FLIGHT_SPEED = 1.0;
const WEAPON_TYPE_ID = "ldz_240409:weapon_turtle_projectile";
const MAX_DURABILITY = 300;
const DAMAGE = 0;
const ENTITY_HIT_EFFECT = { id: "slowness", duration: 100, amplifier: 255, showParticles: true };
const ITEM_PICKUP_RADIUS = 2;
async function throwWeapon(player) {
    var _a, _b;
    const damage = (_b = (_a = player.MainHand) === null || _a === void 0 ? void 0 : _a.getComponent(mc.ItemDurabilityComponent.componentId)) === null || _b === void 0 ? void 0 : _b.damage;
    if (damage === undefined)
        throw new Error("Could not get damage of item in main hand.");
    player.MainHand = undefined;
    const dimension = player.dimension;
    const headLocation = player.getHeadLocation();
    const viewDirection = player.getViewDirection();
    player.playSoundAt("ldz_240409:weapon.iron_golem.use");
    player.playSoundAt("ldz_240409:weapon.turtle.shoot");
    const outboundProjectile = new TurtleWeaponProjectile(headLocation, dimension, WEAPON_TYPE_ID, viewDirection, player, {
        power: FLIGHT_SPEED,
        gravity: 0.0,
        inertia: 1.0,
        stick_in_ground: false,
        hit_sound: "",
        on_hit: {
            filters: { excludeTypes: [WEAPON_TYPE_ID, "minecraft:item"] },
            damage: DAMAGE,
            multiple_targets: false,
            destroy_on_hit: false,
            knockback: true,
            hit_callback(projectile, hitEntities) {
                for (const entity of hitEntities) {
                    if (entity.matches({ excludeFamilies: ["monster", "mob", "fish", "animal"] }))
                        continue;
                    const { id, duration, amplifier, showParticles } = ENTITY_HIT_EFFECT;
                    entity.addEffect(id, duration, { amplifier, showParticles });
                    entity.playSoundAt("ldz_240409:weapon.turtle.hit");
                    entity.applyDamage(0.01, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: player.UnsafeEntity });
                    entity.clearVelocity();
                }
                projectile.state = "returning";
            }
        }
    });
    utils.writeDynamicProperty(outboundProjectile.Entity, "damage", damage);
    await utils.waitForTicks(FLIGHT_MAX_DURATION);
    outboundProjectile.state = "returning";
}
class TurtleWeaponProjectile extends utils.Projectile {
    constructor() {
        super(...arguments);
        this.state = "outbound";
        this.returnSpeedFactor = 1.0;
    }
    async shoot() {
        var _a, _b;
        mc.world.playSound(this.shoot_sound, this.Location);
        let loops = 0;
        while (this.Entity.isValid() && !this.StuckInGround) {
            try {
                this.hitChecks();
            }
            catch (error) {
                break;
            }
            if (!this.Entity.isValid() || this.StuckInGround)
                break;
            if (this.state === "returning" && ((_a = this.Owner) === null || _a === void 0 ? void 0 : _a.isValid())) {
                this.Direction = this.Owner.location.up(1).subtract(this.Entity.location).normalize();
                this.returnSpeedFactor += 0.05; // Accelerate return speed the longer it returns
            }
            this.Entity.teleport(this.Entity.location.add(this.Direction.multiply(this.Speed * this.returnSpeedFactor)));
            this.Direction.y -= this.gravity;
            this.Direction = this.Direction.normalize();
            this.updateRotation();
            this.pickupItems();
            if (this.state === "returning" && ((_b = this.Owner) === null || _b === void 0 ? void 0 : _b.isValid())) {
                this.checkNearOwnerForReturn(loops);
                loops += 1;
            }
            await utils.waitForTicks(0);
        }
        while (this.Entity.isValid()) {
            this.updateRotation();
            await utils.waitForTicks(0);
        }
    }
    pickupItems() {
        const { dimension, location } = this.Entity;
        const nearbyItems = dimension.getEntities({ location, maxDistance: ITEM_PICKUP_RADIUS, type: "minecraft:item" });
        for (const item of nearbyItems) {
            let carriedById = utils.readDynamicProperty(item, "turtleWeaponCarriedById");
            if (!carriedById) {
                carriedById = this.Entity.id;
                utils.writeDynamicProperty(item, "turtleWeaponCarriedById", carriedById);
            }
            if (carriedById === this.Entity.id) {
                item.teleport(this.Entity.location.down(0.4));
            }
        }
    }
    checkNearOwnerForReturn(loops) {
        var _a;
        if (this.state !== "returning" || !((_a = this.Owner) === null || _a === void 0 ? void 0 : _a.isValid()))
            throw new Error("Projectile is not returning or owner is invalid.");
        const ownerDistance = this.Owner.location.up(1).distance(this.Entity.location);
        // utils.mclog(`Turtle weapon distance to owner: ${ownerDistance.toFixed(2)}`);
        const buffer = loops * 0.02;
        const isNearOwner = this.Owner.dimension.id === this.Entity.dimension.id && ownerDistance < (0.3 + buffer);
        if (isNearOwner || loops > 19) {
            this.returnAsItemToOwner();
        }
    }
    returnAsItemToOwner() {
        if (!this.Owner)
            throw new Error("Owner nonexistent.");
        let damage = utils.readDynamicProperty(this.Entity, "damage");
        if (damage === undefined)
            throw new Error("Could not read damage of weapon from projectile.");
        if (this.Owner.matches({ gameMode: mc.GameMode.survival }) || this.Owner.matches({ gameMode: mc.GameMode.adventure })) {
            damage += 1;
            utils.mclog(`Returning turtle weapon with ${damage} damage.`);
        }
        const durability = MAX_DURABILITY - damage;
        if (durability < 1) {
            this.Owner.playSoundAt("random.break", { volume: 1.0, pitch: 1.0 });
        }
        else {
            const player = new utils.SafetyCheckedPlayer(this.Owner.UnsafeEntity);
            const selectedSlotIndex = player.selectedSlotIndex;
            const inventory = player.Inventory;
            const item = inventory === null || inventory === void 0 ? void 0 : inventory.getItem(selectedSlotIndex);
            if (inventory) {
                if (item) {
                    const { dimension, location } = this.Owner;
                    dimension.spawnItem(item, location);
                }
                const itemStack = new mc.ItemStack("ldz_240409:weapon_turtle");
                itemStack.getComponent(mc.ItemDurabilityComponent.componentId).damage = damage;
                player.Inventory.setItem(selectedSlotIndex, itemStack);
            }
            else {
                const { dimension, location } = this.Owner;
                const itemStack = new mc.ItemStack("ldz_240409:weapon_turtle");
                itemStack.getComponent(mc.ItemDurabilityComponent.componentId).damage = damage;
                dimension.spawnItem(itemStack, location);
            }
        }
        this.Entity.remove();
    }
    // Same as parent but modified to not stick in ground on hit
    hitChecks() {
        let hitEntities = this.getHitEntities();
        let hitBlock = this.Entity.dimension.getBlockFromRay(this.Entity.location, this.Direction, { includeLiquidBlocks: false, includePassableBlocks: false, maxDistance: Math.max(this.Speed + this.power, 1) });
        if (!hitBlock && !hitEntities.length)
            return;
        mc.world.playSound(this.hit_sound, this.Entity.location);
        if (!this.on_hit.multiple_targets && hitEntities.length > 0) {
            hitEntities.length = 1;
            const { x, z } = hitEntities[0].location;
            this.Entity.teleport({ x, y: this.Entity.location.y, z });
            // this.stuck_in_ground = true; // Stop doing this
            if (this.on_hit.destroy_on_hit) {
                utils.waitForEvent(10, () => this.Entity.remove());
            }
        }
        ;
        if (hitBlock && (this.stick_in_ground || this.on_hit.destroy_on_hit)) {
            this.Entity.teleport(new utils.Vector3(hitBlock.block.location).add(hitBlock.faceLocation));
            // this.stuck_in_ground = true; // Stop doing this
            if (this.on_hit.destroy_on_hit) {
                utils.waitForEvent(6, () => this.Entity.remove());
            }
        }
        this.applyHit(hitEntities, hitBlock);
    }
}
