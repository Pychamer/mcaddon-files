import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onEnderDragonUse(player) {
    utils.mclog(`${player.nameTag} Used Ender Dragon Weapon`);
    player.runCommand("playsound ldz_240409:weapon.ender_dragon.use @a ~ ~ ~");
    const melee = new utils.MeleeAttack({ attackID: "dragon_fire", disableDebug: true, damage: 9, piercing: true, hitCallbacks: [
            (player, hitEntity) => {
                hitEntity.setOnFire(10, true);
            }
        ] });
    let stopAttacking = false;
    const endAttack = (event) => {
        if (event.source.id === player.id) {
            stopAttacking = true;
            mc.world.afterEvents.itemStopUse.unsubscribe(endAttack);
            utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
        }
    };
    mc.world.afterEvents.itemStopUse.subscribe(endAttack);
    utils.waitForLoopEvent(5, () => {
        mc.world.playSound("ldz_240409:weapon.ender_dragon.flames", player.location);
        const direction = player.getViewDirection();
        const map = new mc.MolangVariableMap();
        map.setFloat("variable.direction_x", direction.x);
        map.setFloat("variable.direction_y", direction.y);
        map.setFloat("variable.direction_z", direction.z);
        player.dimension.spawnParticle("ldz_240409:weapon_ender_dragon_flames", player.getHeadLocation().add(direction), map);
        melee.attack(player);
        return stopAttacking;
    });
}
