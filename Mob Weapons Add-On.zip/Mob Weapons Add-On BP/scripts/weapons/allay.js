import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onAllayUse(player) {
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    const projectile = new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_allay_projectile", player.getViewDirection(), player, {
        power: 1,
        gravity: 0,
        faceDirection: true,
        shoot_sound: "ldz_240409:entity.weapon_allay_projectile.shoot",
        hit_sound: "ldz_240409:entity.weapon_allay_projectile.impact",
        lifetime_seconds: 3,
        on_hit: {
            destroy_on_hit: false,
            multiple_targets: true,
            hit_callback(projectile, hitEntities, hitBlock) {
                projectile.Entity.dimension.spawnParticle("ldz_240409:weapon_allay_projectile_impact", projectile.Entity.location);
                if (hitBlock) {
                    projectile.Entity.remove();
                }
            },
        }
    });
    utils.waitForLoopEvent(1, () => {
        if (!projectile.Entity.isValid()) {
            return true;
        }
        ;
        let entities = projectile.Entity.dimension.getEntities({ location: projectile.Entity.location, maxDistance: 2, families: ["mob"] });
        entities.push(...projectile.Entity.dimension.getEntities({ location: projectile.Entity.location, maxDistance: 2, families: ["fish"] }));
        entities.push(...projectile.Entity.dimension.getEntities({ location: projectile.Entity.location, maxDistance: 2, families: ["goat"] }));
        entities.push(...projectile.Entity.dimension.getEntities({ location: projectile.Entity.location, maxDistance: 2, families: ["panda"] }));
        if (mc.world.gameRules.pvp)
            entities.push(...projectile.Entity.dimension.getEntities({ location: projectile.Entity.location, maxDistance: 2, families: ["player"] }));
        entities.forEach((entity) => {
            if (entity.id === player.id || entity.id === projectile.Entity.id)
                return;
            entity.teleport(projectile.Entity.location);
        });
    });
}
