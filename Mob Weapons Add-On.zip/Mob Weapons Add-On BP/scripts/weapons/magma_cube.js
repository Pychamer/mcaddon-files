import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const ON_FIRE_CHANCE = 5; // 1 in 5 chance to set target on fire
const ON_FIRE_DURATION = 5; // seconds
export async function onMagmaCubeUse(player) {
    utils.mclog(`${player.nameTag} Used Magma Cube Weapon`);
    mc.world.playSound("ldz_240409:weapon.magma_cube.squish", player.location);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    await utils.waitForTicks(1);
    mc.world.playSound("ldz_240409:weapon.magma_cube.trigger", player.location);
}
export const MAGMA_CUBE_ATTACK = new utils.MeleeAttack({
    attackID: "ldz_240409:weapon_magma_cube",
    delay: 0.1,
    damage: 7,
    range: 9,
    hitCallbacks: [onHitWithMagmaCubeWeapon],
});
function onHitWithMagmaCubeWeapon(_, entity) {
    if (utils.getRandomInteger(1, ON_FIRE_CHANCE) === 1)
        entity.setOnFire(ON_FIRE_DURATION);
}
