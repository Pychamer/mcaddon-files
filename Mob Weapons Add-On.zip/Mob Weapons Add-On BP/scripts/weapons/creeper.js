import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onCreeperUse(player) {
    utils.mclog(`${player.nameTag} Used Creeper Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    //mc.world.playSound("ldz_240409:weapon.creeper.shoot", player.getHeadLocation(),{volume:0.7});
    new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_creeper_projectile", player.getViewDirection(), player, {
        power: 2,
        shoot_sound: "ldz_240409:weapon.creeper.shoot",
        hit_sound: "",
        offset: { x: 0, y: -0.2, z: 0 },
        faceDirection: true,
        gravity: 0.0,
        on_hit: {
            destroy_on_hit: true,
            hit_callback(projectile) {
                projectile.Entity.dimension.spawnParticle("minecraft:camera_shoot_explosion", projectile.Entity.location);
                projectile.Entity.triggerEvent(`explode`);
                projectile.Entity.runCommand(`stopsound @a[r=16] ldz_240409:weapon.creeper.fuse`);
                projectile.Entity.runCommand(`event entity @s despawn`);
            }
        }
    });
}
