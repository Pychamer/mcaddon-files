import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export async function onGhastUse(player) {
    utils.mclog(`${player.nameTag} Used Ghast Weapon`);
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    mc.world.playSound("ldz_240409:weapon.ghast.scream", player.location);
    await utils.waitForTicks(1);
    new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_ghast_projectile", player.getViewDirection(), player, {
        gravity: 0,
        power: 2,
        shoot_sound: "ldz_240409:weapon.ghast.shoot",
        faceDirection: false,
        on_hit: {
            hit_callback(projectile, hitEntities) {
                projectile.Entity.triggerEvent("minecraft:explode");
                hitEntities.forEach(entity => entity.setOnFire(3));
            },
        }
    });
}
