import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
import { Quaternion } from "../utils/quaternion";
const BLACK_LIST = [
    'minecraft:ender_dragon',
    'minecraft:warden',
    'minecraft:wither',
    'minecraft:elder_guardian',
    'minecraft:creaking'
];
const STRUCTURE_ID_PROPERTY = "savedMobStructureID";
const SAVED_MOB_TAG = "snifferSavedMob";
const SHOOT_STRENGTH = 1.9;
export function onSnifferUse(player) {
    utils.mclog(`${player.nameTag} Used Sniffer Weapon`);
    player.playSoundAt("ldz_240409:weapon.sniffer.start");
    const item = player.MainHand;
    if (!item)
        throw new Error("Player has no item in main hand");
    const hasSavedMob = utils.readDynamicProperty(item, STRUCTURE_ID_PROPERTY);
    if (hasSavedMob) {
        shootMob(player, hasSavedMob, player.id);
    }
    else {
        startSniffing(player);
    }
}
async function shootMob(player, structureID, ownerID) {
    const { dimension, location } = player;
    mc.world.structureManager.place(structureID, dimension, location, { includeBlocks: false, includeEntities: true });
    const viewDirection = player.getViewDirection();
    utils.waitForTicks(2);
    const target = utils.getEntitiesSafe(dimension, { location, tags: [`ldz_240409:${SAVED_MOB_TAG}`], closest: 1, maxDistance: 5 })[0];
    if (target) {
        target.removeTag(SAVED_MOB_TAG);
        target.applyImpulse(viewDirection.multiply(SHOOT_STRENGTH).up(0.5));
        hurtMobsNearProjectileMob(target, ownerID);
    }
    mc.world.structureManager.delete(structureID);
    const item = player.MainHand;
    if (item) {
        item.setLore([]);
        item.clearDynamicProperties();
        player.MainHand = item;
    }
    mc.world.playSound("ldz_240409:weapon.sniffer.shoot", player.location);
    player.runCommand('camerashake add @s 1.0 0.2 positional');
}
export function startSniffing(player) {
    let isActive = true;
    utils.waitForLoopEvent(0, () => {
        if (!isActive || !player.isValid() || !isPlayerHoldingSnifferWeapon(player)) {
            stopSniffing();
            return true;
        }
        const viewDirection = player.getViewDirection();
        const headLocation = player.getHeadLocation();
        const rotation = player.getRotation();
        const pitchRadians = rotation.x * Math.PI / 180;
        const yawRadians = rotation.y * Math.PI / 180;
        const yawQuat = Quaternion.fromAxisAngle(utils.Vector3.UP, -yawRadians);
        const xAxis = utils.Vector3.EAST.rotateYaw(-rotation.y);
        const pitchQuat = Quaternion.fromAxisAngle(xAxis, pitchRadians);
        const finalQuat = pitchQuat.multiply(yawQuat);
        const localOffset = new utils.Vector3({ x: -0.5, y: 0, z: 1.3 }).applyQuaternion(finalQuat); // Start particles in front of gun
        const particleLocation = headLocation.add(localOffset);
        const vars = new mc.MolangVariableMap();
        vars.setVector3("direction", viewDirection);
        player.dimension.spawnParticle("ldz_240409:weapon_sniffer_suck", particleLocation, vars);
    });
    utils.waitForLoopEvent(2, () => {
        var _a, _b;
        if (!isActive || !player.isValid() || !isPlayerHoldingSnifferWeapon(player)) {
            stopSniffing();
            return true;
        }
        player.playAnimation(`animation.ldz_240409.player.weapon_sniffer.attack.third_person.held`, {
            stopExpression: "!q.is_using_item",
            nextState: "default",
            blendOutTime: 0.2,
            controller: `weapon_sniffer.third_person`,
        });
        const headLocation = player.getHeadLocation();
        const viewDirection = player.getViewDirection();
        const dimension = player.dimension;
        const monsterTarget = (_a = utils.getEntitiesFromRaySafe(dimension, headLocation, viewDirection, { maxDistance: 12, families: ['monster'] })[0]) === null || _a === void 0 ? void 0 : _a.entity;
        const mobTarget = (_b = utils.getEntitiesFromRaySafe(dimension, headLocation, viewDirection, { maxDistance: 12, families: ['mob'] })[0]) === null || _b === void 0 ? void 0 : _b.entity;
        const target = [monsterTarget, mobTarget]
            .filter(entity => !BLACK_LIST.includes(entity === null || entity === void 0 ? void 0 : entity.typeId) && (entity === null || entity === void 0 ? void 0 : entity.isValid()))[0];
        if (target) {
            const dist = player.location.distance(target.location);
            if (dist <= 1) {
                saveMob(player, target);
                isActive = false;
            }
            else {
                const vel = target.getVelocity().y;
                const dir = player.location.subtract(target.location).normalize();
                const hStrength = 0.4;
                const vStrength = vel <= 0.3 ? 1.3 : 0.7;
                target.applyImpulse(dir.multiply({ x: hStrength, y: vStrength, z: hStrength }));
            }
        }
    });
    utils.waitForLoopEvent(11, () => {
        if (!isActive || !player.isValid() || !isPlayerHoldingSnifferWeapon(player)) {
            stopSniffing();
            return true;
        }
        player.playSoundAt("ldz_240409:weapon.sniffer.loop");
    });
    const stopUseEvent = (event) => {
        if (event.source.id === player.id) {
            stopSniffing();
        }
    };
    mc.world.afterEvents.itemStopUse.subscribe(stopUseEvent);
    function stopSniffing() {
        isActive = false;
        mc.world.afterEvents.itemStopUse.unsubscribe(stopUseEvent);
    }
}
async function saveMob(player, target) {
    utils.mclog(`${player.nameTag} Sniffer Weapon saving mob: ${target.typeId}`);
    target.addTag(SAVED_MOB_TAG);
    target.addEffect('invisibility', 3, { showParticles: false });
    target.addEffect('slow_falling', 3, { showParticles: false });
    utils.waitForTicks(1);
    target.teleport(player.location.up(5));
    utils.waitForTicks(1);
    const structureID = `mystructure:${target.id}`;
    const { dimension, location } = player;
    mc.world.structureManager.createFromWorld(structureID, dimension, location.up(5), location.up(5), {
        includeBlocks: false,
        includeEntities: true,
        saveMode: mc.StructureSaveMode.World,
    });
    utils.waitForTicks(1);
    target.remove();
    if (player.MainHand)
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    const item = player.MainHand;
    if (item) {
        item.setLore([formatTypeString('Contains ' + target.typeId)]);
        item.setDynamicProperty(STRUCTURE_ID_PROPERTY, structureID);
        player.MainHand = item;
    }
    mc.world.playSound("ldz_240409:weapon.sniffer.capture", player.location);
    player.runCommand('camerashake add @s 0.5 0.4 positional');
}
export const SNIFFER_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_sniffer", damage: 5 });
function formatTypeString(value) {
    value = value.replace("minecraft:", "");
    value = value.replace("_v2", "");
    value = value.replace("_v3", "");
    value = value.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
    return value;
}
function getLoopId(playerId) {
    return `SnifferWeapon_${playerId}`;
}
function isPlayerHoldingSnifferWeapon(player) {
    var _a;
    return ((_a = player.MainHand) === null || _a === void 0 ? void 0 : _a.typeId) === "ldz_240409:weapon_sniffer";
}
async function hurtMobsNearProjectileMob(victim, ownerID) {
    const player = utils.getEntitySafe(ownerID);
    let dealtDamage = false;
    for (let index = 0; index < 18; index++) {
        if (!dealtDamage) {
            const monsters = utils.getEntitiesSafe(victim.dimension, { location: victim.location, maxDistance: 1.5, families: ["monster"], excludeTypes: ['minecraft:player'] }).filter(entity => entity.id !== victim.id);
            const mobs = monsters.concat(utils.getEntitiesSafe(victim.dimension, { location: victim.location, maxDistance: 1.5, families: ["mob"], excludeTypes: ['minecraft:player'] })).filter(entity => entity.id !== victim.id);
            mobs.forEach(mob => {
                if (player) {
                    mob.applyDamage(6, { cause: mc.EntityDamageCause.entityAttack, damagingEntity: player });
                }
                else {
                    mob.applyDamage(6);
                }
                dealtDamage = true;
            });
            await utils.waitForTicks(2);
        }
    }
}
