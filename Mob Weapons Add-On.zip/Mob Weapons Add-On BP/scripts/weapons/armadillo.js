import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
const BLOCK_BLACKLIST = [
    "minecraft:allow",
    "minecraft:barrel",
    "minecraft:barrier",
    "minecraft:bedrock",
    "minecraft:border_block",
    "minecraft:chain_command_block",
    "minecraft:chest",
    "minecraft:command_block",
    "minecraft:deny",
    "minecraft:end_portal_frame",
    "minecraft:end_portal",
    "minecraft:end_portal",
    "minecraft:ender_chest",
    "minecraft:light_block",
    "minecraft:repeating_command_block",
    "minecraft:structure_block",
    "minecraft:structure_void",
];
export async function onArmadilloUse(player) {
    utils.mclog(`${player.nameTag} Used Armadillo Weapon`);
    let blockCount = 10;
    //player.runCommand("playsound ldz_240409:weapon.armadillo.shoot @a ~ ~ ~");
    await utils.waitForTicks(1);
    if (!player.isValid())
        return;
    player.runCommand("playsound ldz_240409:weapon.armadillo.projectile_spin @a ^ ^ ^3");
    utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    new utils.Projectile(player.getHeadLocation(), player.dimension, "ldz_240409:weapon_armadillo_projectile", player.getViewDirection(), player, {
        power: 1.0,
        gravity: 0.0,
        offset: { x: 0, y: 0, z: 0 },
        shoot_sound: "ldz_240409:weapon.armadillo.shoot",
        hit_sound: "",
        on_hit: {
            damage: 9,
            multiple_targets: true,
            destroy_on_hit: false,
            knockback: true,
            hit_callback(projectile, hitEntities, hitBlock) {
                if (hitBlock && blockCount > 0) {
                    tryBreakBlocks(getAdjacentBlocks(hitBlock.block));
                    blockCount--;
                }
            },
        }
    });
}
function getAdjacentBlocks(block) {
    const loc = new utils.Vector3(block.location);
    let blocks = [block];
    const dist = 0.333;
    const north = block.dimension.getBlock(loc.add({ x: 0, y: 0, z: -dist }));
    const south = block.dimension.getBlock(loc.add({ x: 0, y: 0, z: dist }));
    const east = block.dimension.getBlock(loc.add({ x: dist, y: 0, z: 0 }));
    const west = block.dimension.getBlock(loc.add({ x: -dist, y: 0, z: 0 }));
    const up = block.dimension.getBlock(loc.add({ x: 0, y: dist, z: 0 }));
    const down = block.dimension.getBlock(loc.add({ x: 0, y: -dist, z: 0 }));
    if (north && north.isValid())
        blocks.push(north);
    if (south && south.isValid())
        blocks.push(south);
    if (east && east.isValid())
        blocks.push(east);
    if (west && west.isValid())
        blocks.push(west);
    if (up && up.isValid())
        blocks.push(up);
    if (down && down.isValid())
        blocks.push(down);
    return blocks;
}
function tryBreakBlocks(blocks) {
    blocks.forEach(block => {
        if (BLOCK_BLACKLIST.every(banned_block => !block.permutation.matches(banned_block))) {
            block.dimension.runCommand(`setblock ${new utils.Vector3(block.location)} minecraft:air destroy`);
        }
    });
}
