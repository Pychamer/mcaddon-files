import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onPufferfishUse(player) {
    utils.mclog(`${player.nameTag} Used Pufferfish Weapon`);
    player.playSound('ldz_240409:weapon.pufferfish.use');
}
export const PUFFERFISH_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_pufferfish", hitCallbacks: [onHitWithPufferfish] });
function onHitWithPufferfish(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
        player.playSound('ldz_240409:weapon.pufferfish.impact');
        const variableMap = new mc.MolangVariableMap();
        variableMap.setColorRGBA('variable.color', { alpha: 0, red: 0.4, blue: 0.1, green: 0.6 });
        variableMap.setFloat('variable.splash_range', 20);
        variableMap.setFloat('variable.splash_power', 6);
        player.dimension.spawnParticle('minecraft:splash_spell_emitter', entity.location.add({ x: 0, y: 0.5, z: 0 }), variableMap);
        const victims = player.dimension.getEntities({ location: player.location, maxDistance: 5 }).filter(entity => entity.id !== player.id);
        victims.forEach(victim => {
            try {
                victim.addEffect("fatal_poison", 80, { showParticles: true, amplifier: 2 });
            }
            catch (error) { }
        });
    }
}
