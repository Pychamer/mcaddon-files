import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onChickenUse(player) {
    utils.mclog(`${player.nameTag} Used Chicken Weapon`);
    mc.world.playSound("ldz_240409:weapon.chicken.use", player.location);
}
export const CHICKEN_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_chicken", damage: 4.1, delay: 0.1, hitCallbacks: [onHitWithChicken], maxAngle: 5, minAngle: -5 });
function onHitWithChicken(player, entity) {
    if (entity.isValid()) {
        mc.world.playSound("ldz_240409:weapon.chicken.impact", player.location);
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
        entity.dimension.spawnParticle("ldz_240409:weapon_chicken_impact", entity.location.up());
    }
}
