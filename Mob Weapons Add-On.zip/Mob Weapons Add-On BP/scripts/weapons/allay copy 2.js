import * as utils from "../utils/index";
export async function onAllayUse(player) {
    utils.mclog(`${player.nameTag} Used Allay Weapon`);
}
