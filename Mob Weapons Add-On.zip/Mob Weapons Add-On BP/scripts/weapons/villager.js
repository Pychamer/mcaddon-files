import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onVillagerUse(player) {
    utils.mclog(`${player.nameTag} Used Villager Weapon`);
    player.playSound('ldz_240409:weapon.villager.use');
}
export const VILLAGER_ATTACK = new utils.MeleeAttack({ attackID: "ldz_240409:weapon_villager", delay: 0.05, range: 7, damage: 6, hitCallbacks: [onHitWithVillager] });
function onHitWithVillager(player, entity) {
    if (entity.isValid()) {
        player.playSound('ldz_240409:weapon.villager.impact');
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
    }
}
