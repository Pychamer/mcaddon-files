import * as mc from "@minecraft/server";
import * as utils from "../utils/index";
export function onCowUse(player) {
    utils.mclog(`${player.nameTag} Used Cow Weapon`);
    mc.world.playSound("ldz_240409:weapon.cow.use", player.location);
}
export const COW_ATTACK = new utils.MeleeAttack({
    attackID: "ldz_240409:weapon_cow",
    range: 6,
    damage: 6,
    minAngle: 16,
    maxAngle: 16,
    minAngleVertical: 16,
    maxAngleVertical: 16,
    delay: 0.05,
    duration: 3,
    hitCallbacks: [onHitWithCow],
});
function onHitWithCow(player, entity) {
    if (entity.isValid()) {
        utils.modifyEquipmentDurability(player, mc.EquipmentSlot.Mainhand, -1);
        mc.world.playSound("ldz_240409:weapon.cow.impact", player.location);
    }
}
