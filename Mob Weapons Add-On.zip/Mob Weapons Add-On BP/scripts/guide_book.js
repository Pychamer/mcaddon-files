import * as mc from '@minecraft/server';
import * as utils from './utils/index';
export function initializeGuideBook() {
    //utils.mclog("book")
    utils.getAllPlayersSafe().forEach(giveGuideBook);
    mc.world.afterEvents.playerSpawn.subscribe(event => {
        if (event.initialSpawn) {
            giveGuideBook(new utils.SafetyCheckedPlayer(event.player));
        }
    });
}
function giveGuideBook(player) {
    let hasBook = false;
    if (player.runCommand("testfor @s[hasitem={item=ldz_240409:guide_book}]").successCount > 0)
        hasBook = true;
    if (utils.readDynamicProperty(player, "has_book"))
        hasBook = true;
    if (!hasBook) {
        player.runCommand('structure load "ldz_240409/guide_book" ~ ~ ~');
        utils.writeDynamicProperty(player, "has_book", true);
    }
}
export function useGuideBook(player) {
    utils.mclog("Using Book");
    const menu = new utils.MenuBuilder({
        type: "page_list",
        title: "ldz_240409:menu.book.main.title",
        contents: {
            weapons: {
                type: "page_list",
                icon: "textures/ldz/240409/items/weapon_armadillo",
                buttonLabel: utils.translate('menu.book.weapons_menu.button'),
                title: utils.translate('menu.book.weapons_menu.title'),
                backButtonPosition: "both",
                contents: {
                    allay: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedAllay') ? "textures/ldz/240409/items/weapon_allay" : "textures/ldz/240409/items/weapon_allay_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedAllay') ? { translate: "item.ldz_240409:weapon_allay.name" } : { translate: "item.ldz_240409:weapon_allay.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedAllay') ? { translate: "item.ldz_240409:weapon_allay.name" } : { translate: "item.ldz_240409:weapon_allay.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.allay.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.allay.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    armadillo: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedArmadillo') ? "textures/ldz/240409/items/weapon_armadillo" : "textures/ldz/240409/items/weapon_armadillo_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedArmadillo') ? { translate: "item.ldz_240409:weapon_armadillo.name" } : { translate: "item.ldz_240409:weapon_armadillo.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedArmadillo') ? { translate: "item.ldz_240409:weapon_armadillo.name" } : { translate: "item.ldz_240409:weapon_armadillo.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.armadillo.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.armadillo.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    axolotl: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedAxolotl') ? "textures/ldz/240409/items/weapon_axolotl" : "textures/ldz/240409/items/weapon_axolotl_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedAxolotl') ? { translate: "item.ldz_240409:weapon_axolotl.name" } : { translate: "item.ldz_240409:weapon_axolotl.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedAxolotl') ? { translate: "item.ldz_240409:weapon_axolotl.name" } : { translate: "item.ldz_240409:weapon_axolotl.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.axolotl.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.axolotl.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    bee: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBee') ? "textures/ldz/240409/items/weapon_bee" : "textures/ldz/240409/items/weapon_bee_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBee') ? { translate: "item.ldz_240409:weapon_bee.name" } : { translate: "item.ldz_240409:weapon_bee.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBee') ? { translate: "item.ldz_240409:weapon_bee.name" } : { translate: "item.ldz_240409:weapon_bee.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.bee.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.bee.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    blaze: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBlaze') ? "textures/ldz/240409/items/weapon_blaze" : "textures/ldz/240409/items/weapon_blaze_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBlaze') ? { translate: "item.ldz_240409:weapon_blaze.name" } : { translate: "item.ldz_240409:weapon_blaze.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBlaze') ? { translate: "item.ldz_240409:weapon_blaze.name" } : { translate: "item.ldz_240409:weapon_blaze.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.blaze.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.blaze.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    bogged: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBogged') ? "textures/ldz/240409/items/weapon_bogged" : "textures/ldz/240409/items/weapon_bogged_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBogged') ? { translate: "item.ldz_240409:weapon_bogged.name" } : { translate: "item.ldz_240409:weapon_bogged.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBogged') ? { translate: "item.ldz_240409:weapon_bogged.name" } : { translate: "item.ldz_240409:weapon_bogged.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.bogged.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.bogged.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    breeze: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBreeze') ? "textures/ldz/240409/items/weapon_breeze" : "textures/ldz/240409/items/weapon_breeze_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBreeze') ? { translate: "item.ldz_240409:weapon_breeze.name" } : { translate: "item.ldz_240409:weapon_breeze.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedBreeze') ? { translate: "item.ldz_240409:weapon_breeze.name" } : { translate: "item.ldz_240409:weapon_breeze.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.breeze.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.breeze.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    camel: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCamel') ? "textures/ldz/240409/items/weapon_camel" : "textures/ldz/240409/items/weapon_camel_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCamel') ? { translate: "item.ldz_240409:weapon_camel.name" } : { translate: "item.ldz_240409:weapon_camel.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCamel') ? { translate: "item.ldz_240409:weapon_camel.name" } : { translate: "item.ldz_240409:weapon_camel.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.camel.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.camel.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    cow: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCow') ? "textures/ldz/240409/items/weapon_cow" : "textures/ldz/240409/items/weapon_cow_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCow') ? { translate: "item.ldz_240409:weapon_cow.name" } : { translate: "item.ldz_240409:weapon_cow.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCow') ? { translate: "item.ldz_240409:weapon_cow.name" } : { translate: "item.ldz_240409:weapon_cow.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.cow.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.cow.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    chicken: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedChicken') ? "textures/ldz/240409/items/weapon_chicken" : "textures/ldz/240409/items/weapon_chicken_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedChicken') ? { translate: "item.ldz_240409:weapon_chicken.name" } : { translate: "item.ldz_240409:weapon_chicken.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedChicken') ? { translate: "item.ldz_240409:weapon_chicken.name" } : { translate: "item.ldz_240409:weapon_chicken.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.chicken.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.chicken.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    creaking: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCreaking') ? "textures/ldz/240409/items/weapon_creaking" : "textures/ldz/240409/items/weapon_creaking_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCreaking') ? { translate: "item.ldz_240409:weapon_creaking.name" } : { translate: "item.ldz_240409:weapon_creaking.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCreaking') ? { translate: "item.ldz_240409:weapon_creaking.name" } : { translate: "item.ldz_240409:weapon_creaking.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.creaking.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.creaking.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    creeper: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCreeper') ? "textures/ldz/240409/items/weapon_creeper" : "textures/ldz/240409/items/weapon_creeper_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCreeper') ? { translate: "item.ldz_240409:weapon_creeper.name" } : { translate: "item.ldz_240409:weapon_creeper.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedCreeper') ? { translate: "item.ldz_240409:weapon_creeper.name" } : { translate: "item.ldz_240409:weapon_creeper.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.creeper.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.creeper.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    ender_dragon: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEnderDragon') ? "textures/ldz/240409/items/weapon_ender_dragon" : "textures/ldz/240409/items/weapon_ender_dragon_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEnderDragon') ? { translate: "item.ldz_240409:weapon_ender_dragon.name" } : { translate: "item.ldz_240409:weapon_ender_dragon.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEnderDragon') ? { translate: "item.ldz_240409:weapon_ender_dragon.name" } : { translate: "item.ldz_240409:weapon_ender_dragon.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.ender_dragon.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.ender_dragon.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    enderman: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEnderman') ? "textures/ldz/240409/items/weapon_enderman" : "textures/ldz/240409/items/weapon_enderman_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEnderman') ? { translate: "item.ldz_240409:weapon_enderman.name" } : { translate: "item.ldz_240409:weapon_enderman.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEnderman') ? { translate: "item.ldz_240409:weapon_enderman.name" } : { translate: "item.ldz_240409:weapon_enderman.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.enderman.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.enderman.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    evoker: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEvoker') ? "textures/ldz/240409/items/weapon_evoker" : "textures/ldz/240409/items/weapon_evoker_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEvoker') ? { translate: "item.ldz_240409:weapon_evoker.name" } : { translate: "item.ldz_240409:weapon_evoker.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedEvoker') ? { translate: "item.ldz_240409:weapon_evoker.name" } : { translate: "item.ldz_240409:weapon_evoker.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.evoker.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.evoker.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    frog: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedFrog') ? "textures/ldz/240409/items/weapon_frog" : "textures/ldz/240409/items/weapon_frog_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedFrog') ? { translate: "item.ldz_240409:weapon_frog.name" } : { translate: "item.ldz_240409:weapon_frog.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedFrog') ? { translate: "item.ldz_240409:weapon_frog.name" } : { translate: "item.ldz_240409:weapon_frog.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.frog.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.frog.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    ghast: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedGhast') ? "textures/ldz/240409/items/weapon_ghast" : "textures/ldz/240409/items/weapon_ghast_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedGhast') ? { translate: "item.ldz_240409:weapon_ghast.name" } : { translate: "item.ldz_240409:weapon_ghast.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedGhast') ? { translate: "item.ldz_240409:weapon_ghast.name" } : { translate: "item.ldz_240409:weapon_ghast.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.ghast.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.ghast.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    guardian: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedGuardian') ? "textures/ldz/240409/items/weapon_guardian" : "textures/ldz/240409/items/weapon_guardian_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedGuardian') ? { translate: "item.ldz_240409:weapon_guardian.name" } : { translate: "item.ldz_240409:weapon_guardian.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedGuardian') ? { translate: "item.ldz_240409:weapon_guardian.name" } : { translate: "item.ldz_240409:weapon_guardian.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.guardian.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.guardian.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    iron_golem: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedIronGolem') ? "textures/ldz/240409/items/weapon_iron_golem" : "textures/ldz/240409/items/weapon_iron_golem_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedIronGolem') ? { translate: "item.ldz_240409:weapon_iron_golem.name" } : { translate: "item.ldz_240409:weapon_iron_golem.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedIronGolem') ? { translate: "item.ldz_240409:weapon_iron_golem.name" } : { translate: "item.ldz_240409:weapon_iron_golem.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.iron_golem.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.iron_golem.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    magma_cube: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedMagmaCube') ? "textures/ldz/240409/items/weapon_magma_cube" : "textures/ldz/240409/items/weapon_magma_cube_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedMagmaCube') ? { translate: "item.ldz_240409:weapon_magma_cube.name" } : { translate: "item.ldz_240409:weapon_magma_cube.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedMagmaCube') ? { translate: "item.ldz_240409:weapon_magma_cube.name" } : { translate: "item.ldz_240409:weapon_magma_cube.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.magma_cube.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.magma_cube.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    mooshroom: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedMooshroom') ? "textures/ldz/240409/items/weapon_mooshroom" : "textures/ldz/240409/items/weapon_mooshroom_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedMooshroom') ? { translate: "item.ldz_240409:weapon_mooshroom.name" } : { translate: "item.ldz_240409:weapon_mooshroom.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedMooshroom') ? { translate: "item.ldz_240409:weapon_mooshroom.name" } : { translate: "item.ldz_240409:weapon_mooshroom.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.mooshroom.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.mooshroom.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    pig: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPig') ? "textures/ldz/240409/items/weapon_pig" : "textures/ldz/240409/items/weapon_pig_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPig') ? { translate: "item.ldz_240409:weapon_pig.name" } : { translate: "item.ldz_240409:weapon_pig.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPig') ? { translate: "item.ldz_240409:weapon_pig.name" } : { translate: "item.ldz_240409:weapon_pig.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.pig.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.pig.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    piglin: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPiglin') ? "textures/ldz/240409/items/weapon_piglin" : "textures/ldz/240409/items/weapon_piglin_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPiglin') ? { translate: "item.ldz_240409:weapon_piglin.name" } : { translate: "item.ldz_240409:weapon_piglin.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPiglin') ? { translate: "item.ldz_240409:weapon_piglin.name" } : { translate: "item.ldz_240409:weapon_piglin.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.piglin.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.piglin.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    polar_bear: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPolarBear') ? "textures/ldz/240409/items/weapon_polar_bear" : "textures/ldz/240409/items/weapon_polar_bear_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPolarBear') ? { translate: "item.ldz_240409:weapon_polar_bear.name" } : { translate: "item.ldz_240409:weapon_polar_bear.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPolarBear') ? { translate: "item.ldz_240409:weapon_polar_bear.name" } : { translate: "item.ldz_240409:weapon_polar_bear.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.polar_bear.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.polar_bear.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    pufferfish: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPufferfish') ? "textures/ldz/240409/items/weapon_pufferfish" : "textures/ldz/240409/items/weapon_pufferfish_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPufferfish') ? { translate: "item.ldz_240409:weapon_pufferfish.name" } : { translate: "item.ldz_240409:weapon_pufferfish.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedPufferfish') ? { translate: "item.ldz_240409:weapon_pufferfish.name" } : { translate: "item.ldz_240409:weapon_pufferfish.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.pufferfish.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.pufferfish.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    ravager: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedRavager') ? "textures/ldz/240409/items/weapon_ravager" : "textures/ldz/240409/items/weapon_ravager_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedRavager') ? { translate: "item.ldz_240409:weapon_ravager.name" } : { translate: "item.ldz_240409:weapon_ravager.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedRavager') ? { translate: "item.ldz_240409:weapon_ravager.name" } : { translate: "item.ldz_240409:weapon_ravager.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.ravager.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.ravager.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    shulker: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedShulker') ? "textures/ldz/240409/items/weapon_shulker" : "textures/ldz/240409/items/weapon_shulker_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedShulker') ? { translate: "item.ldz_240409:weapon_shulker.name" } : { translate: "item.ldz_240409:weapon_shulker.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedShulker') ? { translate: "item.ldz_240409:weapon_shulker.name" } : { translate: "item.ldz_240409:weapon_shulker.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.shulker.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.shulker.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    sheep: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSheep') ? "textures/ldz/240409/items/weapon_sheep" : "textures/ldz/240409/items/weapon_sheep_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSheep') ? { translate: "item.ldz_240409:weapon_sheep.name" } : { translate: "item.ldz_240409:weapon_sheep.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSheep') ? { translate: "item.ldz_240409:weapon_sheep.name" } : { translate: "item.ldz_240409:weapon_sheep.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.sheep.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.sheep.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    skeleton: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSkeleton') ? "textures/ldz/240409/items/weapon_skeleton" : "textures/ldz/240409/items/weapon_skeleton_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSkeleton') ? { translate: "item.ldz_240409:weapon_skeleton.name" } : { translate: "item.ldz_240409:weapon_skeleton.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSkeleton') ? { translate: "item.ldz_240409:weapon_skeleton.name" } : { translate: "item.ldz_240409:weapon_skeleton.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.skeleton.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.skeleton.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    slime: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSlime') ? "textures/ldz/240409/items/weapon_slime" : "textures/ldz/240409/items/weapon_slime_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSlime') ? { translate: "item.ldz_240409:weapon_slime.name" } : { translate: "item.ldz_240409:weapon_slime.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSlime') ? { translate: "item.ldz_240409:weapon_slime.name" } : { translate: "item.ldz_240409:weapon_slime.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.slime.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.slime.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    sniffer: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSniffer') ? "textures/ldz/240409/items/weapon_sniffer" : "textures/ldz/240409/items/weapon_sniffer_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSniffer') ? { translate: "item.ldz_240409:weapon_sniffer.name" } : { translate: "item.ldz_240409:weapon_sniffer.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSniffer') ? { translate: "item.ldz_240409:weapon_sniffer.name" } : { translate: "item.ldz_240409:weapon_sniffer.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.sniffer.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.sniffer.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    snow_golem: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSnowGolem') ? "textures/ldz/240409/items/weapon_snow_golem" : "textures/ldz/240409/items/weapon_snow_golem_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSnowGolem') ? { translate: "item.ldz_240409:weapon_snow_golem.name" } : { translate: "item.ldz_240409:weapon_snow_golem.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSnowGolem') ? { translate: "item.ldz_240409:weapon_snow_golem.name" } : { translate: "item.ldz_240409:weapon_snow_golem.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.snow_golem.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.snow_golem.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    spider: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSpider') ? "textures/ldz/240409/items/weapon_spider" : "textures/ldz/240409/items/weapon_spider_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSpider') ? { translate: "item.ldz_240409:weapon_spider.name" } : { translate: "item.ldz_240409:weapon_spider.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedSpider') ? { translate: "item.ldz_240409:weapon_spider.name" } : { translate: "item.ldz_240409:weapon_spider.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.spider.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.spider.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    turtle: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedTurtle') ? "textures/ldz/240409/items/weapon_turtle" : "textures/ldz/240409/items/weapon_turtle_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedTurtle') ? { translate: "item.ldz_240409:weapon_turtle.name" } : { translate: "item.ldz_240409:weapon_turtle.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedTurtle') ? { translate: "item.ldz_240409:weapon_turtle.name" } : { translate: "item.ldz_240409:weapon_turtle.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.turtle.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.turtle.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    villager: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedVillager') ? "textures/ldz/240409/items/weapon_villager" : "textures/ldz/240409/items/weapon_villager_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedVillager') ? { translate: "item.ldz_240409:weapon_villager.name" } : { translate: "item.ldz_240409:weapon_villager.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedVillager') ? { translate: "item.ldz_240409:weapon_villager.name" } : { translate: "item.ldz_240409:weapon_villager.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.villager.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.villager.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    warden: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWarden') ? "textures/ldz/240409/items/weapon_warden" : "textures/ldz/240409/items/weapon_warden_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWarden') ? { translate: "item.ldz_240409:weapon_warden.name" } : { translate: "item.ldz_240409:weapon_warden.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWarden') ? { translate: "item.ldz_240409:weapon_warden.name" } : { translate: "item.ldz_240409:weapon_warden.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.warden.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.warden.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    witch: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWitch') ? "textures/ldz/240409/items/weapon_witch" : "textures/ldz/240409/items/weapon_witch_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWitch') ? { translate: "item.ldz_240409:weapon_witch.name" } : { translate: "item.ldz_240409:weapon_witch.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWitch') ? { translate: "item.ldz_240409:weapon_witch.name" } : { translate: "item.ldz_240409:weapon_witch.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.witch.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.witch.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    wither: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWither') ? "textures/ldz/240409/items/weapon_wither" : "textures/ldz/240409/items/weapon_wither_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWither') ? { translate: "item.ldz_240409:weapon_wither.name" } : { translate: "item.ldz_240409:weapon_wither.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWither') ? { translate: "item.ldz_240409:weapon_wither.name" } : { translate: "item.ldz_240409:weapon_wither.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.wither.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.wither.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    wolf: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWolf') ? "textures/ldz/240409/items/weapon_wolf" : "textures/ldz/240409/items/weapon_wolf_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWolf') ? { translate: "item.ldz_240409:weapon_wolf.name" } : { translate: "item.ldz_240409:weapon_wolf.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedWolf') ? { translate: "item.ldz_240409:weapon_wolf.name" } : { translate: "item.ldz_240409:weapon_wolf.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.wolf.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.wolf.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    zombie: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedZombie') ? "textures/ldz/240409/items/weapon_zombie" : "textures/ldz/240409/items/weapon_zombie_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedZombie') ? { translate: "item.ldz_240409:weapon_zombie.name" } : { translate: "item.ldz_240409:weapon_zombie.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedZombie') ? { translate: "item.ldz_240409:weapon_zombie.name" } : { translate: "item.ldz_240409:weapon_zombie.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.zombie.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.zombie.recipe", with: ['\n'] }] },
                        contents: []
                    },
                    zombie_villager: {
                        type: "buttons",
                        icon: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedZombieVillager') ? "textures/ldz/240409/items/weapon_zombie_villager" : "textures/ldz/240409/items/weapon_zombie_villager_silhouette",
                        buttonLabel(player) { return utils.getScoreAsBool(player.UnsafeEntity, 'CraftedZombieVillager') ? { translate: "item.ldz_240409:weapon_zombie_villager.name" } : { translate: "item.ldz_240409:weapon_zombie_villager.name_hidden" }; },
                        title: utils.getScoreAsBool(player.UnsafeEntity, 'CraftedZombieVillager') ? { translate: "item.ldz_240409:weapon_zombie_villager.name" } : { translate: "item.ldz_240409:weapon_zombie_villager.name_hidden" },
                        body: { rawtext: [{ translate: "ldz_240409:menu.book.zombie_villager.description", with: ['\n'] }, { text: "\n\n" }, { translate: "ldz_240409:menu.book.generic.recipe_prefix", with: ['\n'] }, { translate: "ldz_240409:menu.book.zombie_villager.recipe", with: ['\n'] }] },
                        contents: []
                    },
                }
            },
            mob_magnet: {
                type: "buttons",
                icon: "textures/ldz/240409/items/mob_magnet",
                buttonLabel: utils.translate('menu.book.mob_magnet.button'),
                title: utils.translate('menu.book.mob_magnet.title'),
                body: utils.translate('menu.book.mob_magnet.body'),
                contents: []
            },
            settings: {
                type: "modal",
                icon: "textures/ui/automation_glyph_color",
                buttonLabel: utils.translate('menu.book.settings.button'),
                title: utils.translate('menu.book.settings.title'),
                contents: [
                    {
                        type: "toggle",
                        text: utils.translate('menu.book.settings.pvp'),
                        defaultValue(player) {
                            return mc.world.gameRules.pvp;
                        },
                        onSubmit(player, toggleValue) {
                            player.runCommand(`gamerule pvp ${String(toggleValue)}`);
                        },
                    }
                ]
            },
            overview: {
                type: "page_list",
                icon: "textures/ldz/240409/ui/infobulb",
                buttonLabel: utils.translate('menu.book.overview.button'),
                title: utils.translate('update.version.name', [utils.getVersionNumber()]),
                contents: {
                    how_to_play: {
                        type: "buttons",
                        icon: "textures/ldz/240409/ui/infobulb",
                        buttonLabel: utils.translate('menu.book.how_to_play.button'),
                        title: utils.translate('update.version.name', [utils.getVersionNumber()]),
                        body: utils.translate('menu.book.how_to_play.body'),
                        contents: []
                    },
                    changelog: {
                        type: "buttons",
                        icon: "textures/ldz/240409/ui/changelog_1.3",
                        buttonLabel: utils.translate('menu.book.changelog.button'),
                        title: utils.translate('update.version.name', [utils.getVersionNumber()]),
                        body: utils.translate('menu.book.changelog.body'),
                        contents: []
                    },
                    credits: {
                        type: "buttons",
                        icon: "textures/ui/icon_book_writable",
                        buttonLabel: utils.translate('menu.book.credits.button'),
                        title: utils.translate('update.version.name', [utils.getVersionNumber()]),
                        body: utils.translate('menu.book.credits.body'),
                        contents: []
                    }
                }
            }
        }
    }, { defaultBackIcon: "textures/ldz/240409/ui/back" }).showMenuToPlayer(player);
}
