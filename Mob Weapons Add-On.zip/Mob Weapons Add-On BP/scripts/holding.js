import * as mc from "@minecraft/server";
import * as utils from "./utils/index";
utils.waitForLoopEvent(10, () => {
    utils.getAllPlayersSafe().forEach((player) => {
        var _a, _b, _c, _d, _e, _f, _g;
        try {
            if (((_b = (_a = player.Equipment) === null || _a === void 0 ? void 0 : _a.getEquipmentSlot(mc.EquipmentSlot.Mainhand)) === null || _b === void 0 ? void 0 : _b.typeId) === "ldz_240409:weapon_axolotl") {
                player.dimension.getEntities({ location: player.location, maxDistance: 20 }).forEach((entity) => {
                    if (entity.typeId === "minecraft:axolotl") {
                        entity.addEffect("speed", 15, { amplifier: 5 });
                    }
                });
            }
            else if (((_d = (_c = player.Equipment) === null || _c === void 0 ? void 0 : _c.getEquipmentSlot(mc.EquipmentSlot.Mainhand)) === null || _d === void 0 ? void 0 : _d.typeId) === "ldz_240409:weapon_witch") {
                const healing = (_e = player.getDynamicProperty("witch_weapon_healing_mode")) !== null && _e !== void 0 ? _e : false;
                player.onScreenDisplay.setActionBar({ translate: healing ? "action.hint.ldz_240409:witch_weapon_healing_mode_on" : "action.hint.ldz_240409:witch_weapon_healing_mode_off" });
            }
            else if (((_g = (_f = player.Equipment) === null || _f === void 0 ? void 0 : _f.getEquipmentSlot(mc.EquipmentSlot.Mainhand)) === null || _g === void 0 ? void 0 : _g.typeId) === "ldz_240409:weapon_sniffer") {
                const STRUCTURE_ID_PROPERTY = "savedMobStructureID";
                const item = player.MainHand;
                if (!item)
                    throw new Error("Player has no item in main hand");
                const hasSavedMob = utils.readDynamicProperty(item, STRUCTURE_ID_PROPERTY);
                if (hasSavedMob)
                    player.playAnimation(`animation.${utils.GlobalNamespace.NamespaceUnformatted}.player.weapon_sniffer.idle.contain_mob_shake`, {});
            }
        }
        catch (e) { }
    });
});
