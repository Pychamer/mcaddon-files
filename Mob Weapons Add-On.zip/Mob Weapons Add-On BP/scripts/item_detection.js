import * as mc from '@minecraft/server';
import * as utils from './utils/index';
const WEAPONS = [
    "allay",
    "armadillo",
    "axolotl",
    "bee",
    "blaze",
    "bogged",
    "breeze",
    "camel",
    "cow",
    "chicken",
    "creaking",
    "creeper",
    "ender_dragon",
    "enderman",
    "evoker",
    "frog",
    "ghast",
    "guardian",
    "iron_golem",
    "magma_cube",
    "mooshroom",
    "pig",
    "piglin",
    "polar_bear",
    "pufferfish",
    "ravager",
    "sheep",
    "shulker",
    "skeleton",
    "slime",
    "sniffer",
    "snow_golem",
    "spider",
    "turtle",
    "villager",
    "warden",
    "witch",
    "wither",
    "wolf",
    "zombie_villager",
    "zombie",
];
export function initializeItemDetection() {
    mc.world.afterEvents.playerSpawn.subscribe(event => {
        startScanning(new utils.SafetyCheckedPlayer(event.player));
    });
    utils.getAllPlayersSafe().forEach(player => { startScanning(player); });
}
function startScanning(player) {
    const inventory = player.Inventory;
    utils.waitForLoopEvent(20, () => {
        if (!player.isValid())
            return true;
        if (!inventory)
            return true;
        for (let x = 0; x < inventory.size; x++) {
            const item = inventory.getItem(x);
            if (item) {
                const weapon = WEAPONS.find(weapon => item.typeId === (formatWeaponId(weapon)));
                if (weapon && !utils.getScoreAsBool(player.UnsafeEntity, formatWeaponScoreboard(weapon))) {
                    unlockWeaponObjective(player.getPlayer(), weapon);
                }
            }
        }
        return !player.isValid();
    });
}
function formatWeaponId(weapon) {
    return `${utils.GlobalNamespace.Namespace}weapon_${weapon}`;
}
function formatWeaponScoreboard(weapon) {
    const pascal = weapon.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join('');
    return `Crafted${pascal}`;
}
function unlockWeaponObjective(player, weapon) {
    player.playSound("ldz_240409:player.notification");
    utils.setScore(player.UnsafeEntity, formatWeaponScoreboard(weapon), 1);
    player.sendMessage({ rawtext: [{ translate: "action.hint.unlock.ldz_240409:weapon", with: { rawtext: [{ translate: `item.${formatWeaponId(weapon)}.name` }] } }] });
}
