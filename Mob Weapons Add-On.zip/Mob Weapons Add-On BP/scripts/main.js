import * as mc from "@minecraft/server";
import * as utils from "./utils/index";
import * as weapons from "./weapons/index";
import { initializeMobMagnet } from "./mob_magnet";
import { initializeGuideBook, useGuideBook } from "./guide_book";
import { initializeItemDetection } from "./item_detection";
import "./holding";
const CUSTOM_ITEMS = [
    { typeId: "ldz_240409:guide_book", options: { itemCallback: useGuideBook } },
    { typeId: "ldz_240409:weapon_allay", options: { itemCallback: weapons.onAllayUse } },
    { typeId: "ldz_240409:weapon_armadillo", options: { itemCallback: weapons.onArmadilloUse } },
    { typeId: "ldz_240409:weapon_axolotl", options: { itemCallback: weapons.onAxolotlUse, meleeAttack: weapons.AXOLOTL_ATTACK } },
    { typeId: "ldz_240409:weapon_bee", options: { itemCallback: weapons.onBeeUse, meleeAttack: weapons.BEE_ATTACK } },
    { typeId: "ldz_240409:weapon_blaze", options: { itemCallback: weapons.onBlazeUse } },
    { typeId: "ldz_240409:weapon_bogged", options: { itemCallback: weapons.onBoggedUse } },
    { typeId: "ldz_240409:weapon_breeze", options: { itemCallback: weapons.onBreezeUse } },
    { typeId: "ldz_240409:weapon_camel", options: { itemCallback: weapons.onCamelUse, meleeAttack: weapons.CAMEL_ATTACK } },
    { typeId: "ldz_240409:weapon_chicken", options: { itemCallback: weapons.onChickenUse, meleeAttack: weapons.CHICKEN_ATTACK } },
    { typeId: "ldz_240409:weapon_cow", options: { itemCallback: weapons.onCowUse, meleeAttack: weapons.COW_ATTACK } },
    { typeId: "ldz_240409:weapon_creeper", options: { itemCallback: weapons.onCreeperUse } },
    { typeId: "ldz_240409:weapon_creaking", options: { itemCallback: weapons.onCreakingUse } },
    { typeId: "ldz_240409:weapon_ender_dragon", options: { itemCallback: weapons.onEnderDragonUse } },
    { typeId: "ldz_240409:weapon_enderman", options: { itemCallback: weapons.onEndermanUse } },
    { typeId: "ldz_240409:weapon_evoker", options: { itemCallback: weapons.onEvokerUse } },
    { typeId: "ldz_240409:weapon_frog", options: { itemCallback: weapons.onFrogUse, meleeAttack: weapons.FROG_ATTACK } },
    { typeId: "ldz_240409:weapon_ghast", options: { itemCallback: weapons.onGhastUse } },
    { typeId: "ldz_240409:weapon_guardian", options: { itemCallback: weapons.onGuardianUse } },
    { typeId: "ldz_240409:weapon_iron_golem", options: { itemCallback: weapons.onIronGolemUse, meleeAttack: weapons.GOLEM_ATTACK } },
    { typeId: "ldz_240409:weapon_magma_cube", options: { itemCallback: weapons.onMagmaCubeUse, meleeAttack: weapons.MAGMA_CUBE_ATTACK } },
    { typeId: "ldz_240409:weapon_mooshroom", options: { itemCallback: weapons.onMooshroomUse, meleeAttack: weapons.MOOSHROOM_ATTACK } },
    { typeId: "ldz_240409:weapon_pig", options: { itemCallback: weapons.onPigUse } },
    { typeId: "ldz_240409:weapon_piglin", options: { itemCallback: weapons.onPiglinUse, meleeAttack: weapons.PIGLIN_ATTACK } },
    { typeId: "ldz_240409:weapon_polar_bear", options: { itemCallback: weapons.onPolarBearUse, meleeAttack: weapons.POLAR_BEAR_ATTACK } },
    { typeId: "ldz_240409:weapon_pufferfish", options: { itemCallback: weapons.onPufferfishUse, meleeAttack: weapons.PUFFERFISH_ATTACK } },
    { typeId: "ldz_240409:weapon_ravager", options: { itemCallback: weapons.onRavagerUse, meleeAttack: weapons.RAVAGER_ATTACK } },
    { typeId: "ldz_240409:weapon_sheep", options: { itemCallback: weapons.onSheepUse } },
    { typeId: "ldz_240409:weapon_shulker", options: { itemCallback: weapons.onShulkerUse } },
    { typeId: "ldz_240409:weapon_skeleton", options: { itemCallback: weapons.onSkeletonUse } },
    { typeId: "ldz_240409:weapon_slime", options: { itemCallback: weapons.onSlimeUse } },
    { typeId: "ldz_240409:weapon_sniffer", options: { itemCallback: weapons.onSnifferUse } },
    { typeId: "ldz_240409:weapon_snow_golem", options: { itemCallback: weapons.onSnowGolemUse } },
    { typeId: "ldz_240409:weapon_spider", options: { itemCallback: weapons.onSpiderUse, meleeAttack: weapons.SPIDER_ATTACK } },
    { typeId: "ldz_240409:weapon_turtle", options: { itemCallback: weapons.onTurtleUse } },
    { typeId: "ldz_240409:weapon_villager", options: { itemCallback: weapons.onVillagerUse, meleeAttack: weapons.VILLAGER_ATTACK } },
    { typeId: "ldz_240409:weapon_warden", options: { itemCallback: weapons.onWardenUse, meleeAttack: weapons.WARDEN_ATTACK } },
    { typeId: "ldz_240409:weapon_witch", options: { itemCallback: weapons.onWitchUse } },
    { typeId: "ldz_240409:weapon_wither", options: { itemCallback: weapons.onWitherUse } },
    { typeId: "ldz_240409:weapon_wolf", options: { itemCallback: weapons.onWolfUse, meleeAttack: weapons.WOLF_ATTACK } },
    { typeId: "ldz_240409:weapon_zombie_villager", options: { itemCallback: weapons.onZombieVillagerUse } },
    { typeId: "ldz_240409:weapon_zombie", options: { itemCallback: weapons.onZombieUse } },
];
async function main() {
    utils.GlobalNamespace.Namespace = "ldz_240409";
    await utils.waitForWorldLoad();
    utils.setVersionNumber("v1.3.0");
    initializeMobMagnet();
    initializeGuideBook();
    initializeItemDetection();
    utils.initializeCustomItem(CUSTOM_ITEMS);
    utils.mclog("Loaded (Mob Weapons Add-On)");
}
mc.system.run(main);
