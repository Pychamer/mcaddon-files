## Loop for the guardian staff when you do have a target
## @s = player using the guardian staff

## Every iteration, we remove the TargetAcquired tag and reapply it only if our target is still within our 15 block range
tag @s remove TargetAcquired
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,r=15,c=1] run tag @s add TargetAcquired

## Sets beam length based on distance to target
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=0,r=1,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_1
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=1,r=2,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_2
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=2,r=3,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_3
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=3,r=4,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_4
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=4,r=5,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_5
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=5,r=6,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_6
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=6,r=7,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_7
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=7,r=8,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_8
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=8,r=9,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_9
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=9,r=10,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_10
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=10,r=11,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_11
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=11,r=12,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_12
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=12,r=13,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_13
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=13,r=14,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_14
execute at @s if entity @e[tag=ldz_240409:GuardianTarget,rm=14,r=15,c=1] run playanimation @s animation.ldz_240409.player.guardian_length_15

tag @e[r=15] remove ldz_240409:GuardianTarget