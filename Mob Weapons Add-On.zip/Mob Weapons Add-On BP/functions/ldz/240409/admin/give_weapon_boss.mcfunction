function ldz/240409/admin/clear_weapons_all

give @s ldz_240409:weapon_ender_dragon
give @s ldz_240409:weapon_warden
give @s ldz_240409:weapon_wither