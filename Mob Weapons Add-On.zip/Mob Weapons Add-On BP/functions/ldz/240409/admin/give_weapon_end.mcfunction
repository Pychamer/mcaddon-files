function ldz/240409/admin/clear_weapons_all

give @s ldz_240409:weapon_enderman
give @s ldz_240409:weapon_shulker