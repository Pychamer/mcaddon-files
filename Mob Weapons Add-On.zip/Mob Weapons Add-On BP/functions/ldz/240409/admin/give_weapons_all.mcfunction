function ldz/240409/admin/clear_weapons_all
function ldz/240409/admin/give_weapon_light
function ldz/240409/admin/give_weapon_dark
function ldz/240409/admin/give_weapon_nether
function ldz/240409/admin/give_weapon_end
function ldz/240409/admin/give_weapon_boss