function ldz/240409/admin/clear_weapons_all

give @s ldz_240409:weapon_blaze
give @s ldz_240409:weapon_ghast
give @s ldz_240409:weapon_piglin