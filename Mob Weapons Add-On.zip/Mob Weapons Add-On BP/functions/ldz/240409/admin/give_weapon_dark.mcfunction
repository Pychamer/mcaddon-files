function ldz/240409/admin/clear_weapons_all

give @s ldz_240409:weapon_bogged
give @s ldz_240409:weapon_breeze
give @s ldz_240409:weapon_creaking
give @s ldz_240409:weapon_creeper
give @s ldz_240409:weapon_evoker
give @s ldz_240409:weapon_guardian
give @s ldz_240409:weapon_ravager
give @s ldz_240409:weapon_skeleton
give @s ldz_240409:weapon_slime
give @s ldz_240409:weapon_spider
give @s ldz_240409:weapon_warden
give @s ldz_240409:weapon_witch
give @s ldz_240409:weapon_zombie