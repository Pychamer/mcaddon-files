function ldz/240409/admin/clear_weapons_all

give @s ldz_240409:weapon_allay
give @s ldz_240409:weapon_armadillo
give @s ldz_240409:weapon_axolotl
give @s ldz_240409:weapon_bee
give @s ldz_240409:weapon_camel
give @s ldz_240409:weapon_chicken
give @s ldz_240409:weapon_cow
give @s ldz_240409:weapon_frog
give @s ldz_240409:weapon_iron_golem
give @s ldz_240409:weapon_mooshroom
give @s ldz_240409:weapon_pig
give @s ldz_240409:weapon_polar_bear
give @s ldz_240409:weapon_pufferfish
give @s ldz_240409:weapon_sheep
give @s ldz_240409:weapon_villager
give @s ldz_240409:weapon_wolf